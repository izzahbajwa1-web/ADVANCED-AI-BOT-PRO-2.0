import unittest
from core.qualification import probability_gate
from core.trade_policy import setup_validity, manage_open_trade


class QualificationTests(unittest.TestCase):
    def test_no_validated_model_never_qualifies(self):
        for estimate in (None, .95, 1.0):
            result = probability_gate(estimate, model_validated=False)
            self.assertFalse(result['eligible'])
            self.assertIsNone(result['estimated_probability'])
        self.assertFalse(probability_gate(None, model_validated=True)['eligible'])

    def test_only_90_percent_or_higher_qualifies_with_caller_assertion(self):
        # Synthetic numbers test the gate ONLY. True is a caller assertion,
        # not evidence that a model or probability has actually been validated.
        self.assertFalse(probability_gate(.8999, model_validated=True)['eligible'])
        self.assertTrue(probability_gate(.90, model_validated=True)['eligible'])
        self.assertTrue(probability_gate(.95, model_validated=True)['eligible'])
        for bad in (True, -1, 1.01, float('nan'), '90%'):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                probability_gate(bad, model_validated=True)


class OpenTradePolicyTests(unittest.TestCase):
    def action(self, structure, orderflow, quote):
        return manage_open_trade(opposite_structure=structure, opposite_orderflow=orderflow,
                                 side='BUY',entry_price=100,original_stop=99,
                                 current_stop=99,exit_quote=quote,tick_size=.01)

    def test_only_both_opposite_confirmations_invalidate(self):
        for structure, flow, expected in ((False,False,'VALID'),(True,False,'VALID'),
                                          (False,True,'VALID'),(True,True,'INVALID'),
                                          (None,False,'UNKNOWN'),(True,None,'UNKNOWN'),
                                          (None,None,'UNKNOWN')):
            with self.subTest(structure=structure,flow=flow):
                self.assertEqual(setup_validity(opposite_structure=structure,opposite_orderflow=flow),expected)
        with self.assertRaises(ValueError):
            setup_validity(opposite_structure=1,opposite_orderflow=True)

    def test_invalidation_requests_close_before_and_after_one_r(self):
        for quote in (99.5, 100, 101, 102.5):
            with self.subTest(quote=quote):
                result=self.action(True,True,quote)
                self.assertEqual(result['setup_validity'],'INVALID')
                self.assertTrue(result['request_close_trade'])
                self.assertFalse(result['request_stop_change'])
                self.assertIsNone(result['proposed_stop'])

    def test_only_valid_setup_trails_and_only_after_one_r(self):
        for pair in ((False,False),(True,False),(False,True)):
            pre=self.action(*pair,100.9)
            self.assertEqual(pre['setup_validity'],'VALID')
            self.assertFalse(pre['request_close_trade']);self.assertFalse(pre['request_stop_change'])
            at=self.action(*pair,101)
            self.assertTrue(at['request_stop_change']);self.assertEqual(at['proposed_stop'],100)
            more=self.action(*pair,101.5)
            self.assertEqual(more['proposed_stop'],100.5)

    def test_unknown_neither_closes_nor_trails(self):
        for pair in ((None,True),(True,None),(None,None)):
            result=self.action(*pair,102)
            self.assertEqual(result['setup_validity'],'UNKNOWN')
            self.assertFalse(result['request_close_trade']);self.assertFalse(result['request_stop_change'])
            self.assertIsNone(result['proposed_stop'])

if __name__ == '__main__': unittest.main()
