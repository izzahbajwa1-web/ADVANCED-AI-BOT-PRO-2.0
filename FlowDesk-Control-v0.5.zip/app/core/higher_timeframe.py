"""Research D1/H4 market-structure context; not a validated prediction."""
from __future__ import annotations
from .staged_strategy import _valid_bars


def structure_bias(bars, *, width=2):
    """Classify last two fully confirmed swing highs and lows in closed bars.

    Two higher highs AND higher lows => bullish; lower highs AND lower lows =>
    bearish. Mixed/equal swings or insufficient pivots do not infer a trend.
    Width=2 is a provisional research setting. No live signal or order is sent.
    """
    if type(width) is not int or width < 1:
        raise ValueError("width must be positive")
    _valid_bars(bars)
    highs=[]; lows=[]
    for i in range(width,len(bars)-width):
        part=bars[i-width:i+width+1]; high=bars[i].high; low=bars[i].low
        if all(high > b.high for j,b in enumerate(part) if j != width): highs.append(high)
        if all(low < b.low for j,b in enumerate(part) if j != width): lows.append(low)
    if len(highs)<2 or len(lows)<2:
        return {"bias":"INSUFFICIENT", "last_closed_bar_ms":bars[-1].timestamp_ms if bars else None}
    if highs[-1] > highs[-2] and lows[-1] > lows[-2]: bias="BULLISH"
    elif highs[-1] < highs[-2] and lows[-1] < lows[-2]: bias="BEARISH"
    else: bias="MIXED"
    return {"bias":bias, "last_closed_bar_ms":bars[-1].timestamp_ms,
            "last_two_swing_highs":highs[-2:], "last_two_swing_lows":lows[-2:]}


def combined_bias(daily_bars, h4_bars):
    daily=structure_bias(daily_bars); h4=structure_bias(h4_bars)
    db, hb=daily['bias'],h4['bias']
    consensus=db if db==hb and db in {'BULLISH','BEARISH'} else 'MIXED_OR_INSUFFICIENT'
    return {"daily":daily,"h4":h4,"consensus":consensus,
            "label":"Research structure context; not a probability or validated trading rule"}
