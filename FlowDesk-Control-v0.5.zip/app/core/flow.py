"""Normalized, authenticated order-flow event receiver (research prototype)."""
from __future__ import annotations
from collections import deque
import math
import threading
import time

PLATFORMS = {"bookmap", "quantower", "atas"}
FRESH_MS = 5_000
WINDOW_MS = 30_000
MAX_TRADES = 8_000
MAX_BOOK_LEVELS = 50


def _number(value, name, *, positive=True):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} must be a finite number")
    if positive and value <= 0:
        raise ValueError(f"{name} must be greater than zero")
    return float(value)


def _text(value, name):
    if not isinstance(value, str) or not value.strip() or len(value) > 120:
        raise ValueError(f"{name} must be a non-empty string (max 120 chars)")
    return value.strip()


def _timestamp(value, now_ms):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("timestamp_ms must be integer UTC epoch milliseconds")
    if value > now_ms + 2_000 or value < now_ms - 120_000:
        raise ValueError("timestamp is too far from the receiver clock")
    return value


def _levels(value, side):
    if not isinstance(value, list) or not 1 <= len(value) <= MAX_BOOK_LEVELS:
        raise ValueError(f"{side} must contain 1 to {MAX_BOOK_LEVELS} levels")
    result = []
    for item in value:
        if not isinstance(item, list) or len(item) != 2:
            raise ValueError("book levels must be [price, size]")
        result.append([_number(item[0], "price"), _number(item[1], "size")])
    prices = [x[0] for x in result]
    if len(set(prices)) != len(prices):
        raise ValueError("duplicate price levels")
    result.sort(key=lambda x: x[0], reverse=(side == "bids"))
    return result


class FlowCollector:
    def __init__(self):
        self.lock = threading.RLock()
        self.streams = {}

    def accept(self, event: object, now_ms: int | None = None):
        now = int(time.time() * 1000) if now_ms is None else now_ms
        if not isinstance(event, dict):
            raise ValueError("event must be a JSON object")
        platform = _text(event.get("platform"), "platform").lower()
        if platform not in PLATFORMS:
            raise ValueError("unsupported platform")
        provider = _text(event.get("provider"), "provider")
        instrument = _text(event.get("instrument"), "instrument")
        kind = event.get("type")
        if kind not in {"book", "trades"}:
            raise ValueError("type must be book or trades")
        if event.get("declared_live") is not True:
            raise ValueError("sender must declare this live data; replay is not allowed")
        timestamp = _timestamp(event.get("timestamp_ms"), now)
        timestamp_origin = _text(event.get("timestamp_origin"), "timestamp_origin")
        key = (platform, provider, instrument)

        # Validate the complete batch before mutating state.
        if kind == "book":
            bids = _levels(event.get("bids"), "bids")
            asks = _levels(event.get("asks"), "asks")
            if bids[0][0] >= asks[0][0]:
                raise ValueError("crossed or locked book snapshot")
            parsed = (bids, asks)
        else:
            trades = event.get("trades")
            if not isinstance(trades, list) or not 1 <= len(trades) <= 500:
                raise ValueError("trades must contain 1 to 500 trades")
            parsed = []
            for t in trades:
                if not isinstance(t, dict):
                    raise ValueError("each trade must be an object")
                ts = _timestamp(t.get("timestamp_ms"), now)
                price, size = _number(t.get("price"), "price"), _number(t.get("size"), "size")
                side = t.get("aggressor")
                if side not in {"buy", "sell", "unknown"}:
                    raise ValueError("aggressor must be buy, sell or unknown")
                parsed.append((ts, price, size, side))
            if any(a[0] > b[0] for a, b in zip(parsed, parsed[1:])) or parsed[-1][0] != timestamp:
                raise ValueError("trade timestamps must be ordered; batch timestamp must be last trade time")
            if event.get("continuity") not in {"ok", "gap"}:
                raise ValueError("continuity must be ok or gap")

        with self.lock:
            s = self.streams.setdefault(key, {
                "platform": platform, "provider": provider, "instrument": instrument,
                "bids": None, "asks": None, "book_source_ms": None,
                "book_receive_ms": None, "last_trade_source_ms": None,
                "last_trade_receive_ms": None, "first_trade_receive_ms": None, "trades": deque(), "gap_until_ms": 0,
                "last_receive_ms": None, "timestamp_origin": timestamp_origin,
            })
            if s["timestamp_origin"] != timestamp_origin:
                raise ValueError("timestamp origin changed; restart receiver to clear the stream")
            if kind == "book":
                if s["book_source_ms"] is not None and timestamp < s["book_source_ms"]:
                    raise ValueError("book timestamp moved backwards")
                s["bids"], s["asks"] = parsed
                s["book_source_ms"], s["book_receive_ms"] = timestamp, now
            else:
                previous = s["last_trade_source_ms"]
                if previous is not None and parsed[0][0] < previous:
                    raise ValueError("trade timestamps moved backwards")
                if event["continuity"] == "gap":
                    s["gap_until_ms"] = max(s["gap_until_ms"], now + WINDOW_MS)
                if s["first_trade_receive_ms"] is None:
                    s["first_trade_receive_ms"] = now
                s["trades"].extend(parsed)
                while s["trades"] and s["trades"][0][0] < now - WINDOW_MS:
                    s["trades"].popleft()
                if len(s["trades"]) > MAX_TRADES:
                    while len(s["trades"]) > MAX_TRADES:
                        s["trades"].popleft()
                    s["gap_until_ms"] = max(s["gap_until_ms"], now + WINDOW_MS)
                s["last_trade_source_ms"] = timestamp
                s["last_trade_receive_ms"] = now
            s["last_receive_ms"] = now
        return {"accepted": True}

    def summaries(self, now_ms: int | None = None):
        now = int(time.time() * 1000) if now_ms is None else now_ms
        results = []
        with self.lock:
            for s in self.streams.values():
                fresh_book = (s["book_source_ms"] is not None and
                              0 <= now - s["book_source_ms"] <= FRESH_MS and
                              0 <= now - s["book_receive_ms"] <= FRESH_MS)
                fresh_trade = (s["last_trade_source_ms"] is not None and
                               0 <= now - s["last_trade_source_ms"] <= FRESH_MS and
                               0 <= now - s["last_trade_receive_ms"] <= FRESH_MS)
                window = [t for t in s["trades"] if now - WINDOW_MS <= t[0] <= now]
                buy = sum(t[2] for t in window if t[3] == "buy")
                sell = sum(t[2] for t in window if t[3] == "sell")
                unknown = sum(t[2] for t in window if t[3] == "unknown")
                imbalance = None
                if s["bids"] and s["asks"]:
                    bid_size = sum(p[1] for p in s["bids"][:5])
                    ask_size = sum(p[1] for p in s["asks"][:5])
                    if bid_size + ask_size > 0:
                        imbalance = (bid_size - ask_size) / (bid_size + ask_size)
                # Unknown aggressors and any known gap disable confirmation.
                warm = (s["first_trade_receive_ms"] is not None and
                        now - s["first_trade_receive_ms"] >= WINDOW_MS)
                usable = bool(warm and fresh_book and fresh_trade and now >= s["gap_until_ms"]
                              and buy + sell > 0 and unknown == 0)
                results.append({"platform": s["platform"], "provider": s["provider"],
                    "instrument": s["instrument"], "last_receive_ms": s["last_receive_ms"],
                    "book_fresh": fresh_book, "trade_fresh": fresh_trade, "warm": warm, "usable": usable,
                    "imbalance": imbalance, "delta": buy - sell if buy + sell else None,
                    "unknown_volume": unknown, "gap": now < s["gap_until_ms"],
                    "timestamp_origin": s["timestamp_origin"],
                    "book": {"bids": s["bids"], "asks": s["asks"]} if s["bids"] and s["asks"] else None,
                    "declared_live_unverified": True})
        return results
