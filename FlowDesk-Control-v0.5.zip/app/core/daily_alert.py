"""Daily account-equity ALERT model; it never closes or blocks trades.

The caller must obtain and persist a verified UTC day-start equity for the
correct account and feed current equity (including floating P/L). This model
is not connected to MT5 and does not deliver notifications in this build.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation


class MissingDayStartEquity(ValueError):
    """No verified equity baseline is available; do not invent one."""


def _finite_decimal(value, name: str) -> Decimal:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a finite number")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError(f"{name} must be a finite number") from None
    if not result.is_finite():
        raise ValueError(f"{name} must be a finite number")
    return result


@dataclass(frozen=True)
class DailyAlertState:
    utc_day: date
    day_start_equity: Decimal
    alerted: bool = False


def evaluate_daily_alert(*, now: datetime, current_equity, state: DailyAlertState | None,
                         verified_day_start_equity=None, daily_loss_alert_pct=10):
    """Return a latched daily alert decision without blocking or closing trades.

    Compare account equity including floating P/L against a verified UTC day
    start. At or below 90% with a 10% threshold, request an alert once. An
    alerted state remains visible for the rest of the UTC day, but does NOT
    close positions or pause new entries. A new, verified baseline is required
    on a new UTC date. No broker action or notification is performed here.
    """
    if not isinstance(now, datetime) or now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("now must be a timezone-aware datetime")
    utc_day = now.astimezone(timezone.utc).date()
    equity = _finite_decimal(current_equity, "current_equity")
    pct = _finite_decimal(daily_loss_alert_pct, "daily_loss_alert_pct")
    if not Decimal(0) < pct <= Decimal(100):
        raise ValueError("daily_loss_alert_pct must be greater than 0 and at most 100")
    if state is not None and (not isinstance(state, DailyAlertState)
                              or type(state.utc_day) is not date
                              or type(state.alerted) is not bool
                              or not isinstance(state.day_start_equity, Decimal)
                              or not state.day_start_equity.is_finite()
                              or state.day_start_equity <= 0):
        raise ValueError("Invalid daily alert state")
    if state is not None and utc_day < state.utc_day:
        raise ValueError("UTC clock moved backwards; do not reset the alert")
    is_new_day = state is None or state.utc_day != utc_day
    if is_new_day:
        if verified_day_start_equity is None:
            raise MissingDayStartEquity("A verified UTC day-start equity is required before evaluating the alert")
        start = _finite_decimal(verified_day_start_equity, "verified_day_start_equity")
        if start <= 0:
            raise ValueError("Day-start equity must be positive")
        already_alerted = False
    else:
        start = state.day_start_equity
        already_alerted = state.alerted
        if verified_day_start_equity is not None and _finite_decimal(verified_day_start_equity, "verified_day_start_equity") != start:
            raise ValueError("Cannot change the day-start baseline within the same UTC day")
    threshold = start * (Decimal(1) - pct / Decimal(100))
    at_threshold = equity <= threshold
    alerted = already_alerted or at_threshold
    newly_alerted = at_threshold and not already_alerted
    state_out = DailyAlertState(utc_day, start, alerted)
    drawdown_pct = max(Decimal(0), (start - equity) / start * Decimal(100))
    decision = {
        "utc_day": utc_day.isoformat(), "day_start_equity": float(start),
        "current_equity": float(equity), "loss_alert_pct": float(pct),
        "alert_equity_threshold": float(threshold), "equity_drawdown_pct": float(drawdown_pct),
        "alerted_today": alerted, "new_alert_requested": newly_alerted,
        "request_close_positions_due_to_daily_alert": False,
        "block_new_bot_entries_due_to_daily_alert": False,
    }
    return state_out, decision
