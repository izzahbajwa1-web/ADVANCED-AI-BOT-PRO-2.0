import unittest
from core.strategy import Bar, find_setup, confirm_flow
from core.flow import FlowCollector, WINDOW_MS

class StrategyTests(unittest.TestCase):
    def test_long_example_on_closed_bars(self):
        bars = [Bar(1,100,101,99,100),Bar(2,100,102,98,100),Bar(3,100,101,99,100),
                Bar(4,99,103,97,99),Bar(5,104,106,102,105)]
        result=find_setup(bars,2)
        self.assertEqual(result['direction'],'BUY')
        self.assertEqual(result['sweep_extreme'],97)
        self.assertEqual((result['fvg_low'],result['fvg_high']),(101,102))

    def test_short_example(self):
        bars = [Bar(1,100,101,99,100),Bar(2,100,102,98,100),Bar(3,100,101,99,100),
                Bar(4,101,103,100,101),Bar(5,97,98,96,97)]
        self.assertEqual(find_setup(bars,2)['direction'],'SELL')
        bars[-1]=Bar(5,97,98,96,97,False)
        with self.assertRaises(ValueError): find_setup(bars,2)

    def test_confirmation_requires_usable_aligned_flow(self):
        self.assertFalse(confirm_flow('BUY', {'usable':False,'imbalance':.4,'delta':2}))
        self.assertTrue(confirm_flow('BUY', {'usable':True,'imbalance':.4,'delta':2}))
        self.assertFalse(confirm_flow('BUY', {'usable':True,'imbalance':-.4,'delta':2}))
        self.assertTrue(confirm_flow('SELL', {'usable':True,'imbalance':-.4,'delta':-2}))

class FlowTests(unittest.TestCase):
    def setUp(self):
        self.t=1_800_000_000_000
        self.collector=FlowCollector()
    def event(self, typ, ts, **kw):
        return {'platform':'bookmap','provider':'Provider','instrument':'GC-test',
                'type':typ,'timestamp_ms':ts,'timestamp_origin':'test_clock','declared_live':True,**kw}
    def book(self,ts):
        return self.event('book',ts,bids=[[100,9],[99,1]],asks=[[101,3],[102,2]])
    def trade(self,ts, side='buy', continuity='ok'):
        return self.event('trades',ts,continuity=continuity,
             trades=[{'timestamp_ms':ts,'price':100.5,'size':4,'aggressor':side}])
    def test_warmup_then_fresh_then_stale(self):
        self.collector.accept(self.book(self.t),self.t)
        self.collector.accept(self.trade(self.t),self.t)
        self.assertFalse(self.collector.summaries(self.t)[0]['usable'])
        later=self.t+WINDOW_MS
        self.collector.accept(self.book(later),later)
        self.collector.accept(self.trade(later),later)
        summary=self.collector.summaries(later)[0]
        self.assertTrue(summary['usable'])
        self.assertGreater(summary['imbalance'],0)
        self.assertGreater(summary['delta'],0)
        self.assertFalse(self.collector.summaries(later+6000)[0]['usable'])
    def test_gap_and_unknown_fail_closed(self):
        self.collector.accept(self.book(self.t),self.t)
        self.collector.accept(self.trade(self.t),self.t)
        later=self.t+WINDOW_MS
        self.collector.accept(self.book(later),later)
        self.collector.accept(self.trade(later,'unknown','gap'),later)
        self.assertFalse(self.collector.summaries(later)[0]['usable'])
        self.assertTrue(self.collector.summaries(later)[0]['gap'])
    def test_bad_data_never_accepted(self):
        with self.assertRaises(ValueError): self.collector.accept({**self.book(self.t),'declared_live':False},self.t)
        with self.assertRaises(ValueError): self.collector.accept({**self.book(self.t),'bids':[[102,3]]},self.t)
        with self.assertRaises(ValueError): self.collector.accept({**self.book(self.t),'timestamp_ms':self.t-120001},self.t)
        with self.assertRaises(ValueError): self.collector.accept({**self.trade(self.t),'trades':[{'timestamp_ms':self.t,'price':0,'size':1,'aggressor':'buy'}]},self.t)
        self.assertEqual(self.collector.summaries(self.t),[])

if __name__ == '__main__': unittest.main()
