import unittest
from core.staged_strategy import plan_staged_lots, proposed_sweep_stop, analyze_sequence
from core.higher_timeframe import structure_bias, combined_bias
from core.strategy import Bar


def candle(t,o,h,l,c): return Bar(t,o,h,l,c)


def staged_bars(side='BUY'):
    ts=1_800_000_000_000; unit=300_000
    bars=[candle(ts+i*unit,100,102,98,100) for i in range(12)]
    if side=='BUY':
        bars += [candle(ts+12*unit,100,101,97,99), candle(ts+13*unit,99,101,98,100),
                 candle(ts+14*unit,100,103,99,102), candle(ts+15*unit,102,104,100,103),
                 candle(ts+16*unit,105,107,104,106)]
    else:
        bars += [candle(ts+12*unit,100,103,99,101), candle(ts+13*unit,101,102,99,100),
                 candle(ts+14*unit,100,101,97,98), candle(ts+15*unit,98,100,96,97),
                 candle(ts+16*unit,95,96,93,94)]
    return bars


class StagedLotTests(unittest.TestCase):
    def plan(self, lots):
        return plan_staged_lots(tier=lots,minimum=.01,maximum=10,step=.01)
    def test_split_tiers_with_first_no_larger(self):
        for tier,first,second in ((.02,.01,.01),(.03,.01,.02),(.04,.02,.02),(.05,.02,.03)):
            with self.subTest(tier=tier):
                r=self.plan(tier)
                self.assertEqual((r['first_lots'],r['second_lots'],r['combined_lots']),(first,second,tier))
                self.assertFalse(r['extra_over_tier'])
    def test_authorized_small_tier_exception(self):
        r=self.plan(.01)
        self.assertEqual((r['first_lots'],r['second_lots'],r['combined_lots']),(.01,.01,.02))
        self.assertTrue(r['extra_over_tier'])
    def test_other_unresolved_broker_grids_never_round_up(self):
        for args in (dict(tier=.01,minimum=.02,maximum=1,step=.01),
                     dict(tier=.03,minimum=.02,maximum=1,step=.01),
                     dict(tier=.05,minimum=.01,maximum=.02,step=.01)):
            r=plan_staged_lots(**args)
            self.assertEqual(r['status'],'UNRESOLVED_BROKER_VOLUME')
            self.assertIsNone(r['first_lots']);self.assertIsNone(r['second_lots'])
    def test_proposed_stop_is_beyond_sweep(self):
        self.assertEqual(proposed_sweep_stop(side='BUY',sweep_extreme=100,tick_size=.05),99.95)
        self.assertEqual(proposed_sweep_stop(side='SELL',sweep_extreme=100,tick_size=.05),100.05)
        self.assertEqual(proposed_sweep_stop(side='BUY',sweep_extreme=100.023,tick_size=.05),99.95)
        with self.assertRaises(ValueError): proposed_sweep_stop(side='BUY',sweep_extreme=100,tick_size=0)


class SequenceTests(unittest.TestCase):
    def test_sweep_then_later_directional_bos_without_fvg(self):
        bars=staged_bars('BUY')[:15]
        r=analyze_sequence(bars)
        self.assertEqual(r['direction'],'BUY');self.assertEqual(r['phase'],'BOS_RESEARCH')
        self.assertTrue(r['bos_is_latest_closed']); self.assertIsNone(r['fvg'])
        self.assertEqual(r['sweep_extreme'],97)
    def test_fvg_retest_requires_fresh_quote_after_formation(self):
        bars=staged_bars('BUY'); formed=bars[-1].timestamp_ms+300_000
        r=analyze_sequence(bars,quote={'timestamp_ms':formed,'bid':103.4,'ask':103.5},now_ms=formed+100)
        self.assertEqual(r['direction'],'BUY');self.assertEqual((r['fvg']['low'],r['fvg']['high']),(103,104))
        self.assertTrue(r['retest_observed']);self.assertEqual(r['phase'],'FVG_RETEST_RESEARCH')
        early=analyze_sequence(bars,quote={'timestamp_ms':formed-1,'bid':103.4,'ask':103.5},now_ms=formed)
        self.assertIsNone(early['retest_observed'])
        stale=analyze_sequence(bars,quote={'timestamp_ms':formed,'bid':103.4,'ask':103.5},now_ms=formed+5001)
        self.assertIsNone(stale['retest_observed'])
        outside=analyze_sequence(bars,quote={'timestamp_ms':formed,'bid':104.8,'ask':104.9},now_ms=formed+100)
        self.assertFalse(outside['retest_observed'])
    def test_short_uses_bid_and_above_sweep_stop(self):
        bars=staged_bars('SELL'); formed=bars[-1].timestamp_ms+300_000
        r=analyze_sequence(bars,quote={'timestamp_ms':formed,'bid':96.5,'ask':96.6},now_ms=formed)
        self.assertEqual(r['direction'],'SELL');self.assertEqual(r['sweep_extreme'],103)
        self.assertEqual((r['fvg']['low'],r['fvg']['high']),(96,97));self.assertTrue(r['retest_observed'])
        self.assertGreater(proposed_sweep_stop(side='SELL',sweep_extreme=r['sweep_extreme'],tick_size=.01),103)
    def test_doji_or_wrong_direction_does_not_confirm(self):
        bars=staged_bars('BUY')[:15]
        bars[-1]=candle(bars[-1].timestamp_ms,102,103,99,102) # doji
        self.assertIsNone(analyze_sequence(bars))
        bars[-1]=candle(bars[-1].timestamp_ms,103,104,99,102) # bearish
        self.assertIsNone(analyze_sequence(bars))
    def test_unclosed_or_out_of_order_candles_rejected(self):
        bars=staged_bars()[:15]
        bars[-1]=Bar(bars[-1].timestamp_ms,100,103,99,102,False)
        with self.assertRaises(ValueError):analyze_sequence(bars)


class BiasTests(unittest.TestCase):
    def bars(self,invert=False):
        vals=[10,11,14,11,9,10,15,12,10,11,16,13,11,12,17,14,12]
        if invert: vals=[30-v for v in vals]
        return [Bar(i+1,x,x+.5,x-.5,x) for i,x in enumerate(vals)]
    def test_confirmed_higher_highs_and_higher_lows(self):
        self.assertEqual(structure_bias(self.bars())['bias'],'BULLISH')
        self.assertEqual(structure_bias(self.bars(True))['bias'],'BEARISH')
        self.assertEqual(combined_bias(self.bars(),self.bars())['consensus'],'BULLISH')
        self.assertEqual(combined_bias(self.bars(),self.bars(True))['consensus'],'MIXED_OR_INSUFFICIENT')
    def test_insufficient_is_not_fabricated(self):
        self.assertEqual(structure_bias([])['bias'],'INSUFFICIENT')
        self.assertEqual(structure_bias(self.bars()[:3])['bias'],'INSUFFICIENT')

if __name__ == '__main__': unittest.main()
