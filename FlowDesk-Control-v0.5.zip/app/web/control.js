(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const txt = (id, value) => { $(id).textContent = value; };
  const node = (tag, cls, value) => { const n = document.createElement(tag); if (cls) n.className = cls; if (value !== undefined) n.textContent = String(value); return n; };
  let state = null, marketData = null, marketLimit = 60, settingInitialized = false, refreshing = false;
  async function get(path) {
    const response = await fetch(path, {cache:'no-store'});
    if (!response.ok) throw new Error('Could not load FlowDesk state.');
    return response.json();
  }
  async function post(path, data) {
    const response = await fetch(path, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data), cache:'no-store'});
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Request failed.');
    return result;
  }
  function renderBot(bot) {
    const plan = bot.plan || {};
    txt('summaryBooking', `${Number(plan.book_percent ?? 50)}% at +${Number(plan.book_at_r ?? 2)}R`);
    if (!settingInitialized) {
      $('settingsForm').elements.book_at_r.value = plan.book_at_r ?? 2;
      $('settingsForm').elements.book_percent.value = plan.book_percent ?? 50;
      settingInitialized = true;
    }
    const box = $('blockers'); box.replaceChildren();
    for (const item of bot.blockers || []) {
      const row = node('div','blocker'); row.append(node('i','', '!'),node('span','',item)); box.append(row);
    }
    if (!box.childElementCount) box.append(node('p','muted','No readiness data. Execution is still locked.'));
  }
  function renderMarket() {
    const list=$('marketList'); list.replaceChildren();
    if (!marketData || marketData.status !== 'RECEIVED_UNVERIFIED') {
      txt('marketCount','—'); txt('marketFoot',marketData?.message || 'Connect MT5 to load symbols');
      $('moreMarkets').hidden=true; list.append(node('p','empty',marketData?.message || 'Connect MT5 to view your Market Watch.')); return;
    }
    const symbols=marketData.symbols || [];
    const q=$('marketSearch').value.trim().toLowerCase();
    const matches=symbols.filter(m=>`${m.symbol} ${m.broker_group} ${m.description}`.toLowerCase().includes(q));
    txt('marketCount',symbols.length); txt('marketFoot',`Showing ${Math.min(matches.length, marketLimit)} of ${matches.length} matching symbols`);
    if (!matches.length) list.append(node('p','empty',symbols.length ? 'No matching symbols.' : 'No visible symbols in MT5 Market Watch.'));
    for (const m of matches.slice(0, marketLimit)) {
      const row=node('div','market-row'); row.append(node('strong','',m.symbol),node('small','',m.broker_group || m.description || 'MT5 symbol')); list.append(row);
    }
    $('moreMarkets').hidden=matches.length<=marketLimit;
  }
  function renderPositions(data) {
    const body=$('positionRows'); body.replaceChildren();
    if (!data || data.status !== 'READ_ONLY') {
      txt('positionCount','—'); const tr=node('tr'); const td=node('td','empty',data?.message || 'Connect MT5 to view positions.'); td.colSpan=4; tr.append(td); body.append(tr); return;
    }
    const rows=data.positions || []; txt('positionCount',rows.length);
    if (!rows.length) {const tr=node('tr'); const td=node('td','empty','No open positions returned by MT5.'); td.colSpan=4; tr.append(td); body.append(tr); return;}
    for (const p of rows) {
      const tr=node('tr');
      tr.append(node('td','',p.symbol),node('td','',p.side),node('td','',p.volume ?? '—'),node('td','',typeof p.profit==='number' ? p.profit.toFixed(2) : '—')); body.append(tr);
    }
  }
  function renderDaily(d) {
    const box=$('dailyStatus'); box.classList.toggle('alert',d.status==='ALERT');
    txt('dailyBadge',d.status === 'MONITORING' ? 'MONITORING' : d.status === 'ALERT' ? 'ALERT' : d.status === 'ERROR' ? 'ERROR' : 'WAITING');
    let detail=d.message || 'Waiting for daily alert status.';
    if (typeof d.day_start_equity==='number' && typeof d.current_equity==='number') detail += ` Start ${d.day_start_equity} · current ${d.current_equity} · alert at ${d.alert_equity_threshold}.`;
    box.textContent=detail;
  }
  function renderScan(scan) {
    txt('scanBadge', (scan.status || 'STOPPED').replaceAll('_',' '));
    txt('scanProgress', `${scan.scanned || 0} of ${scan.total || 0} symbols checked in this cycle`);
    txt('scanMessage', scan.message || 'Research scanner is stopped.');
    const box=$('scanResults');box.replaceChildren();const signals=scan.signals || [];
    if (!signals.length) box.append(node('p','empty','No research observations in this cycle.'));
    for (const item of signals) {
      const row=node('div','scan-row');const label=node('strong','',`${item.symbol} · ${item.direction} · ${String(item.phase || '').replaceAll('_',' ')}`);
      row.append(label,node('small','','No 90% model · not executable'));box.append(row);
    }
  }
  function renderAccount(account) {
    txt('accountBadge',account ? 'MT5 CONNECTED · READ ONLY' : 'MT5 DISCONNECTED');
    txt('accountDetail',account ? `Connected account: ${account.login ?? 'unknown'} · ${account.server || 'unknown server'}. Verify inside MT5.` : 'No MT5 account connected.');
  }
  async function refresh() {
    if (refreshing) return;
    refreshing = true;
    try {
      const results = await Promise.allSettled([get('/api/state'),get('/api/market-watch'),get('/api/positions'),get('/api/research-scan')]);
      if (results[0].status==='fulfilled') {state=results[0].value;renderBot(state.bot_control || {});renderDaily(state.daily_alert || {});renderAccount(state.mt5?.account || null);}
      if (results[1].status==='fulfilled') {marketData=results[1].value;renderMarket();}
      if (results[2].status==='fulfilled') renderPositions(results[2].value);
      if (results[3].status==='fulfilled') renderScan(results[3].value);
    } finally { refreshing=false; }
  }
  $('startScan').onclick=async()=>{try{const result=await post('/api/research-scan/start',{});if(result.started){await refresh();}else{txt('scanMessage',result.message);}}catch(e){txt('scanMessage',e.message);}};
  $('stopScan').onclick=async()=>{try{const result=await post('/api/research-scan/stop',{});txt('scanMessage',result.message);await refresh();}catch(e){txt('scanMessage',e.message);}};
  $('marketSearch').addEventListener('input',()=>{marketLimit=60;renderMarket();});
  $('moreMarkets').onclick=()=>{marketLimit+=60;renderMarket();};
  $('checkStart').onclick=async()=>{try {const result=await post('/api/bot/start',{});renderBot(result);txt('settingsMessage','Bot not started; see readiness blockers.');}catch(e){txt('settingsMessage',e.message);}};
  $('stopBot').onclick=async()=>{try {const result=await post('/api/bot/stop',{});renderBot(result);txt('settingsMessage',result.message);}catch(e){txt('settingsMessage',e.message);}};
  $('settingsForm').onsubmit=async e=>{e.preventDefault(); const f=e.currentTarget; const b=f.querySelector('button[type=submit]'); b.disabled=true;txt('settingsMessage','');try {await post('/api/bot/settings',{book_at_r:Number(f.elements.book_at_r.value),book_percent:Number(f.elements.book_percent.value)});txt('settingsMessage','Saved as a research preference; no trades are managed.');await refresh();}catch(err){txt('settingsMessage',err.message);}finally{b.disabled=false;}};
  $('dailyForm').onsubmit=async e=>{e.preventDefault();const f=e.currentTarget;const b=f.querySelector('button[type=submit]');b.disabled=true;txt('dailyMessage','');try {await post('/api/daily/baseline',{day_start_equity:Number(f.elements.equity.value),verified:f.elements.verified.checked});txt('dailyMessage','Baseline saved for this account and UTC day.');f.elements.verified.checked=false;await refresh();}catch(err){txt('dailyMessage',err.message);}finally{b.disabled=false;}};
  $('brokerForm').onsubmit=async e=>{e.preventDefault();const f=e.currentTarget;const b=f.querySelector('button[type=submit]');b.disabled=true;txt('brokerMessage','Checking with MT5…');try {const result=await post('/api/broker/check',{symbol:f.elements.symbol.value.trim(),side:f.elements.side.value,volume:f.elements.volume.value,stop_loss:f.elements.stop_loss.value,fill_policy:f.elements.fill_policy.value,confirm_account:f.elements.confirm_account.checked});txt('brokerMessage',`${result.message} Estimated margin: ${result.margin_estimate}.`);}catch(err){txt('brokerMessage',`Check failed: ${err.message}`);}finally{b.disabled=false;}};
  refresh(); setInterval(refresh,5000);
})();
