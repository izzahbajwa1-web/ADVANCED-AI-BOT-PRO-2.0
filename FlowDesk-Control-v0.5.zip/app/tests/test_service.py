import tempfile
import time
import unittest
from pathlib import Path
from core.service import DeskService
from core.strategy import Bar

class FakeReader:
    def __init__(self, bars, account=None): self._bars=bars; self.account=account
    def snapshot(self, symbols):
        return {'connected':True,'message':'test reader','account':self.account,'quotes':[]}
    def bars(self, symbol, count=30, timeframe="M5"): return self._bars if timeframe == "M5" else []

class ServiceTests(unittest.TestCase):
    def setup_service(self, age=300_000):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        desk=DeskService(Path(temp.name)/'config.json')
        desk.add_mapping({'mt5_symbol':'XAUUSDr','platform':'bookmap','provider':'test-provider',
            'instrument':'test-contract','is_proxy':True,'reviewed':True})
        now=int(time.time()*1000)
        t=now-age-14*300_000
        bars=[Bar(t+i*300_000,100,102,98,100) for i in range(12)]
        bars += [Bar(t+12*300_000,100,101,99,100), Bar(t+13*300_000,99,102,97,99),
                 Bar(t+14*300_000,104,106,102,105)]
        desk.reader=FakeReader(bars)
        return desk, now
    def test_research_setup_never_claims_execution(self):
        desk, _=self.setup_service()
        state=desk.state()
        self.assertEqual(len(state['signals']),1)
        self.assertFalse(state['signals'][0]['flow_confirmed'])
        self.assertFalse(state['execution']['implemented'])
        self.assertFalse(state['risk_enforced'])
        self.assertEqual(state['risk']['daily_loss_action'], 'alert_only')
        self.assertEqual(state['risk']['daily_loss_alert_pct'], 10)
        self.assertFalse(state['qualification_gate']['eligible'])
        self.assertFalse(state['signals'][0]['qualification']['eligible'])
        self.assertIsNone(state['lot_sizing_preview']['indicative_lots'])
    def test_stale_candles_do_not_create_setups(self):
        desk, _=self.setup_service(age=20*60_000)
        self.assertEqual(desk.state()['signals'],[])
    def test_selected_fresh_source_aligns_after_warmup(self):
        desk, now=self.setup_service()
        def book(t):
            return {'type':'book','platform':'bookmap','provider':'test-provider','instrument':'test-contract',
                    'timestamp_ms':t,'timestamp_origin':'fixture','declared_live':True,
                    'bids':[[100,10]],'asks':[[101,1]]}
        def trade(t):
            return {'type':'trades','platform':'bookmap','provider':'test-provider','instrument':'test-contract',
                    'timestamp_ms':t,'timestamp_origin':'fixture','declared_live':True,'continuity':'ok',
                    'trades':[{'timestamp_ms':t,'price':100.5,'size':4,'aggressor':'buy'}]}
        desk.collector.accept(book(now-31_000),now-31_000)
        desk.collector.accept(trade(now-31_000),now-31_000)
        desk.collector.accept(book(now),now)
        desk.collector.accept(trade(now),now)
        result=desk.state()
        self.assertTrue(result['signals'][0]['flow_confirmed'])
        self.assertFalse(result['execution']['implemented'])
        self.assertFalse(result['signals'][0]['qualification']['eligible'])

    def test_lot_preview_uses_balance_not_equity_and_rejects_non_usd(self):
        desk, _=self.setup_service()
        desk.reader.account={'balance':500,'equity':100,'profit':-400,'currency':'USD'}
        preview=desk.state()['lot_sizing_preview']
        self.assertEqual(preview['indicative_lots'], .03)
        self.assertFalse(preview['broker_volume_checked'])
        desk.reader.account={'balance':500,'equity':10000,'profit':9500,'currency':'EUR'}
        preview=desk.state()['lot_sizing_preview']
        self.assertIsNone(preview['indicative_lots'])
        self.assertIn('USD',preview['reason'])
        desk.reader.account={'balance':0,'equity':500,'profit':500,'currency':'USD'}
        self.assertIsNone(desk.state()['lot_sizing_preview']['indicative_lots'])

    def test_context_symbol_saved_without_assuming_provider_or_enabling_orders(self):
        desk, _=self.setup_service()
        result=desk.save_market_context({'dxy_symbol':'USD-INDEX-TEST'})
        self.assertEqual(result['dxy_symbol'],'USD-INDEX-TEST')
        state=desk.state()
        self.assertEqual(state['dollar_index']['symbol'],'USD-INDEX-TEST')
        self.assertIsNone(state['dollar_index']['quote'])
        self.assertTrue(state['execution']['hard_locked'])
        self.assertFalse(state['execution']['implemented'])
        self.assertFalse(state['qualification_gate']['eligible'])
        self.assertEqual(desk.config.read()['watchlist'],['XAUUSDr'])
        desk.save_market_context({'dxy_symbol':''})
        self.assertIsNone(desk.state()['dollar_index']['symbol'])
        with self.assertRaises(ValueError): desk.save_market_context({'dxy_symbol':'A\nB'})
        with self.assertRaises(ValueError): desk.save_market_context({'dxy_symbol':'ABC','key':'never-store'})

    def test_staged_settings_include_confirmed_small_tier_exception(self):
        desk, _=self.setup_service()
        state=desk.state(); staging=state['staging']
        self.assertEqual(staging['first_entry'],'market_after_sweep_bos_directional_close')
        self.assertEqual(staging['second_entry'],'market_on_fvg_retest')
        self.assertEqual(staging['small_tier_exception']['first_lots'],.01)
        self.assertEqual(staging['small_tier_exception']['second_lots'],.01)
        self.assertIsNone(staging['stop_buffer_ticks'])
        self.assertEqual(state['economic_calendar']['events'],[])

if __name__=='__main__': unittest.main()
