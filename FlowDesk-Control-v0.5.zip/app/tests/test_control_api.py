import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from unittest.mock import patch
from core import server
from core.service import DeskService
from test_calendar_execution import FakeMT5Preflight


class APIFakeMT5(FakeMT5Preflight):
    POSITION_TYPE_BUY=0;POSITION_TYPE_SELL=1
    def __init__(self):
        super().__init__()
        self.account.balance=1000;self.account.equity=1000;self.account.profit=0
        self.tick.time_msc=int(time.time()*1000)
    def symbols_get(self):return [SimpleNamespace(name='XAU-test',visible=True,path='Mock',description='Mock')]
    def positions_get(self):return []


class ControlAPITests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.service=DeskService(Path(self.tmp.name)/'config.json')
        self.mt5=APIFakeMT5();self.service.reader._mt5=self.mt5
        self.patch_s=patch.object(server,'SERVICE',self.service);self.patch_s.start();self.addCleanup(self.patch_s.stop)
        self.patch_p=patch.object(server,'PREVIEW',False);self.patch_p.start();self.addCleanup(self.patch_p.stop)
        self.httpd=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
        self.thread=threading.Thread(target=self.httpd.serve_forever,daemon=True);self.thread.start()
        self.addCleanup(self.close_http)
        self.base=f'http://127.0.0.1:{self.httpd.server_port}'
    def close_http(self):
        self.httpd.shutdown();self.httpd.server_close();self.thread.join(timeout=2)
    def get(self,path,headers=None):
        with urlopen(Request(self.base+path,headers=headers or {}),timeout=5) as r:return json.load(r)
    def post(self,path,data,headers=None):
        headers={'Content-Type':'application/json',**(headers or {})}
        with urlopen(Request(self.base+path,data=json.dumps(data).encode(),headers=headers,method='POST'),timeout=5) as r:return json.load(r)
    def test_live_style_control_requests_never_send_or_manage_orders(self):
        state=self.get('/api/state');self.assertTrue(state['mt5']['connected'])
        self.assertTrue(state['execution']['hard_locked'])
        self.assertEqual(self.get('/api/market-watch')['symbols'][0]['symbol'],'XAU-test')
        self.assertEqual(self.get('/api/positions')['positions'],[])
        result=self.post('/api/bot/start',{});self.assertFalse(result['started']);self.assertTrue(result['real_orders_locked'])
        saved=self.post('/api/bot/settings',{'book_at_r':3,'book_percent':50})
        self.assertEqual(saved['book_at_r'],3)
        check=self.post('/api/broker/check',{'symbol':'XAU-test','side':'BUY','volume':.01,'stop_loss':99,
                                             'fill_policy':'IOC','confirm_account':True})
        self.assertTrue(check['checked']);self.assertEqual(len(self.mt5.checks),1)
        self.post('/api/bot/stop',{})
        self.assertEqual(self.mt5.sent,[])
        with self.assertRaises(HTTPError) as e:self.post('/api/order',{})
        self.assertEqual(e.exception.code,404);self.assertEqual(self.mt5.sent,[])
    def test_daily_alert_on_verified_equity_is_alert_only(self):
        self.post('/api/daily/baseline',{'day_start_equity':1000,'verified':True})
        self.mt5.account.equity=900;result=self.service.poll_daily_alert()
        self.assertEqual(result['status'],'ALERT')
        self.assertFalse(result['stops_trading']);self.assertFalse(result['closes_positions']);self.assertEqual(self.mt5.sent,[])
    def test_cross_origin_and_host_are_rejected(self):
        with self.assertRaises(HTTPError) as e:self.post('/api/bot/start',{},headers={'Origin':'https://other.example'})
        self.assertEqual(e.exception.code,403)
        with self.assertRaises(HTTPError) as e:self.get('/api/bot/status',headers={'Host':'other.example'})
        self.assertEqual(e.exception.code,403)
        self.assertEqual(self.mt5.sent,[])

if __name__=='__main__':unittest.main()
