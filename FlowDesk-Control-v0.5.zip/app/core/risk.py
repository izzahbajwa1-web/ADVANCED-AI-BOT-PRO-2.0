"""User-selected USD account-balance tiers; no orders or margin checks."""
from __future__ import annotations
from decimal import Decimal, InvalidOperation


class UnsupportedAccountCurrency(ValueError):
    """The confirmed ladder applies only to a USD-denominated account."""


def _decimal(value, name):
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a finite number")
    try:
        val = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError(f"{name} must be a finite number") from None
    if not val.is_finite():
        raise ValueError(f"{name} must be a finite number")
    return val


def lots_from_usd_balance(*, account_balance, account_currency):
    """Return the selected tier for a new trade, or None for nonpositive balance.

    USD balance <200 -> 0.01; [200,500) -> 0.02; [500,600) -> 0.03;
    [600,700) -> 0.04; [700,infinity) -> 0.05. Floating P/L is excluded.
    The function does not prove the broker accepts the size or has margin.
    """
    if not isinstance(account_currency, str) or account_currency.upper() != "USD":
        raise UnsupportedAccountCurrency("Lot tiers require a USD-denominated account; no automatic conversion is configured")
    balance = _decimal(account_balance, "account_balance")
    if balance <= 0:
        return None
    if balance < Decimal('200'):
        return 0.01
    if balance < Decimal('500'):
        return 0.02
    if balance < Decimal('600'):
        return 0.03
    if balance < Decimal('700'):
        return 0.04
    return 0.05


def broker_accepts_exact_volume(*, volume, minimum, maximum, step):
    """Check the tier against supplied broker volume min/max/step only.

    Reject incompatible tiers instead of silently increasing or decreasing
    them. This does not check margin, trading permissions or stop distances.
    """
    volume, minimum, maximum, step = [_decimal(v, name) for v, name in
                                      ((volume, "volume"), (minimum, "minimum"),
                                       (maximum, "maximum"), (step, "step"))]
    if minimum <= 0 or maximum < minimum or step <= 0:
        raise ValueError("Invalid broker volume specification")
    if volume < minimum or volume > maximum:
        return False
    return (volume - minimum) % step == 0
