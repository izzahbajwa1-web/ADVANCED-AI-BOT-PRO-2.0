@echo off
setlocal
title FlowDesk VPS - Research and Read-Only
cd /d "%~dp0"

if not exist "runtime\python.exe" (
  echo ERROR: The included Python runtime was not found.
  echo First right-click the ZIP and choose Extract All. Then open the extracted
  echo FlowDesk-VPS folder and double-click START-FLOWDESK again.
  echo Do not run this file from inside the ZIP.
  echo.
  pause
  exit /b 1
)
if not exist "app\starter.py" (
  echo ERROR: The FlowDesk application files are missing.
  echo Extract the complete ZIP again before starting.
  echo.
  pause
  exit /b 1
)

"runtime\python.exe" -u "app\starter.py"
set "FLOW_RESULT=%ERRORLEVEL%"
echo.
if not "%FLOW_RESULT%"=="0" (
  echo FlowDesk could not start. Please read the error above or START-HERE.txt.
) else (
  echo FlowDesk stopped.
)
echo.
pause
exit /b %FLOW_RESULT%
