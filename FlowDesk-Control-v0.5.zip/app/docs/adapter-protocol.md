# Normalized adapter protocol — experimental, read-only

The dashboard server accepts book snapshots and signed trades at `POST /api/bridge/events`, only on `127.0.0.1`, only when a `FLOW_GATEWAY_TOKEN` of at least 16 characters is set before server startup, and only with `Authorization: Bearer <token>`. Use HTTPS/strong authentication in any future non-local design; this prototype intentionally forbids non-loopback binds outside the isolated preview. Never send broker login credentials.

The included Bookmap sender is experimental. **No native Quantower or ATAS sender is included.** This protocol exists so those platform-specific add-ons can be built later against the correct SDK and tested with the user's actual feeds.

## Envelope

Common fields:

- `platform`: `bookmap`, `quantower`, or `atas`.
- `provider`: actual provider name/label (must exactly match the manually configured mapping).
- `instrument`: exact feed instrument or platform alias (must exactly match the mapping).
- `type`: `book` or `trades`.
- `timestamp_ms`: UTC epoch milliseconds from the declared source clock; no more than 2 seconds in the future or 120 seconds old at receipt.
- `timestamp_origin`: a stable description of the clock for the stream; origin changes are rejected. A platform clock is not necessarily an exchange timestamp.
- `declared_live`: must be boolean `true`. **This is an assertion, not independent proof that the feed is live.**

For `book`, add `bids` and `asks`, each an array of `[price, size]` pairs. Send 1–50 positive, unique-price levels per side. The receiver sorts them and rejects a locked or crossed book. The imbalance uses only the first five levels.

For `trades`, add `continuity` (`ok` or `gap`) and a `trades` array of 1–500 objects: `timestamp_ms`, `price`, `size`, and `aggressor` (`buy`, `sell`, or `unknown`). Timestamps must be nondecreasing, and the envelope timestamp must equal the final trade's timestamp. Do not invent aggressor direction when the provider does not supply it. A sender must report `gap` after a dropped buffer, transport failure, reconnect or any other known missing data.

The receiver calculates 30-second buy volume minus sell volume for each source independently. It will not mark a stream usable until it has a 30-second warm-up, a book and last trade no older than five seconds according to both source and receiver clocks, no known recent gap, and no unknown aggressor volume in the window. There is a bounded trade buffer; overflow marks the stream incomplete. These checks **do not prove continuity** and are not a production-grade ingestion system. A single live event cannot authenticate its true market source.

This prototype stores stream state and session logs only in memory. Restarting clears data. Do not connect untrusted senders or expose this endpoint externally.
