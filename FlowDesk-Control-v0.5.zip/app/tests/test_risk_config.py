import json
import tempfile
import unittest
from pathlib import Path

from core.risk import lots_from_usd_balance, broker_accepts_exact_volume, UnsupportedAccountCurrency
from core.config import ConfigStore, validate_risk


class BalanceLotTests(unittest.TestCase):
    def lots(self, balance, currency='USD'):
        return lots_from_usd_balance(account_balance=balance, account_currency=currency)

    def test_balance_tiers_and_exact_boundaries(self):
        examples = [(0.01, .01), (100, .01), (199.999, .01),
                    (200, .02), (300, .02), (499.999, .02),
                    (500, .03), (599.999, .03),
                    (600, .04), (699.999, .04),
                    (700, .05), (1000, .05), (1_000_000, .05)]
        for balance, expected in examples:
            with self.subTest(balance=balance):
                self.assertEqual(self.lots(balance), expected)

    def test_nonpositive_balance_and_usd_currency(self):
        self.assertIsNone(self.lots(0))
        self.assertIsNone(self.lots(-10))
        self.assertEqual(self.lots(500, 'usd'), .03)
        for currency in ('EUR', 'USC', '', None):
            with self.subTest(currency=currency), self.assertRaises(UnsupportedAccountCurrency):
                self.lots(500, currency)

    def test_invalid_inputs(self):
        for bad in (True, None, 'abc', float('nan'), float('inf')):
            with self.subTest(balance=bad), self.assertRaises(ValueError):
                self.lots(bad)

    def test_broker_volume_grid_requires_exact_compatibility(self):
        self.assertTrue(broker_accepts_exact_volume(volume=.03, minimum=.01, maximum=2, step=.01))
        self.assertFalse(broker_accepts_exact_volume(volume=.01, minimum=.02, maximum=2, step=.01))
        self.assertFalse(broker_accepts_exact_volume(volume=.04, minimum=.01, maximum=2, step=.02))
        self.assertFalse(broker_accepts_exact_volume(volume=.05, minimum=.01, maximum=.04, step=.01))
        with self.assertRaises(ValueError):
            broker_accepts_exact_volume(volume=.03, minimum=.01, maximum=2, step=0)


class ConfigTests(unittest.TestCase):
    def test_confirmed_policy_and_atomic_save(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'config.json'; store = ConfigStore(p)
            risk = store.read()['risk']
            self.assertEqual(risk['daily_loss_alert_pct'], 10.0)
            self.assertEqual(risk['daily_reset_timezone'], 'UTC')
            self.assertEqual(risk['daily_loss_action'], 'alert_only')
            self.assertIsNone(risk['risk_per_trade_pct'])
            self.assertIsNone(risk['max_open_positions'])
            self.assertEqual(risk['lot_sizing']['mode'], 'usd_balance_tiers')
            self.assertEqual(risk['lot_sizing']['currency'], 'USD')
            self.assertEqual(risk['trailing'], {'activation_r':1.0,'distance_r':1.0,'requires_valid_setup':True})
            self.assertEqual(risk['setup_qualification']['min_probability'], .90)
            self.assertEqual(risk['setup_qualification']['model_status'], 'unconfigured')
            self.assertEqual(risk['invalidation']['rule'], 'opposite_structure_and_orderflow')
            self.assertEqual(risk['invalidation']['action'], 'close_trade')
            store.set_risk({'daily_loss_alert_pct':'10','daily_reset_timezone':'UTC',
                            'daily_loss_action':'alert_only'})
            saved = json.loads(p.read_text())['risk']
            self.assertEqual(saved['daily_loss_alert_pct'], 10.0)
            self.assertEqual(saved['daily_loss_action'], 'alert_only')

    def test_bad_and_old_policies_rejected(self):
        for bad in (0, -1, float('inf'), True, 'abc', None):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                validate_risk({'daily_loss_alert_pct':bad})
        for changes in ({'risk_per_trade_pct':.5}, {'max_open_positions':2},
                        {'daily_reset_timezone':'Asia/Karachi'},
                        {'daily_loss_action':'close_all_and_pause'},
                        {'lot_sizing':{'mode':'unconfigured'}},
                        {'daily_loss_limit_pct':10}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                validate_risk({'daily_loss_alert_pct':10, **changes})

    def test_mapping_requires_review_and_one_source_per_symbol(self):
        with tempfile.TemporaryDirectory() as d:
            store=ConfigStore(Path(d)/'config.json')
            m={'mt5_symbol':'XAUUSDr','platform':'bookmap','provider':'Rithmic','instrument':'GCZ6','is_proxy':True,'reviewed':True}
            with self.assertRaises(ValueError):store.add_mapping({**m,'reviewed':False})
            store.add_mapping(m);store.add_mapping({**m,'platform':'atas'})
            self.assertEqual(len(store.read()['mappings']),1)
            self.assertEqual(store.read()['mappings'][0]['platform'],'atas')
            self.assertEqual(store.read()['watchlist'],['XAUUSDr'])
            store.remove_mapping('XAUUSDr')
            self.assertEqual(store.read()['watchlist'],[])

if __name__ == '__main__': unittest.main()
