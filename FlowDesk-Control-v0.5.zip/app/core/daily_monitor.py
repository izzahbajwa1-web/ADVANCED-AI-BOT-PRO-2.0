"""Account-bound UTC equity alert. It never closes, pauses, or sends orders.

A baseline is entered and explicitly verified by the user for the *current*
connected account and UTC day. The service cannot reconstruct historical
floating equity if it was not running at midnight. No guessed baseline is used.
The alert is displayed in FlowDesk and its session log; there is no external
notification delivery. State is persisted locally so the alert remains latched.
"""
from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
import json
import math
import os
import tempfile
import threading
from pathlib import Path

from .daily_alert import DailyAlertState, evaluate_daily_alert


def _identity(account):
    if not isinstance(account, dict):
        return None
    login, server = account.get("login"), account.get("server")
    if type(login) is not int or login <= 0 or not isinstance(server, str) or not server.strip() or len(server) > 128:
        return None
    return login, server.strip()


def _utc(now):
    if not isinstance(now, datetime) or now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("UTC-aware date and time are required")
    return now.astimezone(timezone.utc)


def _positive(value):
    if isinstance(value, bool):
        raise ValueError("Day-start equity must be a positive finite number")
    try:
        value = float(value)
    except (ValueError, TypeError, OverflowError):
        raise ValueError("Day-start equity must be a positive finite number") from None
    if not math.isfinite(value) or value <= 0:
        raise ValueError("Day-start equity must be a positive finite number")
    return value


class DailyEquityMonitor:
    def __init__(self, path, log):
        self.path = Path(path)
        self.log = log
        self.lock = threading.RLock()
        self.records = {}
        self.corrupt = False
        self.last = {"status": "DISCONNECTED", "message": "Connect MT5 to monitor equity.",
                     "alerted_today": False, "automatic_baseline": False,
                     "stops_trading": False, "closes_positions": False}
        if self.path.exists():
            try:
                loaded = json.loads(self.path.read_text(encoding="utf-8"))
                if not isinstance(loaded, dict) or loaded.get("version") != 1 or not isinstance(loaded.get("baselines"), dict):
                    raise ValueError("Invalid alert file")
                self.records = loaded["baselines"]
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                # Do not discard or overwrite an untrusted/corrupt record.
                self.corrupt = True

    @staticmethod
    def _key(identity, day):
        return json.dumps([identity[0], identity[1], day], ensure_ascii=True, separators=(",", ":"))

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=".flowdesk-day-", suffix=".tmp", dir=self.path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump({"version": 1, "baselines": self.records}, fh, allow_nan=False, indent=2)
                fh.write("\n")
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(name, self.path)
        finally:
            if os.path.exists(name):
                os.remove(name)

    def set_baseline(self, *, account, verified_day_start_equity, verified, now=None):
        if verified is not True:
            raise ValueError("Confirm that this is the connected account's actual UTC day-start equity")
        identity = _identity(account)
        if identity is None:
            raise ValueError("Connect the intended MT5 account before setting a baseline")
        value = _positive(verified_day_start_equity)
        now = _utc(now or datetime.now(timezone.utc))
        day = now.date().isoformat()
        key = self._key(identity, day)
        with self.lock:
            if self.corrupt:
                raise ValueError("Alert state is unreadable. Back it up and contact support before replacing it.")
            prior = self.records.get(key)
            if prior is not None:
                if not isinstance(prior, dict) or prior.get("start") != value:
                    raise ValueError("Today's baseline is already recorded and cannot be replaced automatically")
                return {"saved": True, "utc_day": day, "already_recorded": True}
            self.records[key] = {"start": value, "alerted": False,
                                 "provided_utc": now.isoformat(), "source": "user_verified"}
            try:
                self._save()
            except Exception:
                del self.records[key]
                raise
        self.log("Daily equity alert", "Verified UTC day-start equity recorded for the connected account.")
        return {"saved": True, "utc_day": day, "already_recorded": False}

    def update(self, *, account, daily_loss_alert_pct, now=None):
        now = _utc(now or datetime.now(timezone.utc))
        identity = _identity(account)
        common = {"automatic_baseline": False, "stops_trading": False, "closes_positions": False,
                  "utc_day": now.date().isoformat()}
        if identity is None:
            result = {**common, "status": "DISCONNECTED", "alerted_today": False,
                      "message": "Connect MT5 to monitor equity."}
            with self.lock:
                self.last = result
            return dict(result)
        key = self._key(identity, now.date().isoformat())
        notify = False
        with self.lock:
            if self.corrupt:
                result = {**common, "status": "ERROR", "alerted_today": False,
                          "message": "Saved alert state is unreadable; no alert can be calculated."}
            elif key not in self.records:
                result = {**common, "status": "NEEDS_BASELINE", "alerted_today": False,
                          "message": "Enter the verified UTC day-start equity for this account. No value is guessed."}
            else:
                item = self.records[key]
                try:
                    start = _positive(item["start"])
                    if type(item["alerted"]) is not bool or item.get("source") != "user_verified":
                        raise ValueError("Invalid stored baseline")
                    if isinstance(account.get("equity"), bool) or not math.isfinite(float(account.get("equity"))):
                        raise ValueError("Invalid live equity")
                    state = DailyAlertState(now.date(), Decimal(str(start)), item["alerted"])
                    new_state, decision = evaluate_daily_alert(now=now, current_equity=account["equity"],
                                                                state=state, daily_loss_alert_pct=daily_loss_alert_pct)
                    notify = decision["new_alert_requested"]
                    if notify:
                        item["alerted"] = True
                        try:
                            self._save()
                        except Exception:
                            item["alerted"] = False
                            raise
                    result = {**common, **decision, "status": "ALERT" if new_state.alerted else "MONITORING",
                              "message": ("Daily equity threshold reached. This is an alert only."
                                          if new_state.alerted else "Monitoring against the manually verified UTC baseline.")}
                except (ValueError, TypeError, KeyError, OverflowError, OSError):
                    notify = False
                    result = {**common, "status": "ERROR", "alerted_today": False,
                              "message": "Cannot calculate or save the alert; check the account and local state."}
            self.last = result
        if notify:
            self.log("Daily equity alert", "The daily equity threshold was reached. No trade was closed or blocked.")
        return dict(result)

    def status(self):
        with self.lock:
            return dict(self.last)
