"""MT5 request preparation scaffold with an unconditional live-order lock.

Not connected to the dashboard, scheduler, or MT5 reader. No validated 90%
model, complete invalidation/trailing engine, broker reconciliation, account
identity authorization, order idempotency, or live enable workflow exists.
No supported action in this release can remove this lock. Request dictionaries
are illustrative and MUST NOT be submitted manually to a broker.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from .risk import broker_accepts_exact_volume


class LiveExecutionLocked(RuntimeError):
    pass


class BrokerPreflightRejected(ValueError):
    pass


@dataclass(frozen=True)
class OrderIntent:
    symbol: str
    side: str
    volume: float
    stop_loss: float
    order_kind: str = 'MARKET'
    limit_price: float | None = None
    expiration_utc_s: int | None = None


def _positive(value, name):
    if isinstance(value,bool): raise ValueError(f"{name} must be a positive finite number")
    try: d=Decimal(str(value))
    except (InvalidOperation,ValueError): raise ValueError(f"{name} must be a positive finite number") from None
    if not d.is_finite() or d <= 0: raise ValueError(f"{name} must be a positive finite number")
    return d


def prepare_request(mt5, intent: OrderIntent, *, bid, ask, fill_policy, deviation_points,
                    magic, now_utc_s):
    """Prepare a generic market or expiring limit request, without submitting.

    This helper alone does not perform broker checks. The separate draft
    `preflight` method is mock-tested only and not wired to the application.
    Limit expiry/cancellation and trade management are not implemented.
    """
    if not isinstance(intent,OrderIntent): raise ValueError('OrderIntent is required')
    if not isinstance(intent.symbol,str) or not intent.symbol.strip() or len(intent.symbol)>64:
        raise ValueError('invalid symbol')
    if intent.side not in ('BUY','SELL') or intent.order_kind not in ('MARKET','LIMIT'):
        raise ValueError('invalid side or order kind')
    volume=_positive(intent.volume,'volume'); stop=_positive(intent.stop_loss,'stop_loss')
    b=_positive(bid,'bid'); a=_positive(ask,'ask')
    if b >= a: raise ValueError('bid must be below ask')
    if type(deviation_points) is not int or deviation_points < 0 or type(magic) is not int or magic < 0:
        raise ValueError('invalid deviation or magic')
    if type(now_utc_s) is not int or type(fill_policy) is not int:
        raise ValueError('invalid clock or fill policy')
    request={'symbol':intent.symbol,'volume':float(volume),'sl':float(stop),
             'deviation':deviation_points,'magic':magic,'comment':'FlowDesk research',
             'type_filling':fill_policy}
    if intent.order_kind=='MARKET':
        executable=a if intent.side=='BUY' else b
        if (intent.side=='BUY' and stop>=b) or (intent.side=='SELL' and stop<=a):
            raise ValueError('stop is not on the protective side of the closing quote')
        request.update({'action':mt5.TRADE_ACTION_DEAL,
                        'type':mt5.ORDER_TYPE_BUY if intent.side=='BUY' else mt5.ORDER_TYPE_SELL,
                        'price':float(executable),'type_time':mt5.ORDER_TIME_GTC})
    else:
        limit=_positive(intent.limit_price,'limit_price')
        if type(intent.expiration_utc_s) is not int or intent.expiration_utc_s<=now_utc_s:
            raise ValueError('future UTC expiration is required for a pending limit')
        if (intent.side=='BUY' and (limit>=a or stop>=limit)) or (
            intent.side=='SELL' and (limit<=b or stop<=limit)):
            raise ValueError('invalid pending limit or protective stop direction')
        request.update({'action':mt5.TRADE_ACTION_PENDING,
                        'type':mt5.ORDER_TYPE_BUY_LIMIT if intent.side=='BUY' else mt5.ORDER_TYPE_SELL_LIMIT,
                        'price':float(limit),'type_time':mt5.ORDER_TIME_SPECIFIED,
                        'expiration':intent.expiration_utc_s})
    return request


class MT5ExecutionAdapter:
    """Contains the MT5 send call but the hard lock is unconditional in v0.4."""
    def __init__(self, mt5):
        self.mt5=mt5

    @staticmethod
    def blockers():
        return ('No validated probability model', 'Live invalidation/stop management not implemented',
                'Account reconciliation, idempotency and explicit enable workflow not implemented',
                'Broker/runtime integration not tested')

    def preflight(self, intent, *, expected_login, expected_server, now_ms,
                  fill_policy, deviation_points, magic, max_quote_age_ms=5_000):
        """Draft broker checks and MT5 order_check; DOES NOT send an order.

        This is mock-tested only. A passed check is not a fill or guarantee,
        and this method is not connected to any live strategy. Netting,
        order idempotency, margin changes, actual fills, management and all
        provider/model validation remain unresolved. Do not bypass the lock.
        """
        def reject(message): raise BrokerPreflightRejected(message)
        if type(expected_login) is not int or expected_login <= 0 or not isinstance(expected_server,str) or not expected_server.strip():
            reject('An explicit expected account and server are required')
        if type(now_ms) is not int or type(max_quote_age_ms) is not int or max_quote_age_ms <= 0:
            reject('A valid UTC clock and quote freshness setting are required')
        if not isinstance(intent,OrderIntent): reject('An OrderIntent is required')
        account=self.mt5.account_info(); terminal=self.mt5.terminal_info()
        if not account or not terminal or not getattr(terminal,'connected',False):
            reject('MT5 account or terminal disconnected')
        if getattr(account,'login',None) != expected_login or getattr(account,'server',None) != expected_server:
            reject('Connected account does not match the explicitly expected account')
        if (not getattr(terminal,'trade_allowed',False) or getattr(terminal,'tradeapi_disabled',True)
                or not getattr(account,'trade_allowed',False) or not getattr(account,'trade_expert',False)):
            reject('Terminal or account trading permission is disabled or unknown')
        if getattr(account,'currency',None) != 'USD': reject('The selected lot tiers require a USD account')
        info=self.mt5.symbol_info(intent.symbol); tick=self.mt5.symbol_info_tick(intent.symbol)
        if not info or not tick: reject('Symbol details or quote unavailable')
        try:
            modes={'BUY': {self.mt5.SYMBOL_TRADE_MODE_FULL,self.mt5.SYMBOL_TRADE_MODE_LONGONLY},
                   'SELL': {self.mt5.SYMBOL_TRADE_MODE_FULL,self.mt5.SYMBOL_TRADE_MODE_SHORTONLY}}
            if intent.side not in modes or getattr(info,'trade_mode',None) not in modes[intent.side]:
                reject('Symbol does not allow this trade direction')
            if not broker_accepts_exact_volume(volume=intent.volume, minimum=info.volume_min,
                                               maximum=info.volume_max, step=info.volume_step):
                reject('Volume is incompatible with broker minimum, maximum or step')
            tick_size=_positive(info.trade_tick_size,'trade_tick_size'); point=_positive(info.point,'point')
            stop=_positive(intent.stop_loss,'stop_loss')
            if stop % tick_size: reject('Stop is not on the broker price grid')
            bid=_positive(tick.bid,'bid'); ask=_positive(tick.ask,'ask')
            tick_ms=getattr(tick,'time_msc',None)
            if type(tick_ms) is not int or not 0 <= now_ms-tick_ms <= max_quote_age_ms:
                reject('Quote is stale, future-dated or missing a timestamp')
            if bid >= ask: reject('Bid/ask quote is invalid')
            stop_level=getattr(info,'trade_stops_level',None)
            if type(stop_level) is not int or stop_level < 0: reject('Broker stop-level data unavailable')
            distance=Decimal(stop_level)*point
            if intent.side=='BUY' and bid-stop < distance: reject('Buy stop violates broker minimum distance')
            if intent.side=='SELL' and stop-ask < distance: reject('Sell stop violates broker minimum distance')
            request=prepare_request(self.mt5,intent,bid=bid,ask=ask,fill_policy=fill_policy,
                                    deviation_points=deviation_points,magic=magic,now_utc_s=now_ms//1000)
            execution=getattr(info,'trade_exemode',None)
            if execution not in (self.mt5.SYMBOL_TRADE_EXECUTION_REQUEST,self.mt5.SYMBOL_TRADE_EXECUTION_INSTANT,
                                  self.mt5.SYMBOL_TRADE_EXECUTION_MARKET,self.mt5.SYMBOL_TRADE_EXECUTION_EXCHANGE):
                reject('Unknown broker execution mode')
            if intent.order_kind=='LIMIT':
                limit=_positive(intent.limit_price,'limit_price')
                if limit % tick_size: reject('Limit is not on the broker price grid')
                if fill_policy != self.mt5.ORDER_FILLING_RETURN: reject('Pending orders require RETURN filling policy')
                if intent.side=='BUY' and ask-limit < distance: reject('Buy limit violates minimum distance')
                if intent.side=='SELL' and limit-bid < distance: reject('Sell limit violates minimum distance')
            else:
                if fill_policy not in (self.mt5.ORDER_FILLING_FOK,self.mt5.ORDER_FILLING_IOC,self.mt5.ORDER_FILLING_RETURN):
                    reject('Unsupported fill policy')
                if execution==self.mt5.SYMBOL_TRADE_EXECUTION_MARKET and fill_policy==self.mt5.ORDER_FILLING_RETURN:
                    reject('RETURN filling is not valid for market execution')
                if execution in (self.mt5.SYMBOL_TRADE_EXECUTION_MARKET,self.mt5.SYMBOL_TRADE_EXECUTION_EXCHANGE):
                    allowed=getattr(info,'filling_mode',None)
                    if type(allowed) is not int: reject('Broker fill-policy information missing')
                    if fill_policy==self.mt5.ORDER_FILLING_FOK and not (allowed & 1): reject('Broker does not advertise FOK')
                    if fill_policy==self.mt5.ORDER_FILLING_IOC and not (allowed & 2): reject('Broker does not advertise IOC')
                if execution==self.mt5.SYMBOL_TRADE_EXECUTION_MARKET:
                    request.pop('price',None)  # documented MT5 Market Execution request format
            margin_price=(float(ask) if intent.side=='BUY' else float(bid)) if intent.order_kind=='MARKET' else float(intent.limit_price)
            margin=self.mt5.order_calc_margin(request['type'],intent.symbol,float(intent.volume),margin_price)
            if margin is None: reject('MT5 margin calculation returned no result')
            required=_positive(margin,'margin')
            free=_positive(getattr(account,'margin_free',None),'free margin')
            if required > free: reject('Insufficient free margin')
            result=self.mt5.order_check(request)
            if result is None: reject('MT5 order_check returned no result')
            if type(getattr(result,'retcode',None)) is not int or result.retcode != 0:
                reject('MT5 order_check did not return a successful check')
            return {'checked':True, 'request':request, 'margin_estimate':float(required),
                    'warning':'Mock-tested draft only; check is not execution or a guarantee'}
        except BrokerPreflightRejected:
            raise
        except (AttributeError,TypeError,ValueError,InvalidOperation):
            reject('Required broker data or MT5 constants are unavailable or invalid')

    def send(self, request):
        # This hard-coded check cannot be enabled via dashboard, API, environment,
        # or config. Future work must replace this guard only after independent
        # validation and explicit authorization. Never bypass it for real money.
        blockers=self.blockers()
        if blockers:
            raise LiveExecutionLocked('; '.join(blockers))
        return self.mt5.order_send(request)  # unreachable in this release
