import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from core.daily_monitor import DailyEquityMonitor


class DailyEquityMonitorTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)/'alert.json';self.events=[]
        self.monitor=DailyEquityMonitor(self.path,lambda *args:self.events.append(args))
        self.now=datetime(2026,10,29,0,0,4,tzinfo=timezone.utc)
        self.account={'login':123,'server':'broker-test','equity':1000,'currency':'USD'}
    def update(self,account=None,now=None):
        return self.monitor.update(account=self.account if account is None else account,daily_loss_alert_pct=10,now=now or self.now)
    def set(self,value=1000,verified=True):
        return self.monitor.set_baseline(account=self.account,verified_day_start_equity=value,verified=verified,now=self.now)
    def test_manual_verified_baseline_required(self):
        self.assertEqual(self.update()['status'],'NEEDS_BASELINE')
        with self.assertRaises(ValueError):self.set(verified=False)
        self.assertFalse(self.path.exists())
        self.set();r=self.update()
        self.assertEqual(r['status'],'MONITORING');self.assertEqual(r['alert_equity_threshold'],900)
        self.assertFalse(r['stops_trading']);self.assertFalse(r['closes_positions'])
    def test_threshold_latches_and_does_not_close_or_block(self):
        self.set();self.account['equity']=900
        r=self.update();self.assertEqual(r['status'],'ALERT');self.assertTrue(r['new_alert_requested'])
        self.assertFalse(r['block_new_bot_entries_due_to_daily_alert'])
        self.assertFalse(r['request_close_positions_due_to_daily_alert'])
        self.account['equity']=980;r=self.update()
        self.assertTrue(r['alerted_today']);self.assertFalse(r['new_alert_requested'])
        self.assertEqual(len([e for e in self.events if 'threshold was reached' in e[1]]),1)
    def test_state_persists_for_same_account_and_day(self):
        self.set();self.account['equity']=899;self.update()
        newer=DailyEquityMonitor(self.path,lambda *a:None)
        self.account['equity']=950
        r=newer.update(account=self.account,daily_loss_alert_pct=10,now=self.now)
        self.assertEqual(r['status'],'ALERT');self.assertFalse(r['new_alert_requested'])
    def test_new_day_or_account_requires_new_baseline(self):
        self.set()
        changed=dict(self.account,login=999)
        self.assertEqual(self.update(account=changed)['status'],'NEEDS_BASELINE')
        changed=dict(self.account,server='other')
        self.assertEqual(self.update(account=changed)['status'],'NEEDS_BASELINE')
        self.assertEqual(self.update(now=self.now+timedelta(days=1))['status'],'NEEDS_BASELINE')
    def test_baseline_cannot_be_replaced_silently(self):
        self.set()
        self.assertTrue(self.set()['already_recorded'])
        with self.assertRaises(ValueError):self.set(1200)
    def test_missing_or_invalid_account_does_not_calculate(self):
        self.assertEqual(self.update(account={'equity':800})['status'],'DISCONNECTED')
        with self.assertRaises(ValueError):self.monitor.set_baseline(account={},verified_day_start_equity=1000,verified=True,now=self.now)
    def test_corrupt_file_fails_closed_without_overwriting(self):
        self.path.write_text('{bad')
        bad=DailyEquityMonitor(self.path,lambda *a:None)
        self.assertEqual(bad.update(account=self.account,daily_loss_alert_pct=10,now=self.now)['status'],'ERROR')
        with self.assertRaises(ValueError):bad.set_baseline(account=self.account,verified_day_start_equity=1000,verified=True,now=self.now)
        self.assertEqual(self.path.read_text(),'{bad')
    def test_invalid_equity_and_baseline(self):
        for n in (True,-1,0,float('inf'),float('nan'),'abc'):
            with self.subTest(value=n),self.assertRaises(ValueError):self.set(n)
        self.set();self.account['equity']=float('nan');self.assertEqual(self.update()['status'],'ERROR')

if __name__=='__main__':unittest.main()
