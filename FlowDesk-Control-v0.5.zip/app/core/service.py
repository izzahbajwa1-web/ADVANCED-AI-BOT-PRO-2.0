"""Composition for the read-only research dashboard. Live execution is locked."""
from __future__ import annotations
from collections import deque
import threading
import time

from .config import ConfigStore
from .flow import FlowCollector, FRESH_MS
from .mt5_reader import MT5Reader
from .strategy import confirm_flow
from .staged_strategy import analyze_sequence
from .higher_timeframe import combined_bias
from .economic_calendar import CalendarClient
from .risk import lots_from_usd_balance, UnsupportedAccountCurrency
from .qualification import probability_gate
from .bot_controls import BotController
from .daily_monitor import DailyEquityMonitor
from .research_scanner import ResearchScanner


class DeskService:
    def __init__(self, config_path, preview=False, bridge_enabled=False):
        self.config = ConfigStore(config_path)
        self.collector = FlowCollector()
        self.reader = MT5Reader(preview)
        self.preview = preview
        self.calendar = CalendarClient(preview=preview)
        self.context_cache = {}
        self.context_cache_lock = threading.Lock()
        self.bridge_enabled = bridge_enabled and not preview
        self.events = deque(maxlen=50)
        self.event_lock = threading.Lock()
        self.source_seen = set()
        self.bot = BotController(self.config)
        self.scanner = ResearchScanner(self.reader, self.log)
        self.daily_monitor = DailyEquityMonitor(config_path.parent / "daily-equity-state.json", self.log)
        self._monitor_stop = threading.Event()
        self._monitor_thread = None
        self.log("System", "Bot control build started. MT5 order execution remains hard-locked.")

    def log(self, title, detail):
        with self.event_lock:
            self.events.appendleft({"time_ms": int(time.time()*1000), "title": title, "detail": detail})

    def start_background(self):
        """Poll equity while the application is running. It never trades."""
        if self._monitor_thread and self._monitor_thread.is_alive():
            return
        self._monitor_stop.clear()
        def worker():
            while not self._monitor_stop.wait(2.0):
                try:
                    self.poll_daily_alert()
                except Exception as exc:
                    # A monitor failure is visible; it must never mutate trades.
                    self.log("Daily equity alert", f"Monitor error ({type(exc).__name__}); no notification delivered.")
        self._monitor_thread = threading.Thread(target=worker, name="flowdesk-equity-alert", daemon=True)
        self._monitor_thread.start()

    def stop_background(self):
        self.scanner.stop()
        self._monitor_stop.set()
        if self._monitor_thread and self._monitor_thread is not threading.current_thread():
            self._monitor_thread.join(timeout=3)

    def poll_daily_alert(self):
        snap = self.reader.snapshot(())
        account = snap.get("account") if snap.get("connected") else None
        risk = self.config.read().get("risk", {})
        return self.daily_monitor.update(account=account, daily_loss_alert_pct=risk.get("daily_loss_alert_pct"))

    def set_daily_baseline(self, payload):
        if not isinstance(payload, dict) or set(payload) != {"day_start_equity", "verified"}:
            raise ValueError("Provide the verified UTC day-start equity only")
        snap = self.reader.snapshot(())
        if not snap.get("connected"):
            raise ValueError("Connect MT5 to the intended account first")
        result = self.daily_monitor.set_baseline(account=snap.get("account"),
            verified_day_start_equity=payload["day_start_equity"], verified=payload["verified"])
        self.poll_daily_alert()
        return result

    def bot_status(self):
        snap = self.reader.snapshot(())
        return self.bot.status(bool(snap.get("connected")))

    def bot_start_check(self):
        snap = self.reader.snapshot(())
        result = self.bot.check_start(bool(snap.get("connected")))
        self.log("Bot readiness", "Start rejected: model, detectors, management and validation are incomplete.")
        return result

    def bot_stop(self):
        scan_result = self.scanner.stop()
        snap = self.reader.snapshot(())
        result = self.bot.stop(bool(snap.get("connected")))
        result["scan_stopped"] = scan_result["stopped"]
        result["message"] = "Bot is stopped; research scan stop requested. No MT5 positions were closed."
        self.log("Bot control", "Bot stopped; research scan stop requested. No MT5 positions were closed.")
        return result

    def save_bot_plan(self, payload):
        result = self.bot.save_plan(payload)
        self.log("Bot settings", "Profit-booking preferences saved for research only; no trade controls are active.")
        return result

    def research_scan_status(self):
        return self.scanner.status()

    def research_scan_start(self):
        return self.scanner.start()

    def research_scan_stop(self):
        return self.scanner.stop()

    def market_watch(self):
        reader = getattr(self.reader, "market_watch", None)
        return reader() if callable(reader) else {"connected": False, "status": "UNAVAILABLE", "symbols": [],
                                                  "message": "Market Watch is unavailable."}

    def positions(self):
        reader = getattr(self.reader, "positions", None)
        return reader() if callable(reader) else {"connected": False, "status": "UNAVAILABLE", "positions": [],
                                                  "message": "Positions are unavailable."}

    def broker_check(self, payload):
        reader = getattr(self.reader, "broker_check", None)
        if not callable(reader):
            raise ValueError("MT5 broker checks are unavailable")
        result = reader(payload)
        self.log("Broker check", "A read-only MT5 order check was requested; no order was sent.")
        return result

    def connect_mt5(self):
        ok, message = self.reader.connect()
        with self.context_cache_lock: self.context_cache.clear()
        self.log("MT5 reader", message)
        return {"ok": ok, "message": message}

    def disconnect_mt5(self):
        self.scanner.stop()
        self.reader.disconnect()
        with self.context_cache_lock: self.context_cache.clear()
        self.log("MT5 reader", "Disconnected by user.")
        return {"ok": True}

    def accept_bridge(self, event):
        result = self.collector.accept(event)
        key = (event["platform"].lower(), event["provider"].strip(), event["instrument"].strip())
        with self.event_lock:
            first = key not in self.source_seen
            self.source_seen.add(key)
        if first:
            self.log("Order-flow event", f"Received data labelled {key[0]} / {key[1]} / {key[2]}. Source not independently verified.")
        return result

    def save_risk(self, body):
        result = self.config.set_risk(body)
        self.log("Risk settings", "Alert threshold saved; monitoring requires a verified daily equity baseline. No trade actions are active.")
        return result

    def save_market_context(self, body):
        context = self.config.set_market_context(body)
        self.log("Dollar-index context", "Symbol saved for read-only lookup; verify it matches the intended index or proxy.")
        return context

    def market_bias(self, symbol, now):
        with self.context_cache_lock:
            cached = self.context_cache.get(symbol)
            if cached and 0 <= now - cached[0] < 60_000:
                return cached[1]
        daily = self.reader.bars(symbol, 100, timeframe="D1")
        h4 = self.reader.bars(symbol, 100, timeframe="H4")
        bias = combined_bias(daily, h4)
        with self.context_cache_lock:
            self.context_cache[symbol] = (now, bias)
        return bias

    def add_mapping(self, body):
        mapping = self.config.add_mapping(body)
        self.log("Market mapped", f"{mapping['mt5_symbol']} → {mapping['instrument']} ({mapping['platform']}).")
        return mapping

    def remove_mapping(self, symbol):
        self.config.remove_mapping(symbol)
        self.log("Market mapping", f"Removed {symbol}.")
        return {"ok": True}

    def state(self):
        now = int(time.time()*1000)
        config = self.config.read()
        watchlist = config.get("watchlist", [])
        watchlist = list(watchlist) if isinstance(watchlist, list) else []
        context = config.get("market_context") or {}
        dxy_symbol = context.get("dxy_symbol") if isinstance(context,dict) else None
        if isinstance(dxy_symbol,str) and dxy_symbol and dxy_symbol not in watchlist:
            watchlist.insert(0,dxy_symbol)
        mt5 = self.reader.snapshot(watchlist)
        streams = self.collector.summaries(now)
        platforms = []
        for name in ("bookmap", "quantower", "atas"):
            sources = [s for s in streams if s["platform"] == name]
            newest = max(sources, key=lambda s: s["last_receive_ms"]) if sources else None
            receiving = bool(newest and 0 <= now - newest["last_receive_ms"] <= FRESH_MS)
            platforms.append({"name": name, "receiving": receiving,
                "instrument": newest["instrument"] if newest else None,
                "provider": newest["provider"] if newest else None,
                "usable": bool(newest and newest["usable"]),
                "last_receive_ms": newest["last_receive_ms"] if newest else None,
                "bridge_enabled": self.bridge_enabled})
        signals = []
        htf_markets = []
        if mt5["connected"]:
            for mapping in config.get("mappings", []):
                if not isinstance(mapping, dict) or mapping.get("reviewed") is not True:
                    continue
                try:
                    symbol = mapping["mt5_symbol"]
                    bias = self.market_bias(symbol, now)
                    htf_markets.append({"symbol":symbol, **bias})
                    bars = self.reader.bars(symbol, 40)
                    if not bars:
                        continue
                    # M5 timestamps are bar-open timestamps. Require a recent closed bar.
                    age = now - bars[-1].timestamp_ms
                    if age < 5*60_000 or age > 11*60_000:
                        continue
                    quote = next((q for q in mt5.get("quotes",[]) if q.get("symbol")==symbol and q.get("available")), None)
                    setup = analyze_sequence(bars, quote=quote, now_ms=now)
                    if not setup:
                        continue
                    flow = next((stream for stream in streams if stream["platform"] == mapping["platform"]
                        and stream["provider"] == mapping["provider"] and stream["instrument"] == mapping["instrument"]), None)
                    setup.update({"symbol": symbol, "source": mapping["platform"],
                        "source_instrument": mapping["instrument"], "is_proxy": mapping["is_proxy"],
                        "flow_confirmed": confirm_flow(setup["direction"], flow),
                        "higher_timeframe":bias, "qualification": probability_gate(None, model_validated=False),
                        "label": "Research sequence only; neither entry is verified or sent"})
                    signals.append(setup)
                except (KeyError, TypeError, ValueError, AttributeError):
                    # Bad or missing user config/data must not create a trade or crash the dashboard.
                    continue
        dxy_quote = next((q for q in mt5.get("quotes",[]) if q.get("symbol")==dxy_symbol),None) if dxy_symbol else None
        dxy = {"symbol": dxy_symbol, "quote": dxy_quote, "fresh": False, "bias": None,
               "message":"Choose and verify a dollar-index symbol or proxy in your MT5 terminal."}
        if dxy_quote and dxy_quote.get("available"):
            ts = dxy_quote.get("timestamp_ms")
            dxy["fresh"] = type(ts) is int and 0 <= now-ts <= FRESH_MS
            dxy["message"] = "Provider quote; identity and live status must be verified." if dxy["fresh"] else "Quote is stale or timestamp missing; verify instrument and feed."
        if mt5.get("connected") and isinstance(dxy_symbol,str) and dxy_symbol:
            try: dxy["bias"] = self.market_bias(dxy_symbol, now)
            except (TypeError,ValueError,KeyError,AttributeError): pass
        risk = config.get("risk", {})
        try:
            from .config import validate_risk
            validate_risk(risk)
            risk_configured = True
        except ValueError:
            risk_configured = False
        account = mt5.get("account")
        lot_preview = {"basis": "USD account balance", "indicative_lots": None,
                       "broker_volume_checked": False, "reason": "MT5 account not connected"}
        if account:
            try:
                lot_preview["indicative_lots"] = lots_from_usd_balance(
                    account_balance=account.get("balance"), account_currency=account.get("currency"))
                lot_preview["reason"] = ("Indicative only; broker volume and margin not checked"
                                         if lot_preview["indicative_lots"] is not None
                                         else "Nonpositive account balance")
            except (UnsupportedAccountCurrency, ValueError) as exc:
                lot_preview["reason"] = str(exc)
        with self.event_lock:
            events = list(self.events)
        return {"version": "0.5.0-control-research", "server_time_ms": now, "preview": self.preview,
            "bot_control": self.bot.status(bool(mt5.get("connected"))),
            "daily_alert": self.daily_monitor.status(),
            "execution": {"implemented": False, "enabled": False, "adapter_scaffold": True, "hard_locked": True,
                          "reason": "No validated model, live management, reconciliation or explicit enable workflow."},
            "mt5": mt5, "risk": risk, "risk_configured": risk_configured,
            "risk_enforced": False, "lot_sizing_preview": lot_preview,
            "qualification_gate": probability_gate(None, model_validated=False),
            "staging": config.get("staging", {}), "dollar_index": dxy, "higher_timeframes": htf_markets,
            "economic_calendar": self.calendar.snapshot(),
            "mappings": config.get("mappings", []), "platforms": platforms,
            "streams": streams, "signals": signals, "events": events}
