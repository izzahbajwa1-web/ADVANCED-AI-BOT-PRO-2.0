(() => {
  'use strict';
  let state = null;
  let toastTimer;
  const $ = (id) => document.getElementById(id);
  const txt = (id, value) => { const e = $(id); if (e) e.textContent = value; };
  const node = (tag, cls, value) => { const e = document.createElement(tag); if (cls) e.className = cls; if (value !== undefined) e.textContent = value; return e; };
  const show = (id) => { if (!$(id).open) $(id).showModal(); };
  const close = (id) => { if ($(id).open) $(id).close(); };
  const notify = (message) => {
    txt('toast', message); $('toast').classList.add('visible');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').classList.remove('visible'), 4200);
  };
  async function post(path, data = {}) {
    const response = await fetch(path, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data), cache:'no-store'});
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Request failed.');
    return result;
  }
  function formatMoney(num, currency) {
    if (typeof num !== 'number' || !Number.isFinite(num)) return '—';
    try { return new Intl.NumberFormat('en-US', {style:'currency', currency:currency || 'USD', maximumFractionDigits:2}).format(num); }
    catch (_) { return `${num.toLocaleString('en-US', {maximumFractionDigits:2})} ${currency || ''}`.trim(); }
  }
  function fmtPct(value) { return typeof value === 'number' ? `${value}%` : 'Not set'; }
  function tag(id, value, ok=false) { const e = $(id); e.textContent = value; e.classList.toggle('ok', ok); }
  function when(ms) {
    if (!ms) return '—';
    return new Date(ms).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'});
  }
  function renderMarkets(s) {
    const surface = $('marketSurface');
    const mappings = Array.isArray(s.mappings) ? s.mappings : [];
    txt('marketCount', String(mappings.length).padStart(2,'0'));
    txt('marketBottom', mappings.length ? `${mappings.length} MARKET${mappings.length === 1 ? '' : 'S'} MAPPED` : 'NO SYMBOLS MAPPED');
    txt('monitorStatus', s.mt5.connected ? 'MT5 READER CONNECTED' : 'WAITING FOR DATA');
    surface.replaceChildren();
    if (!mappings.length) {
      const empty = node('div','empty-state');
      const icon = node('div','empty-chart-icon');
      icon.innerHTML = '<svg viewBox="0 0 36 36" aria-hidden="true"><path d="M7 27V9m0 18h22M11 22l5-6 5 3 6-9"/></svg>';
      const p = node('p',''); p.append('Map an MT5 symbol to an order-flow instrument.', document.createElement('br'), 'Live quotes will appear here when connected.');
      const link = node('button','text-button accent','Map your first market ↗'); link.type = 'button'; link.onclick = () => show('mappingDialog');
      empty.append(icon, node('strong','', 'No markets connected yet'), p, link); surface.append(empty); return;
    }
    const list = node('div','quote-list');
    for (const m of mappings) {
      const row = node('div','quote-row');
      const left = node('div','');
      const htf=(s.higher_timeframes||[]).find(x=>x.symbol===m.mt5_symbol);
      const htfLabel=htf ? ` · D1 ${htf.daily.bias} / H4 ${htf.h4.bias}` : '';
      left.append(node('strong','', m.mt5_symbol), node('small','', `${m.platform.toUpperCase()} · ${m.instrument}${m.is_proxy ? ' · PROXY' : ''}${htfLabel}`));
      const q = (s.mt5.quotes || []).find(x => x.symbol === m.mt5_symbol);
      const bid = node('div','quote-num',q && q.available ? `Bid  ${q.bid}` : 'Bid  —');
      const ask = node('div','quote-num ask-col',q && q.available ? `Ask  ${q.ask}` : 'Ask  —');
      const remove = node('button','remove-map','Remove'); remove.type='button'; remove.setAttribute('aria-label', `Remove mapping ${m.mt5_symbol}`);
      remove.onclick = async () => {
        if (!window.confirm(`Remove the mapping for ${m.mt5_symbol}?`)) return;
        try { await post('/api/mappings/remove', {symbol:m.mt5_symbol}); notify('Market mapping removed.'); await refresh(); }
        catch (err) { notify(err.message); }
      };
      row.append(left,bid,ask,remove); list.append(row);
    }
    surface.append(list);
  }
  function renderSignals(signals) {
    const container = $('signals'); container.replaceChildren();
    txt('signalStatus', signals.length ? `${signals.length} RESEARCH SETUP${signals.length === 1 ? '' : 'S'}` : 'NO SETUPS YET');
    for (const signal of signals) {
      const row=node('div','signal-item');
      const phase=signal.phase==='FVG_RETEST_RESEARCH' ? 'FVG retest observed' : signal.phase==='FVG_FORMED_RESEARCH' ? 'FVG formed · waiting for retest' : 'Sweep + BOS observed';
      const flow=signal.flow_confirmed ? 'Flow aligned' : 'Flow not confirmed';
      row.append(node('strong','', `${signal.symbol} · ${signal.direction}`), node('span','', `${phase} · ${flow} · 90% model unavailable`));
      container.append(row);
    }
  }
  function renderContext(s) {
    const list=$('trendList'); list.replaceChildren();
    const markets=s.higher_timeframes||[];
    if(!markets.length) list.append(node('p','', 'Map a market and connect MT5 to inspect its closed-candle trend.'));
    for(const m of markets.slice(0,5)) {
      const row=node('div','context-item');
      row.append(node('strong','',m.symbol),node('small','',`D1 ${m.daily.bias} · H4 ${m.h4.bias}`)); list.append(row);
    }
    const d=s.dollar_index||{}; const q=d.quote;
    txt('dxySymbol',d.symbol||'NOT CONFIGURED');
    txt('dxyValue',q && q.available && typeof q.bid==='number' ? String(q.bid) : '—');
    const db=d.bias ? ` · D1 ${d.bias.daily.bias} / H4 ${d.bias.h4.bias}` : '';
    txt('dxyStatus',d.symbol ? (q && q.available ? (d.fresh?'Fresh quote · instrument unverified':'Stale quote · verify feed') + db : 'Waiting for MT5 quote' + db) : 'Choose and verify your MT5 instrument.');
    const cal=s.economic_calendar||{}; const events=cal.events||[];
    txt('calendarBadge',cal.status==='RECEIVED_UNVERIFIED'?'RECEIVED*':cal.status==='ERROR'?'ERROR':cal.configured?'WAITING':'NOT SET');
    const eventList=$('calendarList'); eventList.replaceChildren();
    if(!events.length) eventList.append(node('p','',cal.configured?(cal.message||'No upcoming events returned.'):'No calendar provider connected. See the setup guide.'));
    for(const e of events.slice(0,4)) {
      const row=node('div','context-item');
      row.append(node('strong','',e.title),node('small','',`${e.country || e.currency || '—'} · ${e.utc_time.replace('T',' ').replace('Z',' UTC')} · ${e.importance===3?'HIGH':e.importance===2?'MED':'LOW'}`));
      eventList.append(row);
    }
    txt('calendarFoot',cal.last_fetched_ms ? `Trading Economics · updated ${when(cal.last_fetched_ms)} · unverified` : 'Trading Economics · real subscription required');
  }
  function renderEvents(events) {
    const list=$('eventList'); list.replaceChildren();
    (events || []).slice(0,5).forEach(e => {
      const row=node('div','event-row'); const icon=node('div','event-bullet','·');
      const body=node('div','event-text'); body.append(node('strong','',e.title), node('span','',e.detail));
      row.append(icon,body,node('span','event-time',when(e.time_ms))); list.append(row);
    });
  }
  function render(s) {
    const account=s.mt5.account;
    txt('balance', account ? formatMoney(account.balance,account.currency) : '—');
    txt('equity', account ? formatMoney(account.equity,account.currency) : '—');
    txt('profit', account ? formatMoney(account.profit,account.currency) : '—');
    txt('balanceFoot', account ? `${account.currency} · read-only` : 'MT5 not connected');
    txt('equityFoot', account ? 'Live terminal account' : 'Waiting for account');
    txt('profitFoot', account ? 'Current floating P&L' : 'No account data');
    txt('riskMetric', s.risk_configured ? fmtPct(s.risk.daily_loss_alert_pct) : '—');
    const daily=s.daily_alert || {};
    txt('riskMetricFoot', daily.status === 'ALERT' ? 'THRESHOLD REACHED · alert only' : daily.status === 'MONITORING' ? 'Monitoring · verified baseline' : 'UTC baseline required');
    txt('policyBaseline', daily.status === 'MONITORING' || daily.status === 'ALERT' ? 'Manually verified · monitoring' : 'Not available');
    const plan=s.bot_control?.plan || {};
    txt('policyPartial', `${Number(plan.book_percent ?? 50)}% at +${Number(plan.book_at_r ?? 2)}R · saved only`);
    const lot = s.lot_sizing_preview?.indicative_lots;
    txt('lotMetric', typeof lot === 'number' ? lot.toFixed(2) : '—');
    txt('lotMetricFoot', typeof lot === 'number' ? 'Broker volume not checked' : (!account ? 'Waiting for USD balance' : account.currency?.toUpperCase() !== 'USD' ? 'USD account required' : 'Positive balance required'));
    txt('policyRisk', s.risk.risk_per_trade_pct == null ? 'None' : 'Invalid setting');
    txt('policyDay', s.risk_configured ? `${fmtPct(s.risk.daily_loss_alert_pct)} of day-start equity` : 'Not set');
    txt('policyAction', s.risk.daily_loss_action === 'alert_only' ? 'Alert only; entries continue' : 'Not set');
    txt('policyWarnTitle', s.risk_configured ? `${fmtPct(s.risk.daily_loss_alert_pct)} is an alert, not a loss cap.` : 'The alert is not a loss cap.');
    txt('policyPositions', s.risk.max_open_positions == null ? 'None' : 'Invalid setting');
    txt('policyTimezone', s.risk.daily_reset_timezone === 'UTC' ? '00:00 UTC' : 'Not set');
    txt('policyLot', s.risk.lot_sizing?.mode === 'usd_balance_tiers' ? 'USD balance · 0.01–0.05' : 'Not set');
    txt('policyTrail', s.risk_configured ? '1R at +1R while valid' : 'Invalid setting');
    txt('policyInvalid', s.risk_configured ? 'Opposite structure AND flow' : 'Not set');
    txt('policyExit', s.risk_configured ? 'Close that trade' : 'Not set');
    txt('policyConfidence', 'Not configured');
    tag('gateMt5', s.mt5.connected ? 'CONNECTED' : 'NOT CONNECTED', s.mt5.connected);
    const anyReceiving = (s.platforms||[]).some(x=>x.receiving);
    tag('gateFlow', anyReceiving ? 'RECEIVING*' : 'WAITING', anyReceiving);
    tag('gateMapping', s.mappings.length ? 'MAPPED' : 'NOT SET', s.mappings.length>0);
    tag('gateRisk', s.risk_configured ? 'SAVED ONLY' : 'NOT SET', false);
    tag('gateLot', s.risk_configured ? 'SAVED ONLY' : 'NOT SET', false);
    tag('gateModel', 'NOT SET', false);
    tag('gateDetector', 'NOT SET', false);
    for (const p of s.platforms || []) {
      const status=$(`status-${p.name}`); if (!status) continue;
      status.replaceChildren(node('i',''), document.createTextNode(p.receiving ? 'RECEIVING · UNVERIFIED' : 'NOT CONNECTED'));
      status.classList.toggle('receiving', p.receiving);
    }
    const btn=$('openConnection');
    btn.textContent = s.mt5.connected ? 'Disconnect MT5' : '+  Connect MT5';
    txt('noticeTitle', s.mt5.connected ? 'MT5 is connected in read-only mode.' : 'Your workspace is waiting for a connection.');
    txt('noticeBody', s.mt5.connected ? 'Verify your market mappings and feed. No order placement is available in this research build.' : 'Connect an Exness MT5 terminal and map a data source to see real account and market information. No simulated prices are shown.');
    renderMarkets(s); renderSignals(s.signals || []); renderContext(s); renderEvents(s.events || []);
  }
  async function refresh(silent=true) {
    try {
      const r=await fetch('/api/state',{cache:'no-store'});
      if(!r.ok) throw new Error('Dashboard state unavailable.');
      state=await r.json(); render(state);
      if(!silent) notify('Dashboard refreshed.');
    } catch(e) { if(!silent) notify(e.message); }
  }
  $('refreshBtn').onclick=()=>refresh(false);
  $('openGuide').onclick=$('noticeGuide').onclick=$('sourceGuide').onclick=()=>show('guideDialog');
  document.querySelectorAll('.source-info').forEach(b=>b.onclick=()=>show('guideDialog'));
  $('openMapping').onclick=()=>{ $('mappingError').textContent=''; show('mappingDialog'); };
  $('openContext').onclick=()=>{ $('contextForm').elements.dxy_symbol.value=state?.dollar_index?.symbol || ''; $('contextError').textContent=''; show('contextDialog'); };
  $('contextForm').onsubmit=async e=>{
    e.preventDefault(); $('contextError').textContent='';
    try { await post('/api/context',{dxy_symbol:e.currentTarget.elements.dxy_symbol.value}); close('contextDialog'); notify('Context symbol saved. Verify the instrument and feed.'); await refresh(); }
    catch(err){ $('contextError').textContent=err.message; }
  };
  $('openConnection').onclick=async()=>{
    if (state && state.mt5.connected) {
      try { await post('/api/mt5/disconnect'); notify('MT5 disconnected.'); await refresh(); } catch(e) { notify(e.message); }
    } else show('connectionDialog');
  };
  $('connectAction').onclick=async()=>{
    const btn=$('connectAction'); btn.disabled=true; btn.textContent='Connecting…';
    try { const res=await post('/api/mt5/connect'); notify(res.message); if(res.ok) close('connectionDialog'); await refresh(); }
    catch(e) { notify(e.message); }
    finally {btn.disabled=false;btn.textContent='Connect read-only';}
  };
  $('openRisk').onclick=()=>{
    const f=$('riskForm'); const r=state ? state.risk : {};
    f.elements.daily_loss_alert_pct.value = r.daily_loss_alert_pct ?? '';
    $('riskError').textContent=''; show('riskDialog');
  };
  $('riskForm').onsubmit=async e=>{
    e.preventDefault(); $('riskError').textContent=''; const f=e.currentTarget;
    const data={daily_loss_alert_pct:f.elements.daily_loss_alert_pct.value,daily_reset_timezone:'UTC',daily_loss_action:'alert_only'};
    try { await post('/api/risk',data); close('riskDialog'); notify('Alert threshold saved. A verified UTC baseline is required; trade actions remain unavailable.'); await refresh(); }
    catch(err){$('riskError').textContent=err.message;}
  };
  $('mappingForm').onsubmit=async e=>{
    e.preventDefault(); $('mappingError').textContent=''; const f=e.currentTarget;
    const data={mt5_symbol:f.elements.mt5_symbol.value.trim(),platform:f.elements.platform.value,provider:f.elements.provider.value.trim(),instrument:f.elements.instrument.value.trim(),is_proxy:f.elements.is_proxy.checked,reviewed:f.elements.reviewed.checked};
    try { await post('/api/mappings',data); close('mappingDialog'); f.reset(); notify('Mapping saved. The source still needs a working adapter.'); await refresh(); }
    catch(err){$('mappingError').textContent=err.message;}
  };
  document.querySelectorAll('[data-close]').forEach(el=>el.addEventListener('click',()=>close(el.dataset.close)));
  document.querySelectorAll('.nav-link').forEach(el=>el.addEventListener('click',()=>{
    document.querySelectorAll('.nav-link').forEach(n=>n.classList.remove('selected')); el.classList.add('selected');
  }));
  refresh(); setInterval(refresh,3000);
})();
