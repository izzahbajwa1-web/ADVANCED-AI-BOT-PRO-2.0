"""Control-room state for the not-yet-operational FlowDesk trading bot.

The UI can save research preferences and request a readiness check. No API,
setting, browser control, or environment variable can enable order sending in
this version. Live execution remains hard-locked in mt5_execution.py.
"""
from __future__ import annotations

import math
import threading
import time

DEFAULT_BOT_PLAN = {
    "scope": "mt5_market_watch",
    "managed_positions": "flowdesk_only",
    "book_at_r": 2.0,
    "book_percent": 50.0,
    "trailing_activation_r": 1.0,
    "trailing_distance_r": 1.0,
    "trail_requires_valid_setup": True,
    "remaining_position": "trail_no_fixed_target",
    "unsplittable_partial": "unresolved",
    "probability_outcome": "first_2r_target_before_active_stop",
    "minimum_probability": 0.90,
}


def validate_plan(payload):
    """Accept only editable preferences, without allowing safety-gate edits."""
    if not isinstance(payload, dict) or set(payload) != {"book_at_r", "book_percent"}:
        raise ValueError("Provide only the profit-booking R and percentage")
    def number(key):
        value = payload[key]
        if isinstance(value, bool):
            raise ValueError(f"{key} must be a finite number")
        try:
            value = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"{key} must be a finite number") from None
        if not math.isfinite(value):
            raise ValueError(f"{key} must be a finite number")
        return value
    target, percentage = number("book_at_r"), number("book_percent")
    if not 2 <= target <= 10:
        raise ValueError("Profit booking must be from 2R to 10R")
    if not 0 < percentage < 100:
        raise ValueError("Profit-booking percentage must be greater than 0 and less than 100")
    result = dict(DEFAULT_BOT_PLAN)
    result["book_at_r"] = target
    result["book_percent"] = percentage
    # A different target requires a separately validated target-specific model.
    result["probability_outcome"] = "first_booking_target_before_active_stop"
    return result


class BotController:
    """Reports hard blockers honestly; it does not run an autonomous strategy."""
    def __init__(self, store):
        self.store = store
        self.lock = threading.RLock()
        self.last_check_ms = None

    def save_plan(self, payload):
        return self.store.set_bot_plan(validate_plan(payload))

    def status(self, mt5_connected=False):
        try:
            cfg = self.store.read().get("bot_plan", DEFAULT_BOT_PLAN)
            # Verify persisted safety-critical fields have not been silently altered.
            plan = validate_plan({"book_at_r": cfg.get("book_at_r"), "book_percent": cfg.get("book_percent")})
            if any(cfg.get(k, DEFAULT_BOT_PLAN[k]) != DEFAULT_BOT_PLAN[k] for k in (
                "scope", "managed_positions", "trailing_activation_r", "trailing_distance_r",
                "trail_requires_valid_setup", "remaining_position", "unsplittable_partial", "minimum_probability")):
                raise ValueError("Unsupported bot safety settings")
        except (AttributeError, ValueError, TypeError):
            plan = dict(DEFAULT_BOT_PLAN)
        blockers = []
        if not mt5_connected:
            blockers.append("MT5 terminal is not connected")
        blockers.extend([
            "No independently validated 90% target-before-stop model or training data",
            "Live order-flow sources and symbol mappings are not verified",
            "Live opposing-structure and order-flow invalidation detectors are not implemented",
            "MT5 submission and automated position management remain hard-locked and untested",
            "The action for an unsplittable partial close has not been chosen",
            "The live sweep-stop buffer and full trade lifecycle remain unvalidated",
        ])
        with self.lock:
            checked = self.last_check_ms
        return {"status": "STOPPED", "started": False, "start_available": False,
                "real_orders_locked": True, "mode": "research_and_broker_check",
                "plan": plan, "blockers": blockers, "last_readiness_check_ms": checked,
                "message": "Preferences and readiness checks work; the bot cannot send or manage MT5 trades."}

    def check_start(self, mt5_connected=False):
        with self.lock:
            self.last_check_ms = int(time.time() * 1000)
        result = self.status(mt5_connected)
        result["message"] = "Not started. Resolve the listed blockers before any automated orders."
        return result

    def stop(self, mt5_connected=False):
        # There is no worker sending orders. Stop never closes existing MT5 trades.
        result = self.status(mt5_connected)
        result["message"] = "Bot is stopped. This action does not close MT5 positions."
        return result
