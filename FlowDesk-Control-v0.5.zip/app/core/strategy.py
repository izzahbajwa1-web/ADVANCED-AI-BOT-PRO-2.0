"""A deliberately small, deterministic SMC/ICT-inspired RESEARCH example.

No claim of an edge. Not wired to execution. All input candles must be closed.
"""
from __future__ import annotations
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class Bar:
    timestamp_ms: int
    open: float
    high: float
    low: float
    close: float
    closed: bool = True


def find_setup(bars: list[Bar], lookback: int = 12):
    """Return a setup based on a sweep, break of sweep bar, and 3-bar FVG.

    For the last three closed candles A,B,C, compare B to the preceding
    `lookback` bars (excluding A,B,C). E.g. a long has B.low below that
    range's low, B.close back above it, C.close > B.high, C.low > A.high.
    This is a narrow, testable interpretation, not a canonical ICT definition.
    """
    if not isinstance(lookback, int) or lookback < 2:
        raise ValueError("lookback must be an integer of at least 2")
    if len(bars) < lookback + 3:
        return None
    bars = bars[-(lookback + 3):]
    previous = -1
    for bar in bars:
        numbers = (bar.open, bar.high, bar.low, bar.close)
        if (not bar.closed or not all(math.isfinite(x) and x > 0 for x in numbers)
                or bar.low > min(bar.open, bar.close) or bar.high < max(bar.open, bar.close)
                or bar.low > bar.high or bar.timestamp_ms <= previous):
            raise ValueError("Bars must be valid, closed, and strictly time ordered")
        previous = bar.timestamp_ms
    history = bars[:-3]
    first, swept, confirm = bars[-3:]
    swing_low = min(b.low for b in history)
    swing_high = max(b.high for b in history)
    if (swept.low < swing_low < swept.close and confirm.close > swept.high
            and confirm.low > first.high):
        return {"direction": "BUY", "bar_time_ms": confirm.timestamp_ms,
                "reference_entry": confirm.close, "sweep_extreme": swept.low,
                "fvg_low": first.high, "fvg_high": confirm.low,
                "liquidity_level": swing_low}
    if (swept.high > swing_high > swept.close and confirm.close < swept.low
            and confirm.high < first.low):
        return {"direction": "SELL", "bar_time_ms": confirm.timestamp_ms,
                "reference_entry": confirm.close, "sweep_extreme": swept.high,
                "fvg_low": confirm.high, "fvg_high": first.low,
                "liquidity_level": swing_high}
    return None


def confirm_flow(direction: str, summary: dict | None, imbalance_threshold: float = 0.10):
    """Require a fresh intact book AND signed trade stream from one source.

    This checks a generic heuristic only; these are not validated trading rules.
    """
    if direction not in {"BUY", "SELL"}:
        raise ValueError("direction must be BUY or SELL")
    if not 0 <= imbalance_threshold < 1:
        raise ValueError("imbalance threshold out of range")
    if not summary or not summary.get("usable"):
        return False
    imbalance, delta = summary.get("imbalance"), summary.get("delta")
    if imbalance is None or delta is None:
        return False
    return (imbalance >= imbalance_threshold and delta > 0) if direction == "BUY" else (
        imbalance <= -imbalance_threshold and delta < 0)
