import time
import unittest
from types import SimpleNamespace
from core.mt5_reader import MT5Reader
from test_calendar_execution import FakeMT5Preflight


class FakeViewMT5:
    POSITION_TYPE_BUY=0;POSITION_TYPE_SELL=1
    def __init__(self):self.nsymbols=500;self.positions_value=[]
    def symbols_get(self):
        return [SimpleNamespace(name=f'MKT{i}',visible=True,path='Test\\Category',description='mock') for i in range(self.nsymbols)]+[SimpleNamespace(name='HIDDEN',visible=False)]
    def positions_get(self):return self.positions_value


class MT5ViewTests(unittest.TestCase):
    def setUp(self):
        self.reader=MT5Reader();self.fake=FakeViewMT5();self.reader._mt5=self.fake
    def test_market_watch_includes_every_visible_symbol_not_a_position_cap(self):
        result=self.reader.market_watch()
        self.assertEqual(result['status'],'RECEIVED_UNVERIFIED')
        self.assertEqual(len(result['symbols']),500)
        self.assertNotIn('HIDDEN',[x['symbol'] for x in result['symbols']])
    def test_empty_and_failed_data_are_distinct(self):
        self.fake.nsymbols=0
        self.assertEqual(self.reader.market_watch()['status'],'RECEIVED_UNVERIFIED')
        self.fake.symbols_get=lambda: None
        self.assertEqual(self.reader.market_watch()['status'],'ERROR')
        self.fake.positions_value=None
        self.assertEqual(self.reader.positions()['status'],'ERROR')
    def test_positions_are_read_only_and_ownership_is_not_claimed(self):
        self.fake.positions_value=[SimpleNamespace(ticket=15,symbol='XAU-test',type=0,volume=.01,price_open=100,
               price_current=101,sl=99,tp=0,profit=3,magic=4600401)]
        result=self.reader.positions();self.assertEqual(result['status'],'READ_ONLY')
        self.assertEqual(result['positions'][0]['side'],'BUY')
        self.assertFalse(result['positions'][0]['ownership_verified'])
    def test_disconnected_no_market_or_positions_fabricated(self):
        self.reader._mt5=None
        self.assertEqual(self.reader.market_watch()['status'],'DISCONNECTED')
        self.assertEqual(self.reader.positions()['positions'],[])


class BrokerCheckTests(unittest.TestCase):
    def setUp(self):
        self.reader=MT5Reader();self.mt5=FakeMT5Preflight();self.reader._mt5=self.mt5
        self.mt5.tick.time_msc=int(time.time()*1000)
        self.payload={'symbol':'XAU-test','side':'BUY','volume':.01,'stop_loss':99,
                      'fill_policy':'IOC','confirm_account':True}
    def test_real_adapter_check_uses_order_check_not_order_send(self):
        result=self.reader.broker_check(self.payload)
        self.assertTrue(result['checked']);self.assertEqual(len(self.mt5.checks),1)
        self.assertEqual(self.mt5.sent,[])
    def test_account_confirmation_is_mandatory(self):
        self.payload['confirm_account']=False
        with self.assertRaises(ValueError):self.reader.broker_check(self.payload)
        self.assertEqual(self.mt5.checks,[]);self.assertEqual(self.mt5.sent,[])
    def test_rejected_check_never_sends(self):
        self.mt5.retcode=10019
        with self.assertRaises(ValueError):self.reader.broker_check(self.payload)
        self.assertEqual(self.mt5.sent,[])

if __name__=='__main__':unittest.main()
