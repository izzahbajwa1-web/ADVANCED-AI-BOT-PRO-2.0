# FlowDesk v0.5 — control-room research build

**This is not a functioning live-trading bot.** There is no supported way to place, close, or modify an MT5 trade in this package. The existing MT5 `order_send` scaffold is hard-locked. The bot start/readiness button always reports blockers and does not start order execution or position management. Do not use research observations as trading instructions.

This release adds an initial control-room page and real MT5 read-only tools toward the requested trading system. Unit/integration tests use mocks and synthetic fixtures; the package has **not** been tested with the user's MT5/Exness account, Bookmap, a real provider, or on the user's VPS.

## One-click Windows VPS startup

If using the portable ZIP, right-click the ZIP -> **Extract All** -> double-click `START-FLOWDESK.bat`. Do not run it from inside the ZIP. Keep its window open. The browser opens the local dashboard; click **Bot controls**. If it does not open, visit `http://127.0.0.1:8765/` inside the same Windows VPS session.

The ZIP bundles 64-bit CPython, NumPy and the MT5 Python connector. No Python install or pip command is needed. The package requires x64 Windows 10+ or Windows Server 2016+; it does not contain MT5, Bookmap, Quantower, ATAS, accounts, passwords, exchange subscriptions or live data feeds. Install/sign in to the correct Exness MT5 terminal separately and verify the account. The starter attempts a read-only connection.

## What works in this build

- **Bot control room:** shows blockers and saves profit-booking preferences. Default is 50% at +2R. These settings are not connected to actual orders. The readiness check cannot start trading; Stop never closes MT5 positions.
- **MT5 Market Watch:** lists every visible symbol that the terminal returns. No asset-specific symbol names, suffixes or broker availability are assumed. Metals, crypto, energies, stocks, indices and forex are subject to your Exness account, platform and feed. The page can display all symbols by searching or paging.
- **Research scanner:** when explicitly started, reads the Market Watch symbols' closed M5 bars and quotes and applies the existing provisional sweep/BOS/FVG logic. It is not a trading signal, may miss intrabar retests, and does not validate order flow or estimate probabilities. It sends no orders. It uses MT5 data rather than fabricated prices. MT5 feeds may be delayed or different from exchange order flow; verify with the broker.
- **Positions:** lists MT5 positions read-only. It does not assert that a position belongs to FlowDesk and cannot control positions. A durable verified ownership journal is still required before any bot-only management.
- **Broker check:** the `order_check` / margin test asks MT5 to check a manually specified market-order example without sending the order. Account confirmation is required. It is mock-tested only; a pass is not a fill, a trading signal, proof of the 90% rule, or an execution guarantee. FOK, IOC and RETURN depend on broker/symbol execution mode.
- **Daily equity alert:** while FlowDesk runs and MT5 stays connected, it compares current account equity (including floating P/L) with the **manually entered, user-verified equity for 00:00 UTC** on that account/day. The threshold is 10% by default and adjustable. The warning is shown in FlowDesk and its session log; there are no external push/email alerts. The baseline is persisted and account-bound; a new baseline is required on a new UTC day. No value is guessed if the baseline is unavailable. It never closes positions, blocks entries, or provides a loss ceiling.
- **Management planner:** synthetic-tested calculations propose 1R trailing after +1R while the setup is valid, and an exact 50% close at +2R by default. They are **not connected to live positions or MT5 order calls**. A 0.01 position often cannot be divided exactly; the handling rule is unresolved, so the planner does not round or close it. Partial-close idempotency, original-risk persistence and broker ownership require implementation.
- **Context and order-flow groundwork:** provisional D1/H4, optional dollar-index symbol, Trading Economics calendar integration requiring a separate subscription, and an experimental Bookmap read-only bridge are included. The bridge has not been tested with Bookmap or its feed. Quantower and ATAS native adapters are not implemented.

## Your confirmed strategy specification

1. Observe a liquidity sweep, then a directional break-of-structure close for the first market entry. If a subsequent fair-value gap forms and price revisits it, add a second market entry immediately; limit-order capability was also requested. All of this is a **future specification**, not automatic trading.
2. Size by USD **account balance**: below $200 = 0.01; $200–<$500 = 0.02; $500–<$600 = 0.03; $600–<$700 = 0.04; $700+ = 0.05 lots. Split the tier across both entries where broker grids permit. You authorized the exceptional 0.01 + 0.01 lots where a 0.01 tier cannot be split. This exceeds the original tier in total exposure.
3. Initial stop is beyond the sweep; an exact buffer is not confirmed. After +1R, move toward breakeven and trail by the original 1R distance, only while the setup is valid. The latest preference is to book 50% at +2R and trail the remainder; the booking R/percentage are editable as saved preferences. Handling for positions that cannot be halved, grouping of two entry legs and broker partial-fill behavior remain undecided.
4. Close the affected bot-owned trade when **both** opposite structure and opposite order flow confirm invalidation. Never automatically manage manual or other bots' trades. Actual live detectors and verified ownership are not implemented.
5. The 10% UTC day-start equity threshold is **alert-only**; trades should continue. You did not choose a per-trade risk percentage cap or bot-set maximum position count. Losses can exceed 10%, particularly during gaps or outages.
6. Only a setup with a genuinely independently validated probability estimate of at least 90% qualifies. You selected reaching the booking target before the stop as the outcome. No dataset or calibrated model exists in this package, and the treatment of trailing stops, invalidation closes, costs, timeouts and staged fills must be specified for model validation. A 90% model estimate cannot guarantee profits or a 90% win rate.

## What must be completed before trading

Real representative historical price and order-flow data; a defined target/outcome and independent out-of-sample model calibration; live feed/source verification and mappings; reliable structure/flow invalidation detectors; confirmed stop buffer and small-lot partial behavior; persistent bot-owned trade/fill reconciliation and idempotency; position/partial/stop management; broker- and account-specific integration testing; and explicit user authorization. None of those requirements can be bypassed by a settings toggle in this release.

## Local security and limitations

The one-click launcher binds to `127.0.0.1` only. Do not expose it to the public internet. Anyone who can operate the same Windows account or locally access the API may be able to view account details or change local research settings; secure the VPS and its Windows login. Passwords and broker credentials must remain in MT5 and should never be shared in chat. The application must run for the daily monitor; if it is offline, no alert is delivered. It does not install a Windows startup task.

Your previous local `config.json` is not included in this ZIP. To preserve v0.4 settings, stop FlowDesk, back up the new `app/config.json`, copy your old v0.4 `config.json` into `app`, and review it after restart. The new bot-plan defaults are applied when absent; a copied configuration cannot unlock orders.

Run tests for development: `python -m unittest discover -s tests -v` from the app folder. Mocks and unit tests cannot establish broker compatibility or strategy performance. The prior version's detailed bridge and strategy notes are preserved in `docs/V0.4-REFERENCE.md` and `docs/adapter-protocol.md`; where statements conflict, this README describes v0.5.
