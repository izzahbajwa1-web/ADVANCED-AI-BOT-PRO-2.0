package flowdesk;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import velox.api.layer1.annotations.Layer1ApiVersion;
import velox.api.layer1.annotations.Layer1ApiVersionValue;
import velox.api.layer1.annotations.Layer1SimpleAttachable;
import velox.api.layer1.annotations.Layer1StrategyName;
import velox.api.layer1.data.InstrumentInfo;
import velox.api.layer1.data.TradeInfo;
import velox.api.layer1.simplified.Api;
import velox.api.layer1.simplified.CustomModuleAdapter;
import velox.api.layer1.simplified.DepthDataListener;
import velox.api.layer1.simplified.InitialState;
import velox.api.layer1.simplified.TimeListener;
import velox.api.layer1.simplified.TradeDataListener;

/** Experimental READ-ONLY sender. Compile verified, not tested inside Bookmap.
 * Never places orders. Requires a separately licensed data feed.
 * The user must assert live mode; replay/live origin cannot be independently verified.
 */
@Layer1SimpleAttachable
@Layer1StrategyName("FlowDesk Research Bridge (read only)")
@Layer1ApiVersion(Layer1ApiVersionValue.VERSION1)
public class BookmapBridge implements CustomModuleAdapter, DepthDataListener, TradeDataListener, TimeListener {
    private static final int MAX_QUEUE = 4000;
    private static final int MAX_BATCH = 500;
    private static final int LEVELS = 10;
    private final Object lock = new Object();
    private final TreeMap<Integer,Integer> bids = new TreeMap<>(Collections.reverseOrder());
    private final TreeMap<Integer,Integer> asks = new TreeMap<>();
    private final Deque<Trade> trades = new ArrayDeque<>();
    private volatile long currentTimestampMs;
    private long depthTimestampMs;
    private boolean dirtyBook;
    private boolean tradeGap;
    private double tickSize;
    private String alias, provider, token;
    private URL endpoint;
    private ScheduledExecutorService sender;
    private volatile boolean enabled;

    private static final class Trade {
        final long time;
        final double price;
        final int size;
        final boolean buyer;
        Trade(long time, double price, int size, boolean buyer) {
            this.time=time; this.price=price; this.size=size; this.buyer=buyer;
        }
    }

    @Override
    public void initialize(String alias, InstrumentInfo info, Api api, InitialState state) {
        this.alias = alias;
        this.tickSize = info.pips;
        this.provider = System.getenv("FLOW_BOOKMAP_PROVIDER");
        this.token = System.getenv("FLOW_GATEWAY_TOKEN");
        String live = System.getenv("FLOW_BOOKMAP_LIVE");
        String port = System.getenv("FLOW_PORT");
        if (port == null || port.isEmpty()) port="8765";
        if (!"1".equals(live) || provider == null || provider.trim().isEmpty() ||
            token == null || token.length() < 16 || !Double.isFinite(tickSize) || tickSize <= 0 ||
            !port.matches("[0-9]{1,5}")) {
            System.err.println("FlowDesk bridge not enabled: configure provider, token (16+ chars), live assertion and port.");
            return;
        }
        provider = provider.trim();
        try { endpoint = new URL("http://127.0.0.1:" + port + "/api/bridge/events"); }
        catch (Exception ex) { System.err.println("FlowDesk bridge: invalid local endpoint."); return; }
        enabled = true;
        sender = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t=new Thread(r,"FlowDesk-Bookmap-Sender"); t.setDaemon(true); return t;
        });
        sender.scheduleWithFixedDelay(this::flushSafely, 250, 250, TimeUnit.MILLISECONDS);
        System.out.println("FlowDesk Bookmap bridge started for " + alias + " (read-only, source not verified).");
    }

    @Override
    public void onTimestamp(long nanoseconds) { currentTimestampMs = nanoseconds / 1_000_000L; }

    @Override
    public void onDepth(boolean isBid, int price, int size) {
        if (!enabled || price <= 0 || size < 0 || currentTimestampMs <= 0) return;
        synchronized (lock) {
            TreeMap<Integer,Integer> side = isBid ? bids : asks;
            if (size == 0) side.remove(price); else side.put(price,size);
            depthTimestampMs = currentTimestampMs;
            dirtyBook = true;
        }
    }

    @Override
    public void onTrade(double price, int size, TradeInfo tradeInfo) {
        if (!enabled || currentTimestampMs <= 0 || !Double.isFinite(price) || price <= 0 || size <= 0 || tradeInfo == null) return;
        synchronized (lock) {
            if (trades.size() >= MAX_QUEUE) { trades.clear(); tradeGap = true; }
            if (!trades.isEmpty() && currentTimestampMs < trades.peekLast().time) { tradeGap = true; return; }
            trades.addLast(new Trade(currentTimestampMs, price * tickSize, size, tradeInfo.isBidAggressor));
        }
    }

    private void flushSafely() {
        try { flush(); } catch (Exception ex) {
            synchronized(lock) { tradeGap=true; }
            System.err.println("FlowDesk Bookmap sender error: " + ex.getClass().getSimpleName());
        }
    }

    private void flush() {
        String book = null, batch = null;
        synchronized (lock) {
            if (dirtyBook && !bids.isEmpty() && !asks.isEmpty() && depthTimestampMs > 0) {
                dirtyBook = false;
                book = header("book", depthTimestampMs) + ",\"bids\":" + levels(bids) + ",\"asks\":" + levels(asks) + "}";
            }
            if (!trades.isEmpty()) {
                List<Trade> copied = new ArrayList<>();
                while (!trades.isEmpty() && copied.size()<MAX_BATCH) copied.add(trades.removeFirst());
                boolean gap=tradeGap; tradeGap=false;
                StringBuilder b = new StringBuilder(header("trades", copied.get(copied.size()-1).time));
                b.append(",\"continuity\":\"").append(gap?"gap":"ok").append("\",\"trades\":[");
                for (int i=0;i<copied.size();i++) {
                    Trade t=copied.get(i); if(i>0)b.append(',');
                    b.append("{\"timestamp_ms\":").append(t.time).append(",\"price\":").append(t.price)
                     .append(",\"size\":").append(t.size).append(",\"aggressor\":\"")
                     .append(t.buyer?"buy":"sell").append("\"}");
                }
                batch=b.append("]}").toString();
            }
        }
        // The market-data callbacks never perform network IO.
        if (book != null) post(book);
        if (batch != null && !post(batch)) synchronized(lock) { tradeGap = true; }
    }

    private String header(String type, long ts) {
        return "{\"type\":"+quote(type)+",\"platform\":\"bookmap\",\"provider\":"+quote(provider)+
            ",\"instrument\":"+quote(alias)+",\"timestamp_ms\":"+ts+
            ",\"timestamp_origin\":\"bookmap_event_ns\",\"declared_live\":true";
    }

    private String levels(TreeMap<Integer,Integer> side) {
        StringBuilder b=new StringBuilder("["); int i=0;
        for (Map.Entry<Integer,Integer> e:side.entrySet()) {
            if (i>=LEVELS) break; if(i++>0)b.append(',');
            b.append('[').append(e.getKey()*tickSize).append(',').append(e.getValue()).append(']');
        }
        return b.append(']').toString();
    }

    private static String quote(String s) {
        StringBuilder b=new StringBuilder("\"");
        for (int i=0;i<s.length();i++) {
            char c=s.charAt(i);
            if(c=='"'||c=='\\') b.append('\\').append(c);
            else if(c<32) b.append(String.format("\\u%04x",(int)c));
            else b.append(c);
        }
        return b.append('"').toString();
    }

    private boolean post(String body) {
        HttpURLConnection c=null;
        try {
            c=(HttpURLConnection)endpoint.openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(400); c.setReadTimeout(1000); c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Authorization","Bearer "+token);
            byte[] bytes=body.getBytes(StandardCharsets.UTF_8); c.setFixedLengthStreamingMode(bytes.length);
            try(OutputStream out=c.getOutputStream()){out.write(bytes);}
            int code=c.getResponseCode(); return code>=200 && code<300;
        } catch(Exception ex) { return false; }
        finally { if(c!=null)c.disconnect(); }
    }

    @Override
    public void stop() {
        enabled=false;
        if(sender!=null) sender.shutdownNow();
        synchronized(lock){bids.clear();asks.clear();trades.clear();}
    }
}
