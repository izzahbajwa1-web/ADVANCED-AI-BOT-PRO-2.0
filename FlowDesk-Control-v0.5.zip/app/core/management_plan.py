"""Pure, fail-closed position-management planning for FlowDesk-owned trades.

These are suggestions for synthetic/unit tests only. No broker call is made,
ownership and original risk are not reconstructed, and this module is NOT
wired to submit closes or stop changes. The +2R half-booking rule is the
user's latest confirmed preference. A live manager still needs a durable
ownership/fill journal, actual detectors and end-to-end broker validation.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
from .risk import broker_accepts_exact_volume
from .trade_policy import setup_validity
from .trailing import trail_after_one_r


def _positive(value, name):
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a positive finite number")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError(f"{name} must be a positive finite number") from None
    if not result.is_finite() or result <= 0:
        raise ValueError(f"{name} must be a positive finite number")
    return result


def partial_volume(*, volume, fraction, minimum, maximum, step):
    """Return an exact half-close plan only if BOTH resulting volumes are valid.

    No rounding up/down, group-leg netting, or whole-position close is chosen
    when the desired partial cannot be represented. The user's rule for an
    unsplittable position has not been decided.
    """
    vol = _positive(volume, "volume")
    frac = _positive(fraction, "fraction")
    if frac >= 1:
        raise ValueError("fraction must be less than one")
    mn, mx, st = (_positive(x, n) for x, n in
                  ((minimum, "minimum"), (maximum, "maximum"), (step, "step")))
    if not broker_accepts_exact_volume(volume=vol, minimum=mn, maximum=mx, step=st):
        return {"status": "INVALID_CURRENT_VOLUME", "close_volume": None, "remaining_volume": None}
    close, remain = vol * frac, vol * (Decimal(1) - frac)
    if (broker_accepts_exact_volume(volume=close, minimum=mn, maximum=mx, step=st)
            and broker_accepts_exact_volume(volume=remain, minimum=mn, maximum=mx, step=st)):
        return {"status": "EXACT", "close_volume": float(close), "remaining_volume": float(remain)}
    return {"status": "UNSPLITTABLE_NEEDS_USER_DECISION", "close_volume": None, "remaining_volume": None}


def plan_position_management(*, side, entry_price, original_stop, current_stop,
                             exit_quote, volume, minimum, maximum, step,
                             partial_recorded, opposite_structure, opposite_orderflow,
                             tick_size=None, booking_r=2, partial_fraction=0.5,
                             quote_time_ms=None, now_ms=None, max_quote_age_ms=5000):
    """Propose actions only; never submit or modify any live trade.

    Quote is bid for a buy and ask for a sell. A known/confirmed invalidation
    takes precedence over booking and trailing. Missing validity or an unknown
    durable partial record fails closed. Trailing follows the original +1R /
    1R rule while validity is known. The booking trigger is +2R by default.
    If a quote is missing/stale, nothing is proposed. Volume feasibility is
    checked per-position, not across two independent entry tickets.
    """
    if side not in ("BUY", "SELL"):
        raise ValueError("side must be BUY or SELL")
    if partial_recorded not in (True, False, None) or type(partial_recorded) not in (bool, type(None)):
        raise ValueError("partial_recorded must be true, false, or unknown")
    if type(now_ms) is not int or type(quote_time_ms) is not int or type(max_quote_age_ms) is not int or max_quote_age_ms <= 0:
        raise ValueError("valid quote and clock timestamps are required")
    if not 0 <= now_ms - quote_time_ms <= max_quote_age_ms:
        return {"validity": "UNKNOWN", "action": "WAIT", "partial": None, "trail": None,
                "reason": "Quote is stale, missing or future-dated; no action planned"}
    entry, stop, quote = (_positive(x, n) for x, n in
                          ((entry_price, "entry_price"), (original_stop, "original_stop"), (exit_quote, "exit_quote")))
    booking = _positive(booking_r, "booking_r")
    if booking < 2 or booking > 10:
        raise ValueError("booking_r must be between 2 and 10")
    if (side == "BUY" and stop >= entry) or (side == "SELL" and stop <= entry):
        raise ValueError("original stop must be on the protective side of entry")
    validity = setup_validity(opposite_structure=opposite_structure, opposite_orderflow=opposite_orderflow)
    if validity == "INVALID":
        return {"validity": validity, "action": "PROPOSE_CLOSE", "partial": None, "trail": None,
                "reason": "Both opposing structure and flow are confirmed; close this owned trade"}
    if validity == "UNKNOWN":
        return {"validity": validity, "action": "WAIT", "partial": None, "trail": None,
                "reason": "Live invalidation detector state is unknown"}
    risk = abs(entry - stop)
    gain = quote - entry if side == "BUY" else entry - quote
    booked_at_target = gain >= booking * risk
    partial = None
    if booked_at_target and partial_recorded is False:
        partial = partial_volume(volume=volume, fraction=partial_fraction,
                                 minimum=minimum, maximum=maximum, step=step)
    elif booked_at_target and partial_recorded is None:
        partial = {"status": "PARTIAL_HISTORY_UNKNOWN", "close_volume": None, "remaining_volume": None}
    elif partial_recorded is True:
        partial = {"status": "ALREADY_RECORDED", "close_volume": None, "remaining_volume": None}
    trail = trail_after_one_r(side=side, entry_price=entry, original_stop=stop,
                              current_stop=current_stop, exit_quote=quote, tick_size=tick_size)
    trailing = {"activated": trail.activated, "should_modify": trail.should_modify,
                "proposed_stop": trail.proposed_stop, "reason": trail.reason}
    if partial and partial["status"] == "EXACT":
        action = "PROPOSE_PARTIAL_THEN_RECHECK_TRAIL"
    elif partial and partial["status"] in ("UNSPLITTABLE_NEEDS_USER_DECISION", "PARTIAL_HISTORY_UNKNOWN", "INVALID_CURRENT_VOLUME"):
        action = "NEEDS_REVIEW"
    elif trailing["should_modify"]:
        action = "PROPOSE_TRAIL"
    else:
        action = "WAIT"
    return {"validity": validity, "action": action, "partial": partial, "trail": trailing,
            "target_reached": booked_at_target, "gain_r": float(gain / risk),
            "reason": "Research proposal only; no broker operation or fill has occurred"}
