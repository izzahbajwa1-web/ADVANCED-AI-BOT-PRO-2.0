"""Research-only gate for model-estimated win probability; no model is provided."""
from __future__ import annotations
import math


def probability_gate(estimated_probability, *, model_validated: bool):
    """Apply 0.90 only AFTER independent model validation; no validation occurs here.

    The caller is responsible for determining calibration, sample adequacy,
    data provenance, target outcome, costs and out-of-sample validation. A
    caller-supplied boolean is NOT evidence of validation. No model is wired
    to this build, so its default state is ineligible.
    """
    if model_validated is not True or estimated_probability is None:
        return {"eligible": False, "estimated_probability": None,
                "reason": "Calibrated probability model is not available or validated"}
    if (isinstance(estimated_probability, bool) or not isinstance(estimated_probability, (int, float))
            or not math.isfinite(estimated_probability) or not 0 <= estimated_probability <= 1):
        raise ValueError("estimated_probability must be between 0 and 1")
    return {"eligible": estimated_probability >= 0.90,
            "estimated_probability": float(estimated_probability),
            "reason": "Model-supplied estimate; not a guaranteed probability or profit"}
