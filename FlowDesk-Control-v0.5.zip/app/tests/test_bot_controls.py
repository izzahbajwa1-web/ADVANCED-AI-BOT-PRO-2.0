import tempfile
import unittest
from pathlib import Path
from core.bot_controls import BotController, validate_plan
from core.config import ConfigStore


class BotControlTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.store=ConfigStore(Path(self.tmp.name)/'config.json');self.controller=BotController(self.store)
    def test_default_contains_confirmed_latest_choices(self):
        p=self.controller.status()['plan']
        self.assertEqual(p['scope'],'mt5_market_watch');self.assertEqual(p['managed_positions'],'flowdesk_only')
        self.assertEqual(p['book_at_r'],2);self.assertEqual(p['book_percent'],50)
        self.assertEqual(p['trailing_activation_r'],1);self.assertEqual(p['trailing_distance_r'],1)
        self.assertEqual(p['unsplittable_partial'],'unresolved');self.assertEqual(p['minimum_probability'],.9)
    def test_start_never_enables_orders_even_when_connected(self):
        for connected in (False,True):
            s=self.controller.check_start(connected)
            self.assertFalse(s['started']);self.assertFalse(s['start_available']);self.assertTrue(s['real_orders_locked'])
            self.assertTrue(any('90%' in b for b in s['blockers']))
        self.assertFalse(self.controller.stop()['started'])
    def test_settings_saved_without_modifying_risk_or_enabling_orders(self):
        before=self.store.read()['risk']
        p=self.controller.save_plan({'book_at_r':4,'book_percent':50})
        self.assertEqual(p['book_at_r'],4);self.assertEqual(self.store.read()['risk'],before)
        reloaded=BotController(ConfigStore(self.store.path)).status(True)
        self.assertEqual(reloaded['plan']['book_at_r'],4);self.assertTrue(reloaded['real_orders_locked'])
    def test_rejects_unsafe_extra_fields_and_invalid_values(self):
        invalid=[{'book_at_r':2,'book_percent':50,'enabled':True},
                 {'book_at_r':2,'book_percent':50,'model_validated':True},
                 {'book_at_r':1,'book_percent':50},{'book_at_r':11,'book_percent':50},
                 {'book_at_r':2,'book_percent':100},{'book_at_r':2,'book_percent':0},
                 {'book_at_r':True,'book_percent':50}]
        for p in invalid:
            with self.subTest(p=p),self.assertRaises(ValueError):validate_plan(p)
    def test_more_than_30_market_mappings_are_not_a_hidden_position_limit(self):
        for i in range(35):
            self.store.add_mapping({'mt5_symbol': f'SYM{i}', 'platform':'bookmap',
                                    'provider':'mock', 'instrument':f'FEED{i}',
                                    'is_proxy':False, 'reviewed':True})
        self.assertEqual(len(self.store.read()['mappings']),35)
        self.assertEqual(len(self.store.read()['watchlist']),35)
        self.assertTrue(self.controller.status(True)['real_orders_locked'])

    def test_forged_config_does_not_remove_gate(self):
        self.store.data['bot_plan']={'scope':'all_account','book_at_r':2,'book_percent':50,'minimum_probability':0}
        s=self.controller.status(True)
        self.assertTrue(s['real_orders_locked']);self.assertEqual(s['plan']['minimum_probability'],.9)
        self.assertEqual(s['plan']['managed_positions'],'flowdesk_only')

if __name__=='__main__':unittest.main()
