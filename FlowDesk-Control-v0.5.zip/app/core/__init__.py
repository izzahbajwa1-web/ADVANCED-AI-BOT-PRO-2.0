"""FlowDesk research-only infrastructure. This package never sends orders."""
