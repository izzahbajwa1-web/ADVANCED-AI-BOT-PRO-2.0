"""Optional READ-ONLY connection to an already signed-in Windows MT5 terminal."""
from __future__ import annotations
import os
import threading
import math


class MT5Reader:
    def __init__(self, preview=False):
        self._lock = threading.RLock()
        self._mt5 = None
        self.preview = preview
        self.message = "Not connected"

    def connect(self):
        with self._lock:
            if self.preview:
                self.message = "The preview cannot access your MT5 terminal. Run FlowDesk on your Windows PC."
                return False, self.message
            if os.name != "nt":
                self.message = "The MetaTrader5 Python bridge in this project is intended for Windows."
                return False, self.message
            try:
                import MetaTrader5 as mt5
            except (ImportError, OSError, RuntimeError) as exc:
                self.message = (f"The MT5 connector could not load ({type(exc).__name__}). "
                                "Check 64-bit Windows and the setup guide.")
                return False, self.message
            if not mt5.initialize(timeout=8_000):
                self.message = f"MT5 initialization failed: {mt5.last_error()}"
                return False, self.message
            terminal = mt5.terminal_info()
            account = mt5.account_info()
            if not terminal or not terminal.connected or not account:
                mt5.shutdown()
                self.message = "Open MT5, sign in to Exness, and verify the terminal is connected."
                return False, self.message
            self._mt5 = mt5
            self.message = "Read-only connection established"
            return True, self.message

    def snapshot(self, symbols=()):
        with self._lock:
            base = {"connected": False, "message": self.message, "account": None, "quotes": []}
            if self._mt5 is None:
                return base
            try:
                terminal, acct = self._mt5.terminal_info(), self._mt5.account_info()
                if not terminal or not terminal.connected or not acct:
                    self.message = "MT5 connection lost; reconnect from the dashboard."
                    self._mt5.shutdown()
                    self._mt5 = None
                    base["message"] = self.message
                    return base
                base["connected"] = True
                base["message"] = "Read-only connection established"
                base["account"] = {"login": acct.login, "balance": acct.balance, "equity": acct.equity,
                                   "profit": acct.profit, "currency": acct.currency,
                                   "server": acct.server}
                for sym in list(symbols):
                    if not isinstance(sym, str) or not sym or len(sym) > 64:
                        continue
                    info = self._mt5.symbol_info(sym)
                    tick = self._mt5.symbol_info_tick(sym) if info else None
                    base["quotes"].append({"symbol": sym, "bid": tick.bid if tick else None,
                        "ask": tick.ask if tick else None, "timestamp_ms": getattr(tick, "time_msc", 0) if tick else None,
                        "available": bool(info and tick)})
            except Exception as exc:
                base["connected"] = False
                base["account"] = None
                base["message"] = f"MT5 read failed: {type(exc).__name__}. Reconnect from the dashboard."
                self._mt5 = None
            return base

    def market_watch(self):
        """Read all currently visible Market Watch names; never enable symbols or trade."""
        with self._lock:
            if self._mt5 is None:
                return {"connected": False, "status": "DISCONNECTED", "symbols": [],
                        "message": "Connect MT5 to load its Market Watch."}
            try:
                items = self._mt5.symbols_get()
                if items is None:
                    return {"connected": True, "status": "ERROR", "symbols": [],
                            "message": "MT5 could not return its Market Watch."}
                rows, seen = [], set()
                for item in items:
                    if not bool(getattr(item, "visible", False)):
                        continue
                    name = getattr(item, "name", None)
                    if not isinstance(name, str) or not name or name in seen:
                        continue
                    seen.add(name)
                    path = getattr(item, "path", "")
                    desc = getattr(item, "description", "")
                    rows.append({"symbol": name,
                                 "broker_group": path if isinstance(path, str) else "",
                                 "description": desc if isinstance(desc, str) else ""})
                rows.sort(key=lambda x: x["symbol"].casefold())
                return {"connected": True, "status": "RECEIVED_UNVERIFIED", "symbols": rows,
                        "message": "Visible symbols from MT5 Market Watch; broker availability is not verified."}
            except Exception as exc:
                return {"connected": True, "status": "ERROR", "symbols": [],
                        "message": f"Market Watch read failed ({type(exc).__name__})."}

    def quote(self, symbol):
        """Read the latest bid/ask for one Market Watch symbol without selecting it."""
        with self._lock:
            if self._mt5 is None or not isinstance(symbol, str) or not symbol:
                return None
            try:
                tick = self._mt5.symbol_info_tick(symbol)
                if tick is None:
                    return None
                bid, ask, timestamp = getattr(tick, "bid", None), getattr(tick, "ask", None), getattr(tick, "time_msc", None)
                if (isinstance(bid, bool) or isinstance(ask, bool) or
                    not isinstance(bid, (int, float)) or not isinstance(ask, (int, float)) or
                    not math.isfinite(bid) or not math.isfinite(ask) or bid <= 0 or ask <= 0 or
                    type(timestamp) is not int):
                    return None
                return {"bid": float(bid), "ask": float(ask), "timestamp_ms": timestamp}
            except Exception:
                return None

    def positions(self):
        """Read positions for display; ownership is NOT inferred from MT5 magic alone."""
        with self._lock:
            if self._mt5 is None:
                return {"connected": False, "status": "DISCONNECTED", "positions": [],
                        "message": "Connect MT5 to see open positions."}
            try:
                positions = self._mt5.positions_get()
                if positions is None:
                    return {"connected": True, "status": "ERROR", "positions": [],
                            "message": "MT5 could not return positions; an empty list is not assumed."}
                def numeric(obj, key):
                    value = getattr(obj, key, None)
                    if isinstance(value, bool) or not isinstance(value, (int, float)):
                        return None
                    return float(value) if math.isfinite(value) else None
                rows = []
                for pos in positions:
                    side = getattr(pos, "type", None)
                    direction = ("BUY" if side == self._mt5.POSITION_TYPE_BUY else
                                 "SELL" if side == self._mt5.POSITION_TYPE_SELL else "UNKNOWN")
                    ticket = getattr(pos, "ticket", None)
                    rows.append({"ticket": ticket if type(ticket) is int else None,
                        "symbol": str(getattr(pos, "symbol", "")), "side": direction,
                        "volume": numeric(pos, "volume"), "entry": numeric(pos, "price_open"),
                        "current": numeric(pos, "price_current"), "stop_loss": numeric(pos, "sl"),
                        "take_profit": numeric(pos, "tp"), "profit": numeric(pos, "profit"),
                        "ownership_verified": False})
                return {"connected": True, "status": "READ_ONLY", "positions": rows,
                        "message": "Read-only list. Bot ownership, close and stop controls are not operational."}
            except Exception as exc:
                return {"connected": True, "status": "ERROR", "positions": [],
                        "message": f"Position read failed ({type(exc).__name__})."}

    def broker_check(self, payload):
        """Ask MT5 to check a manual market-order example; never send it.

        This uses current account data and the existing mock-tested preflight.
        It is a broker compatibility check, NOT a strategy qualification.
        """
        if not isinstance(payload, dict) or set(payload) != {
            "symbol", "side", "volume", "stop_loss", "fill_policy", "confirm_account"
        }:
            raise ValueError("Provide the broker-check fields only")
        if payload.get("confirm_account") is not True:
            raise ValueError("Confirm the connected MT5 account before a broker check")
        if payload.get("fill_policy") not in ("FOK", "IOC", "RETURN"):
            raise ValueError("Choose FOK, IOC or RETURN filling")
        with self._lock:
            if self._mt5 is None:
                raise ValueError("Connect an MT5 terminal first")
            mt5 = self._mt5
            account = mt5.account_info()
            if not account or type(getattr(account, "login", None)) is not int or not getattr(account, "server", None):
                raise ValueError("Could not verify the connected MT5 account")
            try:
                import time
                from .mt5_execution import OrderIntent, MT5ExecutionAdapter, BrokerPreflightRejected
                fill = {"FOK": mt5.ORDER_FILLING_FOK, "IOC": mt5.ORDER_FILLING_IOC,
                        "RETURN": mt5.ORDER_FILLING_RETURN}[payload["fill_policy"]]
                intent = OrderIntent(payload["symbol"], payload["side"], payload["volume"],
                                     payload["stop_loss"], "MARKET")
                result = MT5ExecutionAdapter(mt5).preflight(
                    intent, expected_login=account.login, expected_server=account.server,
                    now_ms=int(time.time() * 1000), fill_policy=fill, deviation_points=20, magic=4600401)
                return {"checked": result["checked"], "margin_estimate": result["margin_estimate"],
                        "message": "Broker check only. No order was sent, and a pass does not guarantee execution."}
            except BrokerPreflightRejected as exc:
                raise ValueError(str(exc)) from None
            except (AttributeError, TypeError):
                raise ValueError("The MT5 broker-check capability is unavailable") from None

    def bars(self, symbol: str, count: int = 30, timeframe: str = "M5"):
        """Read closed M5, H4 or D1 bars starting at position 1."""
        with self._lock:
            if not self._mt5:
                return []
            names={"M5":"TIMEFRAME_M5", "H4":"TIMEFRAME_H4", "D1":"TIMEFRAME_D1"}
            if timeframe not in names:
                raise ValueError("Unsupported research timeframe")
            raw = self._mt5.copy_rates_from_pos(symbol, getattr(self._mt5, names[timeframe]), 1, count)
            if raw is None:
                return []
            from .strategy import Bar
            return [Bar(int(r["time"]) * 1000, float(r["open"]), float(r["high"]),
                        float(r["low"]), float(r["close"]), True) for r in raw]

    def disconnect(self):
        with self._lock:
            if self._mt5:
                self._mt5.shutdown()
                self._mt5 = None
            self.message = "Not connected"
