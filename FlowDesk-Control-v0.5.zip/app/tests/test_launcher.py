"""Mock tests for the portable local-only starter; no real MT5 or orders."""
import contextlib
import io
import os
import unittest
from unittest.mock import MagicMock, patch

import starter


class LauncherTests(unittest.TestCase):
    def test_bind_success_precedes_browser_open_and_closes_cleanly(self):
        instance = MagicMock()
        instance.serve_forever.side_effect = KeyboardInterrupt
        with patch.dict(os.environ, {"FLOW_PORT": "18767", "FLOW_NO_BROWSER": "0"}), \
             patch.object(starter.server, "ThreadingHTTPServer", return_value=instance) as bind, \
             patch.object(starter.threading, "Thread") as thread, \
             patch.object(starter.webbrowser, "open", return_value=True) as browser, \
             patch.object(starter.server.SERVICE.reader, "disconnect") as disconnect, \
             patch.object(starter.server.SERVICE, "start_background") as start_monitor, \
             patch.object(starter.server.SERVICE, "stop_background") as stop_monitor, \
             contextlib.redirect_stdout(io.StringIO()):
            def verify_bound(url, new):
                bind.assert_called_once_with(("127.0.0.1", 18767), starter.server.Handler)
                self.assertEqual(url, "http://127.0.0.1:18767/")
                self.assertEqual(new, 2)
                return True
            browser.side_effect = verify_bound
            self.assertEqual(starter.main(), 0)
            thread.return_value.start.assert_called_once()
            instance.server_close.assert_called_once()
            start_monitor.assert_called_once()
            stop_monitor.assert_called_once()
            disconnect.assert_called_once()

    def test_busy_port_does_not_open_some_other_app_in_browser(self):
        with patch.dict(os.environ, {"FLOW_PORT": "18767", "FLOW_NO_BROWSER": "0"}), \
             patch.object(starter.server, "ThreadingHTTPServer", side_effect=OSError("busy")), \
             patch.object(starter.webbrowser, "open") as browser, \
             patch.object(starter.threading, "Thread") as thread, \
             contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(starter.main(), 1)
            browser.assert_not_called()
            thread.assert_not_called()
            self.assertIn("port may already be in use", output.getvalue())

    def test_invalid_port_does_not_bind(self):
        for port in ("wrong", "0", "65536", "-1"):
            with self.subTest(port=port), \
                 patch.dict(os.environ, {"FLOW_PORT": port}), \
                 patch.object(starter.server, "ThreadingHTTPServer") as bind, \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(starter.main(), 1)
                bind.assert_not_called()

    def test_failed_browser_displays_manual_address(self):
        instance = MagicMock()
        instance.serve_forever.side_effect = KeyboardInterrupt
        with patch.dict(os.environ, {"FLOW_PORT": "18767", "FLOW_NO_BROWSER": "0"}), \
             patch.object(starter.server, "ThreadingHTTPServer", return_value=instance), \
             patch.object(starter.threading, "Thread"), \
             patch.object(starter.webbrowser, "open", return_value=False), \
             patch.object(starter.server.SERVICE.reader, "disconnect"), \
             patch.object(starter.server.SERVICE, "start_background"), \
             patch.object(starter.server.SERVICE, "stop_background"), \
             contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(starter.main(), 0)
            self.assertIn("http://127.0.0.1:18767/", output.getvalue())
            self.assertIn("Browser did not open", output.getvalue())

    def test_connect_reports_read_only_status(self):
        with patch.object(starter.server.SERVICE, "connect_mt5", return_value={"ok": True}), \
             contextlib.redirect_stdout(io.StringIO()) as output:
            starter.connect_mt5_read_only()
            self.assertIn("read-only", output.getvalue())

    def test_connect_exception_is_nonfatal_and_logged(self):
        with patch.object(starter.server.SERVICE, "connect_mt5", side_effect=RuntimeError("secret")), \
             patch.object(starter.server.SERVICE, "log") as log, \
             contextlib.redirect_stdout(io.StringIO()) as output:
            starter.connect_mt5_read_only()
            self.assertIn("Automatic connection failed", output.getvalue())
            self.assertNotIn("secret", output.getvalue())
            log.assert_called_once()


if __name__ == "__main__":
    unittest.main()
