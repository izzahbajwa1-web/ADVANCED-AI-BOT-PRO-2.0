"""Optional Trading Economics calendar; never fabricates events or sends orders."""
from __future__ import annotations
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import json
import os
import threading
import time


class CalendarClient:
    """Cached, non-blocking calendar reader. Key is only read from the server env.

    Provider timestamp is UTC per its API schema. Subscription rights, event
    completeness, update latency and revisions must be verified by the user.
    No automatic news-based trading decisions are made.
    """
    def __init__(self, key=None, *, preview=False, opener=urlopen):
        self.key = (key if key is not None else os.getenv('FLOW_TE_API_KEY','')).strip()
        self.demo_key_rejected = self.key.lower() == 'guest:guest'
        if self.demo_key_rejected: self.key = ''
        if preview: self.key = ''  # preview never uses the user's credentials
        self.opener = opener
        self.lock=threading.Lock()
        self.last_attempt=0.0
        self.in_flight=False
        self.state={"provider":"Trading Economics", "configured":bool(self.key),
                    "status":"NOT_CONFIGURED" if not self.key else "WAITING",
                    "last_fetched_ms":None, "events":[],
                    "message":("Guest/demo calendar credentials are not accepted." if self.demo_key_rejected else "Set FLOW_TE_API_KEY locally for your subscribed calendar feed.") if not self.key else "Waiting for first fetch."}

    def snapshot(self):
        with self.lock:
            # A dashboard refresh can trigger a background refresh at most every 5 minutes.
            if self.key and not self.in_flight and time.monotonic()-self.last_attempt >= 300:
                self.in_flight=True; self.last_attempt=time.monotonic()
                threading.Thread(target=self._refresh,daemon=True).start()
            return {**self.state,"events":[dict(e) for e in self.state['events']]}

    def _refresh(self):
        now=datetime.now(timezone.utc)
        start=now.date().isoformat(); end=(now.date()+timedelta(days=2)).isoformat()
        # Do not log the URL; the provider uses a query parameter for the secret.
        query=urlencode({'c':self.key,'f':'json'})
        url=f'https://api.tradingeconomics.com/calendar/country/All/{start}/{end}?{query}'
        update={"status":"ERROR", "events":[], "message":"Calendar fetch failed. Check your subscription, key and connection locally."}
        try:
            req=Request(url,headers={'Accept':'application/json','User-Agent':'FlowDeskResearch/0.4'})
            with self.opener(req,timeout=8) as response:
                payload=response.read(2_000_001)
            if len(payload)>2_000_000: raise ValueError('calendar response too large')
            data=json.loads(payload.decode('utf-8'))
            events=self._normalize(data,now=now)
            update={"status":"RECEIVED_UNVERIFIED", "last_fetched_ms":int(now.timestamp()*1000),
                    "events":events, "message":"Provider data received; availability and timing are not independently verified."}
        except Exception:
            # Do not echo provider exceptions: their text may contain the secret URL.
            pass
        finally:
            with self.lock:
                self.state.update(update); self.in_flight=False

    @staticmethod
    def _normalize(data, *, now):
        if not isinstance(data,list): raise ValueError('expected calendar array')
        events=[]
        for item in data[:10_000]:
            if not isinstance(item,dict): continue
            raw=item.get('Date'); name=item.get('Event'); importance=item.get('Importance')
            if not isinstance(raw,str) or not isinstance(name,str) or not name.strip(): continue
            if type(importance) is not int or importance not in (1,2,3): continue
            try:
                dt=datetime.fromisoformat(raw.replace('Z','+00:00'))
                if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
                dt=dt.astimezone(timezone.utc)
            except ValueError: continue
            if dt < now or dt > now+timedelta(days=2): continue
            def text(key):
                value=item.get(key)
                return str(value)[:180] if value is not None else ''
            events.append({"utc_time":dt.isoformat().replace('+00:00','Z'), "title":name[:180],
                           "country":text('Country'), "currency":text('Currency'), "importance":importance,
                           "forecast":text('Forecast'), "previous":text('Previous'), "actual":text('Actual')})
        events.sort(key=lambda x:x['utc_time'])
        return events[:40]
