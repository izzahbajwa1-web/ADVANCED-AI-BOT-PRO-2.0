"""1R trailing-stop calculations only; never sends an MT5 stop modification."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR


def _positive(value, name):
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a positive finite number")
    try:
        v = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError(f"{name} must be a positive finite number") from None
    if not v.is_finite() or v <= 0:
        raise ValueError(f"{name} must be a positive finite number")
    return v


@dataclass(frozen=True)
class TrailingDecision:
    activated: bool
    should_modify: bool
    proposed_stop: float | None
    original_risk_distance: float
    reason: str


def trail_after_one_r(*, side: str, entry_price, original_stop, current_stop, exit_quote, tick_size=None):
    """1R after +1R, based on the original filled entry and original stop.

    For BUY, exit_quote must be the current bid; for SELL it must be the ask.
    At +1R the theoretical stop is entry price; after that it is 1R behind
    the exit quote. It can only tighten, never loosen. A tick_size (when
    supplied) rounds BUY stops down and SELL stops up. This is a calculation,
    not an MT5 modification. Broker stop/freeze levels, quote freshness,
    costs, partial fills and rejected modifications require further work.
    """
    if not isinstance(side, str) or side.upper() not in {"BUY", "SELL"}:
        raise ValueError("side must be BUY or SELL")
    side = side.upper()
    entry = _positive(entry_price, "entry_price")
    initial = _positive(original_stop, "original_stop")
    current = _positive(current_stop, "current_stop")
    quote = _positive(exit_quote, "exit_quote")
    tick = _positive(tick_size, "tick_size") if tick_size is not None else None
    if side == "BUY":
        if initial >= entry:
            raise ValueError("A BUY original stop must be below the entry")
        risk = entry - initial
        if current >= quote:
            return TrailingDecision(False, False, None, float(risk), "current stop is at/through the bid; verify position and quote")
        activated = quote - entry >= risk
        target = quote - risk
        if tick is not None:
            target = (target / tick).to_integral_value(rounding=ROUND_FLOOR) * tick
        tighter = target > current
    else:
        if initial <= entry:
            raise ValueError("A SELL original stop must be above the entry")
        risk = initial - entry
        if current <= quote:
            return TrailingDecision(False, False, None, float(risk), "current stop is at/through the ask; verify position and quote")
        activated = entry - quote >= risk
        target = quote + risk
        if tick is not None:
            target = (target / tick).to_integral_value(rounding=ROUND_CEILING) * tick
        tighter = target < current
    if not activated:
        return TrailingDecision(False, False, None, float(risk), "1R activation has not been reached")
    if not tighter or target <= 0:
        return TrailingDecision(True, False, None, float(risk), "existing stop is already as tight or tighter")
    return TrailingDecision(True, True, float(target), float(risk), "proposed tighter stop; broker validation required")
