//+------------------------------------------------------------------+
//| FlowDeskPanel.mq5                                                |
//| Research-only MT5 chart panel. It NEVER sends orders.              |
//| Source provided for review; not compiled/tested in MetaEditor.   |
//+------------------------------------------------------------------+
#property copyright "FlowDesk Research"
#property version   "0.10"
#property strict
#property description "Read-only account panel; external flow appears in the FlowDesk browser dashboard."

input int PanelLeft = 18;
input int PanelTop  = 28;
const string P = "FlowDeskPanel_";

void Rect(const string name, const int x, const int y, const int width, const int height,
          const color background, const color border)
{
   string id=P+name;
   if(ObjectFind(0,id)<0) ObjectCreate(0,id,OBJ_RECTANGLE_LABEL,0,0,0);
   ObjectSetInteger(0,id,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,id,OBJPROP_XDISTANCE,PanelLeft+x);
   ObjectSetInteger(0,id,OBJPROP_YDISTANCE,PanelTop+y);
   ObjectSetInteger(0,id,OBJPROP_XSIZE,width);
   ObjectSetInteger(0,id,OBJPROP_YSIZE,height);
   ObjectSetInteger(0,id,OBJPROP_BGCOLOR,background);
   ObjectSetInteger(0,id,OBJPROP_COLOR,border);
   ObjectSetInteger(0,id,OBJPROP_BORDER_TYPE,BORDER_FLAT);
   ObjectSetInteger(0,id,OBJPROP_BACK,false);
   ObjectSetInteger(0,id,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,id,OBJPROP_HIDDEN,true);
}

void Label(const string name, const int x, const int y, const string text,
           const int size, const color text_color, const string font="Arial")
{
   string id=P+name;
   if(ObjectFind(0,id)<0) ObjectCreate(0,id,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,id,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,id,OBJPROP_XDISTANCE,PanelLeft+x);
   ObjectSetInteger(0,id,OBJPROP_YDISTANCE,PanelTop+y);
   ObjectSetInteger(0,id,OBJPROP_FONTSIZE,size);
   ObjectSetInteger(0,id,OBJPROP_COLOR,text_color);
   ObjectSetInteger(0,id,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,id,OBJPROP_HIDDEN,true);
   ObjectSetString(0,id,OBJPROP_FONT,font);
   ObjectSetString(0,id,OBJPROP_TEXT,text);
}

void RenderPanel()
{
   color bg=C'21,22,25';
   color card=C'29,29,32';
   color edge=C'105,65,52';
   color soft=C'153,149,146';
   color text=C'239,232,226';
   color warm=C'232,151,112';
   Rect("background",0,0,540,265,bg,edge);
   Rect("topline",0,0,540,3,warm,warm);
   Label("brand",18,15,"FLOWDESK  /  RESEARCH",13,text,"Arial Bold");
   Label("subtitle",18,40,"MT5 ACCOUNT PANEL  -  READ ONLY",8,soft);
   Label("lock",365,19,"EXECUTION UNAVAILABLE",8,warm,"Arial Bold");
   Rect("balanceCard",15,67,160,73,card,C'63,51,46');
   Rect("equityCard",190,67,160,73,card,C'63,51,46');
   Rect("profitCard",365,67,160,73,card,C'63,51,46');
   string currency=AccountInfoString(ACCOUNT_CURRENCY);
   Label("balanceTitle",27,77,"BALANCE",8,soft,"Arial Bold");
   Label("equityTitle",202,77,"EQUITY",8,soft,"Arial Bold");
   Label("profitTitle",377,77,"FLOATING P/L",8,soft,"Arial Bold");
   Label("balanceValue",27,99,DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE),2)+" "+currency,12,text,"Arial Bold");
   Label("equityValue",202,99,DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY),2)+" "+currency,12,text,"Arial Bold");
   Label("profitValue",377,99,DoubleToString(AccountInfoDouble(ACCOUNT_PROFIT),2)+" "+currency,12,text,"Arial Bold");
   Label("chartTitle",18,157,"CHART SYMBOL",8,soft,"Arial Bold");
   Label("chartValue",18,176,_Symbol,11,text,"Arial Bold");
   Label("flowTitle",195,157,"ORDER FLOW",8,soft,"Arial Bold");
   Label("flowValue",195,176,"See local dashboard",10,text);
   Label("strategyTitle",365,157,"STRATEGY",8,soft,"Arial Bold");
   Label("strategyValue",365,176,"Research only",10,text);
   Rect("separator",15,214,510,1,C'64,50,44',C'64,50,44');
   Label("footer",18,227,"NO ORDERS  /  NO EXECUTION  /  SETTINGS NOT ENFORCED",8,warm,"Arial Bold");
   ChartRedraw(0);
}

int OnInit()
{
   EventSetTimer(1);
   RenderPanel();
   return(INIT_SUCCEEDED);
}
void OnTimer() { RenderPanel(); }
void OnTick()  { /* The panel refreshes on the timer; no trading logic. */ }
void OnDeinit(const int reason)
{
   EventKillTimer();
   ObjectsDeleteAll(0,P,-1,-1);
   ChartRedraw(0);
}
