# Bookmap adapter (experimental)

`FlowDeskBookmapBridge.jar` is built from `src/flowdesk/BookmapBridge.java` using Bookmap's `api-core` and `api-simplified` 7.1.0.35. Compilation succeeded; **no Bookmap runtime or real feed test was possible**. Compatibility, throughput, correctness of provider semantics, and reconnect handling must be validated against your installation.

The add-on is disabled unless all three environment variables are present at Bookmap startup:

- `FLOW_GATEWAY_TOKEN`: same strong random token as the local FlowDesk process (minimum 16 characters).
- `FLOW_BOOKMAP_PROVIDER`: exact human-selected provider label used in the dashboard mapping.
- `FLOW_BOOKMAP_LIVE=1`: your own assertion that Bookmap is using live data, not replay. This is not independently verified.

It sends to the loopback server on `FLOW_PORT` (default 8765). It reads Bookmap's API event clock and forwards the current top ten market-by-price levels and batches of trades. No order API is called. Provider and instrument names, timestamp semantics, aggressor flags, data entitlements, gaps, and cross-market proxy relationships require manual verification.

See the main README before use. Bookmap SDK reference: https://bookmap.com/knowledgebase/docs/API-Tutorial
