"""Staged sweep/BOS/FVG research calculations; never sends orders.

This is a narrow, explicit interpretation, not a validated strategy. It uses
closed candles for sweep/BOS/FVG and an optional fresh quote for the retest.
A research sequence is NOT proof that either stage was executed.
"""
from __future__ import annotations
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR
import math
from .risk import broker_accepts_exact_volume


def _decimal(value, name):
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a positive finite number")
    try:
        value = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError(f"{name} must be a positive finite number") from None
    if not value.is_finite() or value <= 0:
        raise ValueError(f"{name} must be a positive finite number")
    return value


def plan_staged_lots(*, tier, minimum, maximum, step):
    """Split the confirmed USD tier as closely as possible, first no larger.

    Both legs must match the supplied exact broker volume grid. The user
    specifically approved a 0.01 + 0.01 exception when a 0.01 tier cannot be
    split because of broker minimums. For other unsplittable tiers, do not
    invent an exception. This function checks volume arithmetic only; it
    cannot check available margin, aggregate exposure, permissions or fills.
    """
    total, lo, hi, increment = [_decimal(x, n) for x,n in
                                  ((tier,"tier"),(minimum,"minimum"),(maximum,"maximum"),(step,"step"))]
    if hi < lo:
        raise ValueError("invalid broker volume limits")
    def ok(v):
        return broker_accepts_exact_volume(volume=v, minimum=lo, maximum=hi, step=increment)
    first = None
    if total / 2 >= lo and (total - 2 * lo) % increment == 0:
        k = ((total / 2 - lo) / increment).to_integral_value(rounding=ROUND_FLOOR)
        candidate = lo + k * increment
        if ok(candidate) and ok(total - candidate):
            first = candidate
    if first is not None:
        return {"first_lots": float(first), "second_lots": float(total-first),
                "combined_lots": float(total), "extra_over_tier": False,
                "status": "SPLIT", "broker_volume_checked": True}
    if total == Decimal('0.01') and ok(total):
        return {"first_lots": 0.01, "second_lots": 0.01, "combined_lots": 0.02,
                "extra_over_tier": True, "status": "SMALL_TIER_EXCEPTION",
                "broker_volume_checked": True}
    return {"first_lots": None, "second_lots": None, "combined_lots": None,
            "extra_over_tier": False, "status": "UNRESOLVED_BROKER_VOLUME",
            "broker_volume_checked": True}


def proposed_sweep_stop(*, side, sweep_extreme, tick_size, buffer_ticks=1):
    """Propose a stop beyond the sweep, conservatively tick-aligned.

    One tick is a provisional research buffer, not a confirmed live rule.
    A BUY stop is below the low; a SELL stop is above the high. No broker
    stop/freeze level, spread, gaps or execution is checked here.
    """
    if side not in ("BUY", "SELL"):
        raise ValueError("side must be BUY or SELL")
    extreme = _decimal(sweep_extreme, "sweep_extreme")
    tick = _decimal(tick_size, "tick_size")
    if type(buffer_ticks) is not int or buffer_ticks < 1:
        raise ValueError("buffer_ticks must be a positive integer")
    if side == "BUY":
        stop = ((extreme - tick * buffer_ticks) / tick).to_integral_value(rounding=ROUND_FLOOR) * tick
    else:
        stop = ((extreme + tick * buffer_ticks) / tick).to_integral_value(rounding=ROUND_CEILING) * tick
    if stop <= 0:
        raise ValueError("proposed stop is not positive")
    return float(stop)


def _valid_bars(bars):
    prior = -1
    for b in bars:
        vals = (b.open, b.high, b.low, b.close)
        if (b.closed is not True or any(isinstance(x, bool) or not isinstance(x,(int,float))
                or not math.isfinite(x) or x <= 0 for x in vals)
                or b.low > min(b.open,b.close) or b.high < max(b.open,b.close)
                or b.low > b.high or type(b.timestamp_ms) is not int or b.timestamp_ms <= prior):
            raise ValueError("bars must be valid, closed and strictly time ordered")
        prior=b.timestamp_ms


def analyze_sequence(bars, *, lookback=12, quote=None, now_ms=None,
                     timeframe_ms=300_000, max_quote_age_ms=5_000):
    """Find a research sweep, then confirmed directional BOS, then FVG/retest.

    A BUY sweep pierces a prior 12-bar low and closes back above; SELL mirrors
    it. A later closed bullish BUY candle closes above the sweep bar's high;
    bearish SELL candle below its low. FVG = a three-bar gap, formed on or
    after that BOS. An optional buy ask / sell bid must be fresh, occur after
    the FVG bar closed, and fall inside the gap to observe a retest. Latest
    quote observation can MISS intrabar touches. This is NOT an order signal.
    """
    if type(lookback) is not int or lookback < 2:
        raise ValueError("lookback must be an integer of at least 2")
    if type(timeframe_ms) is not int or timeframe_ms <= 0:
        raise ValueError("timeframe_ms must be a positive integer")
    if type(max_quote_age_ms) is not int or max_quote_age_ms <= 0:
        raise ValueError("max_quote_age_ms must be a positive integer")
    _valid_bars(bars)
    if len(bars) < lookback + 2:
        return None
    candidates=[]
    for i in range(lookback, len(bars)-1):
        sweep=bars[i]; history=bars[i-lookback:i]
        prior_low=min(b.low for b in history); prior_high=max(b.high for b in history)
        buy=sweep.low < prior_low < sweep.close
        sell=sweep.high > prior_high > sweep.close
        if buy == sell: # none, or ambiguous outside bar that swept both sides
            continue
        direction="BUY" if buy else "SELL"
        for j in range(i+1,len(bars)):
            b=bars[j]
            confirmed=(b.close > sweep.high and b.close > b.open) if buy else (
                       b.close < sweep.low and b.close < b.open)
            if confirmed:
                candidates.append((j,i,direction)); break
    if not candidates:
        return None
    bos_i, sweep_i, direction = max(candidates, key=lambda c:(c[0],c[1]))
    sweep=bars[sweep_i]; bos=bars[bos_i]
    fvg=None
    for i in range(max(2,bos_i),len(bars)):
        a,c=bars[i-2],bars[i]
        if direction == "BUY" and c.low > a.high:
            fvg={"low":a.high,"high":c.low,"formation_bar_ms":c.timestamp_ms,
                 "formed_after_ms":c.timestamp_ms + timeframe_ms}; break
        if direction == "SELL" and c.high < a.low:
            fvg={"low":c.high,"high":a.low,"formation_bar_ms":c.timestamp_ms,
                 "formed_after_ms":c.timestamp_ms + timeframe_ms}; break
    retest=None; quote_fresh=False
    if fvg and isinstance(quote,dict) and type(now_ms) is int:
        qts=quote.get("timestamp_ms"); value=quote.get("ask" if direction=="BUY" else "bid")
        quote_fresh=(type(qts) is int and 0 <= now_ms-qts <= max_quote_age_ms and
                     qts >= fvg["formed_after_ms"] and isinstance(value,(int,float)) and
                     not isinstance(value,bool) and math.isfinite(value) and value > 0)
        if quote_fresh:
            retest=fvg["low"] <= value <= fvg["high"]
    phase = "BOS_RESEARCH"
    if fvg: phase = "FVG_RETEST_RESEARCH" if retest is True else "FVG_FORMED_RESEARCH"
    return {"direction":direction, "sweep_time_ms":sweep.timestamp_ms,
            "bos_time_ms":bos.timestamp_ms, "bos_is_latest_closed":bos_i == len(bars)-1,
            "sweep_extreme":sweep.low if direction=="BUY" else sweep.high,
            "reference_entry":bos.close, "fvg":fvg, "retest_observed":retest,
            "quote_fresh":quote_fresh, "phase":phase,
            "label":"Research sequence only; neither entry is verified or sent"}
