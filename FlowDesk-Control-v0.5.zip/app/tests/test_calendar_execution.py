import json
import unittest
from datetime import datetime, timedelta, timezone
from core.economic_calendar import CalendarClient
from core.mt5_execution import OrderIntent, prepare_request, MT5ExecutionAdapter, LiveExecutionLocked, BrokerPreflightRejected
from types import SimpleNamespace


class CalendarTests(unittest.TestCase):
    def test_default_does_not_fabricate_events(self):
        state=CalendarClient(key='').snapshot()
        self.assertFalse(state['configured']);self.assertEqual(state['events'],[])
        self.assertEqual(state['status'],'NOT_CONFIGURED')
    def test_guest_or_demo_key_is_not_used(self):
        c=CalendarClient(key='guest:guest')
        result=c.snapshot()
        self.assertFalse(result['configured']);self.assertEqual(result['events'],[])
        self.assertIn('not accepted',result['message'])
    def test_normalize_sorts_future_events_and_preserves_utc(self):
        now=datetime(2026,10,29,10,tzinfo=timezone.utc)
        data=[{'Date':'2026-10-29T12:00:00','Event':'CPI','Importance':3,'Country':'United States'},
              {'Date':'2026-10-29T11:00:00Z','Event':'Rate','Importance':2,'Country':'UK'},
              {'Date':'2026-10-28T10:00:00','Event':'Old','Importance':3},
              {'Date':'not-a-date','Event':'Bad','Importance':3}]
        result=CalendarClient._normalize(data,now=now)
        self.assertEqual([x['title'] for x in result],['Rate','CPI'])
        self.assertEqual(result[1]['utc_time'],'2026-10-29T12:00:00Z')
    def test_mock_response_only_in_test_no_key_in_state(self):
        future=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat()
        payload=json.dumps([{'Date':future,'Event':'Test event','Importance':3}]).encode()
        class Response:
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self,n):return payload
        def opener(req,timeout): return Response()
        c=CalendarClient(key='secret-test-key',opener=opener);c._refresh()
        self.assertEqual(c.state['status'],'RECEIVED_UNVERIFIED')
        self.assertEqual(len(c.state['events']),1)
        self.assertNotIn('secret-test-key',json.dumps(c.state))
    def test_failure_never_leaks_key(self):
        def bad(req,timeout): raise RuntimeError('secret-test-key')
        c=CalendarClient(key='secret-test-key',opener=bad);c._refresh()
        self.assertEqual(c.state['status'],'ERROR');self.assertEqual(c.state['events'],[])
        self.assertNotIn('secret-test-key',json.dumps(c.state))


class FakeMT5:
    TRADE_ACTION_DEAL=1; TRADE_ACTION_PENDING=5
    ORDER_TYPE_BUY=0; ORDER_TYPE_SELL=1; ORDER_TYPE_BUY_LIMIT=2; ORDER_TYPE_SELL_LIMIT=3
    ORDER_TIME_GTC=0; ORDER_TIME_SPECIFIED=2
    def __init__(self):self.sent=[]
    def order_send(self,request):self.sent.append(request);return {'sent':True}


class ExecutionScaffoldTests(unittest.TestCase):
    def setUp(self):self.mt5=FakeMT5()
    def prepare(self,intent):return prepare_request(self.mt5,intent,bid=100,ask=100.1,fill_policy=1,deviation_points=20,magic=42,now_utc_s=1000)
    def test_market_and_limit_requests_are_only_prepared(self):
        buy=self.prepare(OrderIntent('XAU-test','BUY',.01,99))
        self.assertEqual(buy['action'],self.mt5.TRADE_ACTION_DEAL);self.assertEqual(buy['price'],100.1)
        limit=self.prepare(OrderIntent('XAU-test','BUY',.01,98,'LIMIT',99,2000))
        self.assertEqual(limit['action'],self.mt5.TRADE_ACTION_PENDING);self.assertEqual(limit['expiration'],2000)
        self.assertEqual(self.mt5.sent,[])
    def test_invalid_stop_and_expiry_rejected(self):
        with self.assertRaises(ValueError):self.prepare(OrderIntent('XAU-test','BUY',.01,100.05))
        with self.assertRaises(ValueError):self.prepare(OrderIntent('XAU-test','BUY',.01,98,'LIMIT',99,900))
        with self.assertRaises(ValueError):self.prepare(OrderIntent('XAU-test','SELL',.01,101,'LIMIT',99,2000))
    def test_live_send_is_unconditionally_locked(self):
        request=self.prepare(OrderIntent('XAU-test','BUY',.01,99))
        with self.assertRaises(LiveExecutionLocked): MT5ExecutionAdapter(self.mt5).send(request)
        self.assertEqual(self.mt5.sent,[])


class FakeMT5Preflight(FakeMT5):
    SYMBOL_TRADE_MODE_FULL=4;SYMBOL_TRADE_MODE_LONGONLY=1;SYMBOL_TRADE_MODE_SHORTONLY=2
    SYMBOL_TRADE_EXECUTION_REQUEST=0;SYMBOL_TRADE_EXECUTION_INSTANT=1
    SYMBOL_TRADE_EXECUTION_MARKET=2;SYMBOL_TRADE_EXECUTION_EXCHANGE=3
    ORDER_FILLING_FOK=0;ORDER_FILLING_IOC=1;ORDER_FILLING_RETURN=2
    def __init__(self):
        super().__init__();self.checks=[];self.margin=20;self.retcode=0
        self.account=SimpleNamespace(login=42,server='test-server',trade_allowed=True,trade_expert=True,currency='USD',margin_free=100)
        self.terminal=SimpleNamespace(connected=True,trade_allowed=True,tradeapi_disabled=False)
        self.info=SimpleNamespace(trade_mode=4,volume_min=.01,volume_max=10,volume_step=.01,
                 trade_tick_size=.01,point=.01,trade_stops_level=5,trade_exemode=2,filling_mode=3)
        self.tick=SimpleNamespace(bid=100,ask=100.1,time_msc=1_000_000)
    def account_info(self):return self.account
    def terminal_info(self):return self.terminal
    def symbol_info(self,symbol):return self.info
    def symbol_info_tick(self,symbol):return self.tick
    def order_calc_margin(self,*args):return self.margin
    def order_check(self,request):
        self.checks.append(request)
        return None if self.retcode is None else SimpleNamespace(retcode=self.retcode)


class PreflightTests(unittest.TestCase):
    def setUp(self):self.mt5=FakeMT5Preflight();self.adapter=MT5ExecutionAdapter(self.mt5)
    def check(self,intent=None,**changes):
        kwargs={'expected_login':42,'expected_server':'test-server','now_ms':1_000_001,
                'fill_policy':1,'deviation_points':20,'magic':42}
        kwargs.update(changes)
        return self.adapter.preflight(intent or OrderIntent('XAU-test','BUY',.01,99),**kwargs)
    def test_mock_broker_preflight_does_not_send(self):
        r=self.check();self.assertTrue(r['checked']);self.assertEqual(r['margin_estimate'],20)
        self.assertNotIn('price',r['request']) # Market Execution request format
        self.assertEqual(len(self.mt5.checks),1);self.assertEqual(self.mt5.sent,[])
        with self.assertRaises(LiveExecutionLocked):self.adapter.send(r['request'])
        self.assertEqual(self.mt5.sent,[])
    def test_missing_or_changed_account_and_stale_quotes_fail_closed(self):
        with self.assertRaises(BrokerPreflightRejected):self.check(expected_login=123)
        with self.assertRaises(BrokerPreflightRejected):self.check(now_ms=1_005_001)
        self.mt5.terminal.trade_allowed=False
        with self.assertRaises(BrokerPreflightRejected):self.check()
        self.assertEqual(self.mt5.checks,[])
    def test_volume_stop_and_filling_rejected_before_broker_check(self):
        with self.assertRaises(BrokerPreflightRejected):self.check(OrderIntent('XAU-test','BUY',.015,99))
        with self.assertRaises(BrokerPreflightRejected):self.check(OrderIntent('XAU-test','BUY',.01,99.97))
        with self.assertRaises(BrokerPreflightRejected):self.check(fill_policy=self.mt5.ORDER_FILLING_RETURN)
        self.assertEqual(self.mt5.checks,[])
    def test_none_or_rejected_order_check_is_never_success(self):
        for rc in (None,10019):
            self.mt5.retcode=rc
            with self.subTest(rc=rc),self.assertRaises(BrokerPreflightRejected):self.check()
        self.assertEqual(self.mt5.sent,[])
    def test_pending_limit_requires_return_policy_and_does_not_send(self):
        intent=OrderIntent('XAU-test','BUY',.01,99,'LIMIT',99.5,2000)
        with self.assertRaises(BrokerPreflightRejected):self.check(intent,fill_policy=1)
        r=self.check(intent,fill_policy=self.mt5.ORDER_FILLING_RETURN)
        self.assertEqual(r['request']['type'],self.mt5.ORDER_TYPE_BUY_LIMIT)
        self.assertEqual(r['request']['expiration'],2000)
        self.assertEqual(self.mt5.sent,[])

    def test_invalid_or_unavailable_margin_fails_closed(self):
        self.mt5.margin=None
        with self.assertRaises(BrokerPreflightRejected):self.check()
        self.mt5.margin=101
        with self.assertRaises(BrokerPreflightRejected):self.check()
        self.assertEqual(self.mt5.checks,[])

if __name__ == '__main__': unittest.main()
