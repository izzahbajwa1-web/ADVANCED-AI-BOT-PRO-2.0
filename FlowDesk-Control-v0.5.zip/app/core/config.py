"""Local configuration. Policy values are stored but are not trading controls yet."""
from __future__ import annotations

import json
import math
import os
import tempfile
import threading
from pathlib import Path
from .bot_controls import DEFAULT_BOT_PLAN

DEFAULT_RISK = {
    "daily_loss_alert_pct": 10.0,
    "daily_reset_timezone": "UTC",
    "daily_loss_action": "alert_only",
    "risk_per_trade_pct": None,
    "max_open_positions": None,
    "lot_sizing": {"mode": "usd_balance_tiers", "currency": "USD",
                   "tiers": [{"min_balance": 0, "lots": 0.01},
                             {"min_balance": 200, "lots": 0.02},
                             {"min_balance": 500, "lots": 0.03},
                             {"min_balance": 600, "lots": 0.04},
                             {"min_balance": 700, "lots": 0.05}]},
    "trailing": {"activation_r": 1.0, "distance_r": 1.0, "requires_valid_setup": True},
    "setup_qualification": {"mode": "calibrated_probability", "min_probability": 0.90,
                            "model_status": "unconfigured", "outcome_definition": "unconfigured"},
    "invalidation": {"rule": "opposite_structure_and_orderflow", "action": "close_trade",
                     "detectors_status": "unconfigured", "allow_new_qualified_setups": True},
}
DEFAULT_STAGING = {
    "entry_timeframe": "M5", "context_timeframes": ["D1", "H4"],
    "first_entry": "market_after_sweep_bos_directional_close",
    "second_entry": "market_on_fvg_retest", "lot_allocation": "split_total_tier",
    "small_tier_exception": {"tier": 0.01, "first_lots": 0.01, "second_lots": 0.01},
    "initial_stop_reference": "beyond_sweep_extreme", "stop_buffer_ticks": None,
    "take_profit": "unconfigured", "status": "research_only",
}
DEFAULT = {"risk": DEFAULT_RISK, "staging": DEFAULT_STAGING,
           "market_context": {"dxy_symbol": None}, "watchlist": [], "mappings": [],
           "bot_plan": DEFAULT_BOT_PLAN}


def validate_risk(payload: object) -> dict:
    """Normalize the selected research policy; no settings enforce trading.

    The 10% daily level is an ALERT, not a loss cap. There is no per-trade
    risk percentage or position-count limit. Tiering uses USD balance.
    """
    if not isinstance(payload, dict):
        raise ValueError("Expected an object containing the daily alert policy.")
    if set(payload) - set(DEFAULT_RISK):
        raise ValueError("Unknown policy field.")
    value = payload.get("daily_loss_alert_pct")
    if isinstance(value, bool):
        raise ValueError("Daily alert must be a number greater than 0 and at most 100.")
    try:
        day = float(value)
    except (ValueError, TypeError):
        raise ValueError("Daily alert must be a number greater than 0 and at most 100.") from None
    if not math.isfinite(day) or not 0 < day <= 100:
        raise ValueError("Daily alert must be a number greater than 0 and at most 100.")
    if payload.get("daily_reset_timezone", "UTC") != "UTC":
        raise ValueError("This build implements the confirmed UTC reset only.")
    if payload.get("daily_loss_action", "alert_only") != "alert_only":
        raise ValueError("This policy specifies an alert only; it does not stop trading.")
    if payload.get("risk_per_trade_pct") is not None or payload.get("max_open_positions") is not None:
        raise ValueError("Per-trade risk and position-count caps are not enabled.")
    for key in ("lot_sizing", "trailing", "setup_qualification", "invalidation"):
        if payload.get(key, DEFAULT_RISK[key]) != DEFAULT_RISK[key]:
            raise ValueError(f"{key} does not match the confirmed research policy.")
    result = json.loads(json.dumps(DEFAULT_RISK))
    result["daily_loss_alert_pct"] = day
    return result


class ConfigStore:
    def __init__(self, path: Path):
        self.path = path
        self.lock = threading.RLock()
        self.data = json.loads(json.dumps(DEFAULT))
        if path.exists():
            with path.open(encoding="utf-8") as fh:
                loaded = json.load(fh)
            if not isinstance(loaded, dict):
                raise ValueError("config.json must be a JSON object")
            self.data.update(loaded)

    def read(self) -> dict:
        with self.lock:
            return json.loads(json.dumps(self.data))

    def _commit(self, updated: dict):
        # The caller holds the lock. A replace avoids half-written JSON files.
        fd, tmp = tempfile.mkstemp(prefix=".flowdesk-config-", suffix=".tmp", dir=self.path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as out:
                json.dump(updated, out, indent=2, allow_nan=False)
                out.write("\n")
            os.replace(tmp, self.path)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
        self.data = updated

    def set_risk(self, new_risk: object) -> dict:
        validated = validate_risk(new_risk)
        with self.lock:
            updated = self.read()
            updated["risk"] = validated
            self._commit(updated)
            return validated

    def set_bot_plan(self, plan: object) -> dict:
        # The controller has validated the only user-editable fields. Rebuild
        # from fixed defaults here too; config cannot switch on execution.
        from .bot_controls import validate_plan
        if not isinstance(plan, dict):
            raise ValueError("Invalid bot plan")
        normalized = validate_plan({"book_at_r": plan.get("book_at_r"),
                                    "book_percent": plan.get("book_percent")})
        with self.lock:
            updated = self.read()
            updated["bot_plan"] = normalized
            self._commit(updated)
        return normalized

    def set_market_context(self, payload: object) -> dict:
        if not isinstance(payload, dict) or set(payload) != {"dxy_symbol"}:
            raise ValueError("Provide only the MT5 dollar-index symbol, or an empty string to clear it")
        symbol = payload["dxy_symbol"]
        if not isinstance(symbol, str) or len(symbol) > 64 or any(ord(c) < 32 for c in symbol):
            raise ValueError("The MT5 symbol must be text of at most 64 characters")
        symbol = symbol.strip() or None
        with self.lock:
            updated = self.read()
            updated["market_context"] = {"dxy_symbol": symbol}
            self._commit(updated)
        return {"dxy_symbol": symbol}

    def add_mapping(self, payload: object) -> dict:
        if not isinstance(payload, dict):
            raise ValueError("Mapping must be an object")
        def text(key):
            v = payload.get(key)
            if not isinstance(v, str) or not v.strip() or len(v) > 100 or any(ord(c) < 32 for c in v):
                raise ValueError(f"{key} must be a non-empty name of at most 100 characters")
            return v.strip()
        symbol, platform = text("mt5_symbol"), text("platform").lower()
        provider, instrument = text("provider"), text("instrument")
        if platform not in {"bookmap", "quantower", "atas"}:
            raise ValueError("Invalid platform")
        if type(payload.get("is_proxy")) is not bool or payload.get("reviewed") is not True:
            raise ValueError("Choose a relationship and confirm the mapping")
        mapping = {"mt5_symbol": symbol, "platform": platform, "provider": provider,
                   "instrument": instrument, "is_proxy": payload["is_proxy"], "reviewed": True}
        with self.lock:
            updated = self.read()
            maps = [m for m in updated.get("mappings", []) if m.get("mt5_symbol") != symbol]
            maps.append(mapping)
            updated["mappings"] = maps
            watchlist = [s for s in updated.get("watchlist", []) if isinstance(s, str)]
            if symbol not in watchlist:
                watchlist.append(symbol)
            updated["watchlist"] = watchlist
            self._commit(updated)
        return mapping

    def remove_mapping(self, symbol: str):
        if not isinstance(symbol, str) or not symbol:
            raise ValueError("Symbol is required")
        with self.lock:
            updated = self.read()
            before = len(updated.get("mappings", []))
            updated["mappings"] = [m for m in updated.get("mappings", []) if m.get("mt5_symbol") != symbol]
            if len(updated["mappings"]) == before:
                raise ValueError("Mapping not found")
            updated["watchlist"] = [s for s in updated.get("watchlist", []) if s != symbol]
            self._commit(updated)
