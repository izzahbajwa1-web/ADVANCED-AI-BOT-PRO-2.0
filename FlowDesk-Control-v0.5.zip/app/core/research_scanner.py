"""Opt-in, read-only scan of every visible MT5 Market Watch symbol.

It applies the existing provisional research sequence, not a validated bot
signal. No probability model, live invalidation, execution, or order management
is connected. It uses only bars and quotes returned by the MT5 terminal.
"""
from __future__ import annotations
import threading
import time

from .staged_strategy import analyze_sequence


class ResearchScanner:
    def __init__(self, reader, log):
        self.reader = reader
        self.log = log
        self.lock = threading.RLock()
        self.cancel = threading.Event()
        self.thread = None
        self.state = {"status": "STOPPED", "scanned": 0, "total": 0, "signals": [],
                      "message": "Research scanner is stopped; no orders can be sent."}

    def status(self):
        with self.lock:
            return {**self.state, "signals": [dict(x) for x in self.state.get("signals", [])],
                    "can_trade": False, "model_validated": False}

    def scan_once(self):
        watch = self.reader.market_watch()
        if watch.get("status") != "RECEIVED_UNVERIFIED":
            with self.lock:
                self.state.update(status="WAITING", scanned=0, total=0, signals=[],
                                  message=watch.get("message", "MT5 Market Watch unavailable."))
            return
        names = [x["symbol"] for x in watch.get("symbols", []) if isinstance(x, dict) and isinstance(x.get("symbol"), str)]
        with self.lock:
            self.state.update(status="SCANNING", scanned=0, total=len(names), signals=[],
                              message="Reading closed M5 bars; research only, no orders.")
        for i, symbol in enumerate(names):
            if self.cancel.is_set():
                break
            found = None
            try:
                bars = self.reader.bars(symbol, 40, timeframe="M5")
                now_ms = int(time.time() * 1000)
                if bars:
                    age = now_ms - bars[-1].timestamp_ms
                    if 300_000 <= age <= 660_000:
                        quote = self.reader.quote(symbol)
                        found = analyze_sequence(bars, quote=quote, now_ms=now_ms)
            except (ValueError, TypeError, KeyError, AttributeError):
                # Missing/invalid broker data cannot generate a setup.
                found = None
            if found:
                found.update(symbol=symbol, flow_confirmed=False, probability=None,
                             qualification="UNAVAILABLE", executable=False,
                             warning="Research only. Order flow and 90% probability are not validated.")
            with self.lock:
                if found:
                    self.state["signals"].append(found)
                self.state["scanned"] = i + 1
        with self.lock:
            if self.cancel.is_set():
                self.state.update(status="STOPPED", message="Research scan stopped; no positions were changed.")
            else:
                self.state.update(status="WAITING_NEXT_SCAN",
                                  message="Cycle complete. Research only; no trade was sent.")

    def start(self):
        with self.lock:
            if self.thread and self.thread.is_alive():
                return {"started": True, "message": "Research scanner is already running; execution remains locked."}
            watch = self.reader.market_watch()
            if watch.get("status") != "RECEIVED_UNVERIFIED":
                return {"started": False, "message": "Connect MT5 and load Market Watch first; no bot trades are available."}
            self.cancel.clear()
            self.state.update(status="STARTING", scanned=0, total=len(watch.get("symbols", [])), signals=[],
                              message="Starting read-only research scan.")
            def worker():
                try:
                    while not self.cancel.is_set():
                        self.scan_once()
                        if self.cancel.wait(30):
                            break
                except Exception as exc:
                    with self.lock:
                        self.state.update(status="ERROR", message=f"Scanner failed ({type(exc).__name__}). No orders sent.")
                finally:
                    with self.lock:
                        if self.state.get("status") != "ERROR":
                            self.state.update(status="STOPPED", message="Research scanner stopped; no positions were changed.")
            self.thread = threading.Thread(target=worker, name="flowdesk-research-scan", daemon=True)
            self.thread.start()
        self.log("Research scanner", "Started a read-only Market Watch scan. Live orders remain locked.")
        return {"started": True, "message": "Research scan started; live execution is locked."}

    def stop(self):
        self.cancel.set()
        with self.lock:
            running = bool(self.thread and self.thread.is_alive())
            if running:
                self.state.update(status="STOPPING", message="Stopping after the current MT5 read.")
            else:
                self.state.update(status="STOPPED", message="Research scanner is stopped; no positions were changed.")
        if running:
            self.thread.join(timeout=2)
        self.log("Research scanner", "Stop requested; no MT5 positions were closed.")
        return {"stopped": not (self.thread and self.thread.is_alive()),
                "message": "Stop requested. This does not close or modify any MT5 position."}
