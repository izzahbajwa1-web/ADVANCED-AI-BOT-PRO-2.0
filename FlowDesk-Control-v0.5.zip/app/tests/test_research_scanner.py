import time
import unittest
from core.research_scanner import ResearchScanner
from core.strategy import Bar


class FakeReader:
    def __init__(self,count=55):self.count=count;self.seen=[]
    def market_watch(self):
        return {'status':'RECEIVED_UNVERIFIED','symbols':[{'symbol':f'S{i}'} for i in range(self.count)]}
    def bars(self,symbol,count,timeframe):
        self.seen.append(symbol)
        now=int(time.time()*1000);t=now-300_000-14*300_000
        bars=[Bar(t+i*300_000,100,102,98,100) for i in range(12)]
        return bars+[Bar(t+12*300_000,100,101,99,100),Bar(t+13*300_000,99,102,97,99),Bar(t+14*300_000,104,106,102,105)]
    def quote(self,symbol):return None


class ResearchScannerTests(unittest.TestCase):
    def test_all_visible_symbols_scanned_no_market_cap_and_none_eligible(self):
        reader=FakeReader(55);s=ResearchScanner(reader,lambda *a:None);s.scan_once();state=s.status()
        self.assertEqual(len(reader.seen),55);self.assertEqual(state['scanned'],55);self.assertEqual(state['total'],55)
        self.assertEqual(len(state['signals']),55)
        self.assertFalse(state['can_trade']);self.assertFalse(state['model_validated'])
        self.assertTrue(all(x['executable'] is False and x['probability'] is None for x in state['signals']))
    def test_cancel_stops_before_any_read_and_never_trades(self):
        reader=FakeReader();s=ResearchScanner(reader,lambda *a:None);s.cancel.set();s.scan_once()
        self.assertEqual(reader.seen,[]);self.assertEqual(s.status()['status'],'STOPPED')
    def test_unavailable_market_watch_cannot_start(self):
        reader=FakeReader();reader.market_watch=lambda:{'status':'DISCONNECTED','symbols':[]}
        s=ResearchScanner(reader,lambda *a:None)
        self.assertFalse(s.start()['started']);self.assertFalse(s.status()['can_trade'])

if __name__=='__main__':unittest.main()
