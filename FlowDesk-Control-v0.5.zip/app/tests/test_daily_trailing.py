import unittest
from datetime import datetime, timedelta, timezone
from core.daily_alert import evaluate_daily_alert, MissingDayStartEquity
from core.trailing import trail_after_one_r


class DailyAlertTests(unittest.TestCase):
    def setUp(self):
        self.t=datetime(2026,10,29,12,0,tzinfo=timezone.utc)

    def evaluate(self, **changes):
        args=dict(now=self.t,current_equity=10000,state=None,verified_day_start_equity=10000)
        args.update(changes)
        return evaluate_daily_alert(**args)

    def assert_alert_only(self, result):
        self.assertFalse(result['request_close_positions_due_to_daily_alert'])
        self.assertFalse(result['block_new_bot_entries_due_to_daily_alert'])

    def test_requires_verified_baseline(self):
        with self.assertRaises(MissingDayStartEquity):
            self.evaluate(verified_day_start_equity=None)

    def test_10_percent_cutoff_includes_current_equity_never_closes_or_blocks(self):
        state, above = self.evaluate(current_equity=9000.01)
        self.assertFalse(above['alerted_today']); self.assert_alert_only(above)
        state, at = self.evaluate(state=state, current_equity=9000, verified_day_start_equity=None)
        self.assertTrue(at['new_alert_requested'])
        self.assertTrue(at['alerted_today'])
        self.assertEqual(at['alert_equity_threshold'],9000)
        self.assertEqual(at['equity_drawdown_pct'],10)
        self.assert_alert_only(at)
        state, deep = self.evaluate(state=state, current_equity=5000, verified_day_start_equity=None)
        self.assertTrue(deep['alerted_today']); self.assertFalse(deep['new_alert_requested'])
        self.assert_alert_only(deep)

    def test_alert_latches_after_equity_recovers_but_does_not_block(self):
        state,_ = self.evaluate(current_equity=8999)
        state,recovered = self.evaluate(state=state, current_equity=9900,
                                        now=self.t+timedelta(hours=1), verified_day_start_equity=None)
        self.assertTrue(recovered['alerted_today'])
        self.assertFalse(recovered['new_alert_requested'])
        self.assert_alert_only(recovered)

    def test_next_utc_day_requires_new_verified_baseline(self):
        state,_ = self.evaluate(current_equity=9000)
        next_day=datetime(2026,10,30,0,0,tzinfo=timezone.utc)
        with self.assertRaises(MissingDayStartEquity):
            self.evaluate(now=next_day,current_equity=9100,state=state,verified_day_start_equity=None)
        state,reset = self.evaluate(now=next_day,current_equity=9100,state=state,verified_day_start_equity=9100)
        self.assertFalse(reset['alerted_today']); self.assert_alert_only(reset)
        self.assertEqual(reset['utc_day'],'2026-10-30')

    def test_utc_conversion_clock_reversal_and_no_baseline_replacement(self):
        state,_=self.evaluate()
        local=timezone(timedelta(hours=5))
        # 04:59 on Oct 30 in Pakistan is still Oct 29 in UTC.
        same_day=datetime(2026,10,30,4,59,tzinfo=local)
        state,result=self.evaluate(now=same_day,state=state,verified_day_start_equity=None)
        self.assertEqual(result['utc_day'],'2026-10-29')
        with self.assertRaises(ValueError):
            self.evaluate(now=self.t-timedelta(days=1),state=state,verified_day_start_equity=None)
        with self.assertRaises(ValueError):
            self.evaluate(state=state,verified_day_start_equity=12000)
        with self.assertRaises(ValueError):
            self.evaluate(now=datetime(2026,10,29,12,0))

    def test_invalid_equity_and_threshold(self):
        for kwargs in ({'current_equity':float('nan')}, {'daily_loss_alert_pct':0},
                       {'verified_day_start_equity':0}, {'current_equity':True}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                self.evaluate(**kwargs)


class TrailingTests(unittest.TestCase):
    def test_long_activates_exactly_at_one_r_and_trails(self):
        common=dict(side='BUY',entry_price=100,original_stop=99,current_stop=99)
        self.assertFalse(trail_after_one_r(**common,exit_quote=100.99).should_modify)
        at_one=trail_after_one_r(**common,exit_quote=101,tick_size=.01)
        self.assertTrue(at_one.activated);self.assertEqual(at_one.proposed_stop,100)
        further=trail_after_one_r(side='BUY',entry_price=100,original_stop=99,current_stop=100,
                                  exit_quote=101.37,tick_size=.01)
        self.assertEqual(further.proposed_stop,100.37)

    def test_short_uses_ask_and_tightens(self):
        at_one=trail_after_one_r(side='SELL',entry_price=100,original_stop=101,current_stop=101,
                                  exit_quote=99,tick_size=.01)
        self.assertEqual(at_one.proposed_stop,100)
        further=trail_after_one_r(side='SELL',entry_price=100,original_stop=101,current_stop=100,
                                  exit_quote=98.63,tick_size=.01)
        self.assertEqual(further.proposed_stop,99.63)

    def test_never_loosens_or_moves_on_retrace(self):
        decision=trail_after_one_r(side='BUY',entry_price=100,original_stop=99,current_stop=100.5,
                                  exit_quote=101.2,tick_size=.01)
        self.assertTrue(decision.activated);self.assertFalse(decision.should_modify)
        decision=trail_after_one_r(side='BUY',entry_price=100,original_stop=99,current_stop=100,
                                  exit_quote=100.8,tick_size=.01)
        self.assertFalse(decision.should_modify)

    def test_conservative_tick_rounding_and_invalid_stop(self):
        buy=trail_after_one_r(side='BUY',entry_price=100,original_stop=99,current_stop=99,
                               exit_quote=101.237,tick_size=.05)
        self.assertEqual(buy.proposed_stop,100.2)
        sell=trail_after_one_r(side='SELL',entry_price=100,original_stop=101,current_stop=101,
                                exit_quote=98.763,tick_size=.05)
        self.assertEqual(sell.proposed_stop,99.8)
        with self.assertRaises(ValueError):
            trail_after_one_r(side='BUY',entry_price=100,original_stop=100,current_stop=99,exit_quote=102)
        with self.assertRaises(ValueError):
            trail_after_one_r(side='SELL',entry_price=100,original_stop=101,current_stop=None,exit_quote=99)

    def test_stop_already_at_or_through_market_never_modifies(self):
        result=trail_after_one_r(side='BUY',entry_price=100,original_stop=99,current_stop=101.1,exit_quote=101)
        self.assertFalse(result.should_modify)
        self.assertIn('verify',result.reason)

if __name__=='__main__':unittest.main()
