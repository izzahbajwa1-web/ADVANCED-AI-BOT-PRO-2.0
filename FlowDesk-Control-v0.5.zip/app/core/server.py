from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import hmac
import json
import os
import sys

from .service import DeskService

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"
PREVIEW = os.getenv("FLOW_PREVIEW") == "1"
TOKEN = os.getenv("FLOW_GATEWAY_TOKEN", "") if not PREVIEW else ""
if len(TOKEN) < 16:
    TOKEN = ""
SERVICE = DeskService(ROOT / "config.json", preview=PREVIEW, bridge_enabled=bool(TOKEN))
MAX_BODY = 262_144


class Handler(BaseHTTPRequestHandler):
    server_version = "FlowDeskControlResearch/0.5"

    def _send(self, status, data, content_type="application/json; charset=utf-8"):
        if isinstance(data, (dict, list)):
            data = json.dumps(data, allow_nan=False, separators=(",", ":")).encode("utf-8")
        elif isinstance(data, str):
            data = data.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; object-src 'none'; base-uri 'none'")
        self.end_headers()
        self.wfile.write(data)

    def _same_origin(self):
        origin = self.headers.get("Origin")
        if not origin:
            return True
        parsed = urlsplit(origin)
        return parsed.scheme in {"http", "https"} and parsed.netloc == self.headers.get("Host")

    def _body(self):
        if self.headers.get_content_type() != "application/json":
            raise ValueError("Content-Type must be application/json")
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ValueError("Invalid Content-Length") from None
        if length <= 0 or length > MAX_BODY:
            raise ValueError("Invalid request size")
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"),
                              parse_constant=lambda x: (_ for _ in ()).throw(ValueError("Invalid number")))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError("Invalid JSON") from None

    def _valid_host(self):
        if PREVIEW:
            return True
        host = self.headers.get("Host", "").lower()
        port = self.server.server_port
        return host in {f"127.0.0.1:{port}", f"localhost:{port}"}

    def do_GET(self):
        if not self._valid_host():
            self._send(403, {"error": "Invalid Host"})
            return
        route = urlsplit(self.path).path
        assets = {"/": ("index.html", "text/html; charset=utf-8"),
                  "/styles.css": ("styles.css", "text/css; charset=utf-8"),
                  "/app.js": ("app.js", "text/javascript; charset=utf-8"),
                  "/control": ("control.html", "text/html; charset=utf-8"),
                  "/control.css": ("control.css", "text/css; charset=utf-8"),
                  "/control.js": ("control.js", "text/javascript; charset=utf-8")}
        if route in assets:
            name, ctype = assets[route]
            try:
                self._send(200, (WEB / name).read_bytes(), ctype)
            except FileNotFoundError:
                self._send(404, {"error": "Asset not found"})
        elif route == "/api/state":
            try:
                self._send(200, SERVICE.state())
            except Exception as exc:
                print(f"State error: {type(exc).__name__}: {exc}", file=sys.stderr)
                self._send(500, {"error": "Could not read application state"})
        elif route == "/api/market-watch":
            self._send(200, SERVICE.market_watch())
        elif route == "/api/positions":
            self._send(200, SERVICE.positions())
        elif route == "/api/bot/status":
            self._send(200, SERVICE.bot_status())
        elif route == "/api/research-scan":
            self._send(200, SERVICE.research_scan_status())
        elif route == "/api/health":
            self._send(200, {"ok": True, "orders_available": False})
        else:
            self._send(404, {"error": "Not found"})

    def do_POST(self):
        if not self._valid_host():
            self._send(403, {"error": "Invalid Host"})
            return
        route = urlsplit(self.path).path
        if route == "/api/bridge/events":
            auth = self.headers.get("Authorization", "")
            expected = "Bearer " + TOKEN
            if not TOKEN or not hmac.compare_digest(auth.encode("utf-8"), expected.encode("utf-8")):
                self._send(401, {"error": "Bridge token missing or invalid"})
                return
        elif not self._same_origin():
            self._send(403, {"error": "Cross-origin state changes are not allowed"})
            return
        try:
            body = self._body()
            if route == "/api/bridge/events":
                result = SERVICE.accept_bridge(body)
            elif route == "/api/mt5/connect":
                result = SERVICE.connect_mt5()
            elif route == "/api/mt5/disconnect":
                result = SERVICE.disconnect_mt5()
            elif route == "/api/risk":
                result = SERVICE.save_risk(body)
            elif route == "/api/context":
                result = SERVICE.save_market_context(body)
            elif route == "/api/bot/settings":
                result = SERVICE.save_bot_plan(body)
            elif route == "/api/bot/start":
                if body != {}:
                    raise ValueError("Start check takes no options")
                result = SERVICE.bot_start_check()
            elif route == "/api/bot/stop":
                if body != {}:
                    raise ValueError("Stop takes no options")
                result = SERVICE.bot_stop()
            elif route == "/api/research-scan/start":
                if body != {}:
                    raise ValueError("Research scan takes no options")
                result = SERVICE.research_scan_start()
            elif route == "/api/research-scan/stop":
                if body != {}:
                    raise ValueError("Research scan stop takes no options")
                result = SERVICE.research_scan_stop()
            elif route == "/api/broker/check":
                result = SERVICE.broker_check(body)
            elif route == "/api/daily/baseline":
                result = SERVICE.set_daily_baseline(body)
            elif route == "/api/mappings":
                result = SERVICE.add_mapping(body)
            elif route == "/api/mappings/remove":
                result = SERVICE.remove_mapping(body.get("symbol") if isinstance(body, dict) else None)
            else:
                self._send(404, {"error": "Not found"})
                return
            self._send(200, result)
        except ValueError as exc:
            self._send(400, {"error": str(exc)})
        except Exception as exc:
            print(f"Request error: {type(exc).__name__}: {exc}", file=sys.stderr)
            self._send(500, {"error": "Request failed"})


def main():
    host = os.getenv("FLOW_HOST", "127.0.0.1")
    if not PREVIEW and host not in {"127.0.0.1", "localhost"}:
        raise SystemExit("Only local loopback binding is allowed outside the isolated preview.")
    port = int(os.getenv("FLOW_PORT", "8765"))
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.daemon_threads = True
    print(f"FlowDesk research dashboard: http://{host}:{port} (MT5 order execution locked; research only)", flush=True)
    SERVICE.start_background()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        SERVICE.stop_background()
        SERVICE.reader.disconnect()
        httpd.server_close()


if __name__ == "__main__":
    main()
