import unittest
from core.management_plan import partial_volume, plan_position_management


class PartialTests(unittest.TestCase):
    def test_exact_half_is_valid_only_if_both_sides_are_valid(self):
        self.assertEqual(partial_volume(volume=.02, fraction=.5, minimum=.01, maximum=100, step=.01),
                         {'status':'EXACT','close_volume':.01,'remaining_volume':.01})
        for vol in (.01,.03,.05):
            result=partial_volume(volume=vol, fraction=.5, minimum=.01, maximum=100, step=.01)
            self.assertEqual(result['status'],'UNSPLITTABLE_NEEDS_USER_DECISION')
            self.assertIsNone(result['close_volume'])
    def test_invalid_current_volume_and_fraction_never_round(self):
        self.assertEqual(partial_volume(volume=.015,fraction=.5,minimum=.01,maximum=10,step=.01)['status'],'INVALID_CURRENT_VOLUME')
        for value in (0,1,True,float('nan')):
            with self.subTest(value=value), self.assertRaises(ValueError):
                partial_volume(volume=.02,fraction=value,minimum=.01,maximum=10,step=.01)


class PositionPlanTests(unittest.TestCase):
    def plan(self, **kw):
        params={'side':'BUY','entry_price':100,'original_stop':99,'current_stop':99,
                'exit_quote':100,'volume':.02,'minimum':.01,'maximum':10,'step':.01,
                'partial_recorded':False,'opposite_structure':False,'opposite_orderflow':False,
                'tick_size':.01,'quote_time_ms':1_000_000,'now_ms':1_000_000}
        params.update(kw)
        return plan_position_management(**params)
    def test_one_r_trail_starts_before_two_r_booking(self):
        p=self.plan(exit_quote=101)
        self.assertEqual(p['action'],'PROPOSE_TRAIL')
        self.assertEqual(p['trail']['proposed_stop'],100)
        self.assertIsNone(p['partial'])
    def test_two_r_exact_half_before_followup_trail(self):
        p=self.plan(exit_quote=102)
        self.assertEqual(p['action'],'PROPOSE_PARTIAL_THEN_RECHECK_TRAIL')
        self.assertEqual(p['partial']['close_volume'],.01)
        self.assertEqual(p['trail']['proposed_stop'],101)
    def test_unsplittable_never_closes_or_rounds_up(self):
        p=self.plan(exit_quote=102,volume=.01)
        self.assertEqual(p['action'],'NEEDS_REVIEW')
        self.assertEqual(p['partial']['status'],'UNSPLITTABLE_NEEDS_USER_DECISION')
        self.assertIsNone(p['partial']['close_volume'])
        self.assertEqual(p['trail']['proposed_stop'],101)
    def test_missing_partial_history_never_proposes_repeated_close(self):
        p=self.plan(exit_quote=102,partial_recorded=None)
        self.assertEqual(p['action'],'NEEDS_REVIEW')
        self.assertEqual(p['partial']['status'],'PARTIAL_HISTORY_UNKNOWN')
        p=self.plan(exit_quote=102,partial_recorded=True)
        self.assertEqual(p['partial']['status'],'ALREADY_RECORDED')
        self.assertEqual(p['action'],'PROPOSE_TRAIL')
    def test_invalidity_closes_before_other_proposals(self):
        p=self.plan(exit_quote=102,opposite_structure=True,opposite_orderflow=True)
        self.assertEqual(p['action'],'PROPOSE_CLOSE')
        self.assertIsNone(p['partial']); self.assertIsNone(p['trail'])
    def test_unknown_detector_and_stale_quote_fail_closed(self):
        p=self.plan(exit_quote=102,opposite_structure=None)
        self.assertEqual(p['action'],'WAIT')
        p=self.plan(exit_quote=102,now_ms=1_005_001)
        self.assertEqual(p['action'],'WAIT')
        self.assertIsNone(p['partial'])
    def test_sell_uses_ask_and_mirrored_two_r(self):
        p=self.plan(side='SELL',entry_price=100,original_stop=101,current_stop=101,exit_quote=98)
        self.assertEqual(p['action'],'PROPOSE_PARTIAL_THEN_RECHECK_TRAIL')
        self.assertEqual(p['trail']['proposed_stop'],99)
    def test_no_duplicate_close_if_price_not_at_target(self):
        p=self.plan(exit_quote=101.99)
        self.assertIsNone(p['partial'])
    def test_invalid_target_or_timestamp_rejected(self):
        for target in (1,11,True,float('inf')):
            with self.subTest(target=target), self.assertRaises(ValueError): self.plan(booking_r=target)
        with self.assertRaises(ValueError): self.plan(quote_time_ms=None)


if __name__=='__main__':unittest.main()
