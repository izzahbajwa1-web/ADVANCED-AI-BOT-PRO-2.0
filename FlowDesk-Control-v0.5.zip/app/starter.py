"""Local-only launcher for the Windows FlowDesk research package.

The trading adapter remains hard-locked. Starting this program never sends orders.
"""
from __future__ import annotations

import os
import sys
import threading
import webbrowser

# Do not inherit preview/public-binding settings when launched from the VPS bundle.
os.environ["FLOW_PREVIEW"] = "0"
os.environ["FLOW_HOST"] = "127.0.0.1"

from core import server


def connect_mt5_read_only() -> None:
    """Try the installed, already signed-in MT5 terminal; credentials are never supplied."""
    try:
        result = server.SERVICE.connect_mt5()
        if result.get("ok"):
            print("MT5: connected read-only. Check that it is the intended Exness account.", flush=True)
        else:
            print("MT5: not connected yet. Open and sign in to MT5, then connect from the dashboard.", flush=True)
            print("MT5 detail: " + str(result.get("message", "Unknown error")), flush=True)
    except Exception as exc:
        detail = (f"Automatic connection failed ({type(exc).__name__}). "
                  "Open and sign in to MT5, then try Connect MT5 in the dashboard.")
        server.SERVICE.log("MT5 reader", detail)
        print("MT5: " + detail, flush=True)


def main() -> int:
    try:
        port = int(os.environ.get("FLOW_PORT", "8765"))
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError:
        print("ERROR: FLOW_PORT must be a valid port number between 1 and 65535.", flush=True)
        return 1

    url = f"http://127.0.0.1:{port}/"
    try:
        httpd = server.ThreadingHTTPServer(("127.0.0.1", port), server.Handler)
    except OSError as exc:
        print(f"ERROR: Cannot start FlowDesk at {url}", flush=True)
        print("The port may already be in use. Close another FlowDesk window and try again.", flush=True)
        print(f"Windows reported: {exc}", flush=True)
        return 1

    print("=" * 64, flush=True)
    print("FlowDesk VPS - CONTROL RESEARCH / NO ORDERS", flush=True)
    print(f"Dashboard: {url}", flush=True)
    print("Keep this window open while you use the dashboard.", flush=True)
    print("Live/demo orders, automatic closes and stop changes are LOCKED.", flush=True)
    print("MT5 and any order-flow apps/data must be installed separately.", flush=True)
    print("Open Bot controls in the dashboard. Daily alert needs a verified baseline.", flush=True)
    print("=" * 64, flush=True)
    print("Trying to connect to the installed MT5 terminal (read-only)...", flush=True)
    threading.Thread(target=connect_mt5_read_only, name="mt5-read-only", daemon=True).start()

    if os.environ.get("FLOW_NO_BROWSER") != "1":
        try:
            if not webbrowser.open(url, new=2):
                print("Browser did not open automatically; paste the dashboard address above into it.", flush=True)
        except Exception:
            print("Browser did not open automatically; paste the dashboard address above into it.", flush=True)

    server.SERVICE.start_background()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping FlowDesk...", flush=True)
    finally:
        httpd.server_close()
        server.SERVICE.stop_background()
        server.SERVICE.reader.disconnect()
    return 0


if __name__ == "__main__":
    sys.exit(main())
